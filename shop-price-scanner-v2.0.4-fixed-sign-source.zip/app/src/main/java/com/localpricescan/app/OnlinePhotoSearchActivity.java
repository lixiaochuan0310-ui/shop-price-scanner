package com.localpricescan.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.MotionEvent;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 免费国内网页图片搜索；不调用付费商品接口，也不抓取非公开图片搜索 API。 */
public final class OnlinePhotoSearchActivity extends SwipeBackActivity {
    private static final int GALLERY_REQUEST = 601;
    private static final int MAX_REMOTE_BYTES = 8_000_000;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private EditText queryInput;
    private TextView status;
    private WebView web;
    private Button baiduButton, sogouButton, bingButton;
    private String searchWords = "";
    private String currentSearchUrl = "";
    private int engine = 0; // 0 百度，1 搜狗，2 必应
    private boolean selecting = false;
    private boolean pageFailed = false;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppUi.apply(this);
        setContentView(R.layout.activity_online_photo_search);
        String name = getIntent().getStringExtra("name");
        queryInput = findViewById(R.id.onlineSearchName);
        status = findViewById(R.id.onlineStatus);
        web = findViewById(R.id.onlineWeb);
        baiduButton = findViewById(R.id.onlineBaidu);
        sogouButton = findViewById(R.id.onlineSogou);
        bingButton = findViewById(R.id.onlineBing);
        findViewById(R.id.onlineBack).setOnClickListener(v -> onBackPressed());
        findViewById(R.id.onlineNameButton).setOnClickListener(v -> nameSearch());
        findViewById(R.id.onlineBrowser).setOnClickListener(v -> openBrowser());
        findViewById(R.id.onlineAlbum).setOnClickListener(v -> selectFromAlbum());
        baiduButton.setOnClickListener(v -> switchEngine(0));
        sogouButton.setOnClickListener(v -> switchEngine(1));
        bingButton.setOnClickListener(v -> switchEngine(2));
        queryInput.setSingleLine(true);
        queryInput.setOnEditorActionListener((v, actionId, event) -> { nameSearch(); return true; });
        queryInput.setText(name == null || name.trim().isEmpty() ? "" : name.trim());

        WebSettings webSettings = web.getSettings();
        webSettings.setJavaScriptEnabled(true); // 公开图片搜索网页依赖 JavaScript。
        // 以手机浏览器访问，而不是请求 PC 图片搜索页面；网页实际布局仍由网站决定。
        String mobileAgent = webSettings.getUserAgentString()
                .replace("; wv", "").replace("Version/4.0 ", "");
        webSettings.setUserAgentString(mobileAgent);
        webSettings.setDomStorageEnabled(true);
        webSettings.setLoadsImagesAutomatically(true);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(false);
        webSettings.setSupportMultipleWindows(false);
        webSettings.setAllowFileAccess(false);
        webSettings.setAllowContentAccess(false);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // 适配移动屏幕：宽网页先整体缩放到可见区域，放大后可横向平移。
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setSupportZoom(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        web.setInitialScale(0);
        web.setHorizontalScrollBarEnabled(true);
        web.setVerticalScrollBarEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                pageFailed = false;
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    pageFailed = true;
                    showStatus("图片搜索网页暂时无法打开。可以换一个搜索网站，或点击「在浏览器打开」。");
                }
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (!selecting && !pageFailed && url != null && !url.isEmpty() && !url.equals("about:blank")) {
                    status.setVisibility(View.GONE);
                }
            }
        });
        web.setOnLongClickListener(v -> {
            WebView.HitTestResult hit = web.getHitTestResult();
            if (hit == null) return false;
            int type = hit.getType();
            if (type != WebView.HitTestResult.IMAGE_TYPE &&
                    type != WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) return false;
            String imageUrl = hit.getExtra();
            if (imageUrl == null || !imageUrl.startsWith("https://")) {
                showStatus("此图片无法直接下载，可在浏览器打开后保存，再从相册选择。");
                return true;
            }
            new AlertDialog.Builder(this)
                    .setTitle("使用选中的商品图片？")
                    .setMessage("请先核对品牌、包装和规格。照片会复制到商品本地资料，保存商品后才能生效。")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("使用这张照片", (dialog, which) -> downloadSelected(imageUrl))
                    .show();
            return true;
        });
        updateEngine();
        if (name != null && !name.trim().isEmpty()) {
            runSearch(name.trim());
        }
    }

    /** 网页范围内的横向手势交给网页，不能触发左缘返回动画。 */
    @Override protected boolean shouldIgnoreSwipeBack(MotionEvent downEvent) {
        if (web == null || web.getVisibility() != View.VISIBLE) return false;
        Rect bounds = new Rect();
        return web.getGlobalVisibleRect(bounds) &&
                bounds.contains((int) downEvent.getRawX(), (int) downEvent.getRawY());
    }

    private void showStatus(String message) {
        status.setText(message);
        status.setVisibility(View.VISIBLE);
    }

    private void switchEngine(int selected) {
        engine = selected;
        updateEngine();
        String input = queryInput.getText().toString().trim();
        if (!input.isEmpty()) runSearch(input);
        else if (!searchWords.isEmpty()) runSearch(searchWords);
    }

    private void updateEngine() {
        baiduButton.setAlpha(engine == 0 ? 1f : .60f);
        sogouButton.setAlpha(engine == 1 ? 1f : .60f);
        bingButton.setAlpha(engine == 2 ? 1f : .60f);
    }

    private void nameSearch() {
        String value = queryInput.getText().toString().trim();
        if (value.isEmpty()) {
            queryInput.setError("请输入商品名称，例如：百事可乐 500ml");
            queryInput.requestFocus();
            return;
        }
        runSearch(value);
    }

    private void runSearch(String value) {
        if (value == null || value.trim().isEmpty()) return;
        searchWords = value.trim();
        try {
            String query = URLEncoder.encode(searchWords + " 商品包装图", "UTF-8");
            switch (engine) {
                case 1:
                    currentSearchUrl = "https://pic.sogou.com/pics?query=" + query;
                    break;
                case 2:
                    currentSearchUrl = "https://cn.bing.com/images/search?q=" + query + "&setlang=zh-Hans";
                    break;
                default:
                    // 百度移动图片结果页；不再嵌入 image.baidu.com PC 图片网页。
                    currentSearchUrl = "https://m.baidu.com/sf/vsearch?pd=image_content&word=" + query;
                    break;
            }
            String provider = engine == 0 ? "百度图片" : engine == 1 ? "搜狗图片" : "必应图片";
            showStatus("正在打开" + provider + "的手机网页…");
            web.loadUrl(currentSearchUrl);
            ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(queryInput.getWindowToken(), 0);
            queryInput.clearFocus();
        } catch (Exception e) {
            showStatus("无法生成搜索链接，请重新输入商品名称。");
        }
    }

    private void openBrowser() {
        if (currentSearchUrl.isEmpty()) {
            nameSearch();
            if (currentSearchUrl.isEmpty()) return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(currentSearchUrl)));
            showStatus("在浏览器中找到合适的包装图并保存到手机后，返回本页点「从相册选择」。");
        } catch (Exception e) {
            showStatus("未找到可打开网页的浏览器，请检查手机是否安装浏览器。");
        }
    }

    private void selectFromAlbum() {
        try { startActivityForResult(PhotoUtils.galleryIntent(), GALLERY_REQUEST); }
        catch (Exception e) { Toast.makeText(this, "无法打开相册", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == GALLERY_REQUEST && result == RESULT_OK && data != null && data.getData() != null) {
            returnPhoto(data.getData());
        }
    }

    /** 图片从网页下载后通过原有商品编辑页的照片导入逻辑压缩并保存。 */
    private void downloadSelected(String address) {
        if (selecting) return;
        selecting = true;
        showStatus("正在获取选中的照片…");
        String referer = web.getUrl();
        String agent = web.getSettings().getUserAgentString();
        worker.execute(() -> {
            try {
                byte[] bytes = downloadImage(address, referer, agent);
                File file = File.createTempFile("domestic_image_", ".img", getCacheDir());
                try (FileOutputStream output = new FileOutputStream(file)) { output.write(bytes); }
                byte[] jpeg;
                try { jpeg = PhotoUtils.readJpeg(this, Uri.fromFile(file)); }
                finally { file.delete(); }
                File converted = File.createTempFile("domestic_photo_", ".jpg", getCacheDir());
                try (FileOutputStream output = new FileOutputStream(converted)) { output.write(jpeg); }
                Uri result = FileProvider.getUriForFile(this,
                        getPackageName() + ".fileprovider", converted);
                main.post(() -> { if (!isFinishing()) returnPhoto(result); });
            } catch (Exception e) {
                main.post(() -> {
                    if (isFinishing()) return;
                    selecting = false;
                    showStatus("该网站限制了图片下载，或图片格式无法读取。可点「在浏览器打开」，保存后再从相册选择。也可长按其他图片重试。");
                });
            }
        });
    }

    private static byte[] downloadImage(String address, String referer, String agent) throws Exception {
        URL url = new URL(address);
        for (int redirect = 0; redirect < 4; redirect++) {
            if (!"https".equalsIgnoreCase(url.getProtocol()) || url.getHost().isEmpty())
                throw new IllegalArgumentException("仅允许 HTTPS 图片");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(9000);
            conn.setReadTimeout(12000);
            conn.setInstanceFollowRedirects(false);
            conn.setRequestProperty("User-Agent", agent);
            conn.setRequestProperty("Accept", "image/avif,image/webp,image/png,image/jpeg,image/*;q=0.8");
            if (referer != null && referer.startsWith("https://")) conn.setRequestProperty("Referer", referer);
            String cookies = CookieManager.getInstance().getCookie(url.toString());
            if (cookies != null && !cookies.isEmpty()) conn.setRequestProperty("Cookie", cookies);
            try {
                int code = conn.getResponseCode();
                if (code >= 300 && code < 400) {
                    String location = conn.getHeaderField("Location");
                    if (location == null || location.isEmpty()) throw new IllegalStateException("跳转缺少目标地址");
                    url = new URL(url, location);
                    continue;
                }
                if (code != 200) throw new IllegalStateException("图片获取失败 " + code);
                String contentType = conn.getContentType();
                if (contentType == null || !contentType.toLowerCase(java.util.Locale.ROOT).startsWith("image/"))
                    throw new IllegalStateException("该链接不是图片");
                long length = conn.getContentLengthLong();
                if (length > MAX_REMOTE_BYTES) throw new IllegalStateException("图片太大");
                try (InputStream input = conn.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[8192];
                    int read;
                    while ((read = input.read(buffer)) != -1) {
                        if (output.size() + read > MAX_REMOTE_BYTES) throw new IllegalStateException("图片太大");
                        output.write(buffer, 0, read);
                    }
                    byte[] result = output.toByteArray();
                    BitmapFactory.Options opts = new BitmapFactory.Options();
                    opts.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(result, 0, result.length, opts);
                    if (opts.outWidth <= 0 || opts.outHeight <= 0)
                        throw new IllegalStateException("无法解析图片");
                    return result;
                }
            } finally { conn.disconnect(); }
        }
        throw new IllegalStateException("图片跳转次数过多");
    }

    private void returnPhoto(Uri image) {
        Intent data = new Intent();
        data.setData(image);
        data.setClipData(ClipData.newRawUri("已选择的商品照片", image));
        data.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        setResult(Activity.RESULT_OK, data);
        finish();
    }

    @Override protected void onDestroy() {
        worker.shutdownNow();
        if (web != null) {
            web.stopLoading();
            web.setWebChromeClient(null);
            web.setWebViewClient(null);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
