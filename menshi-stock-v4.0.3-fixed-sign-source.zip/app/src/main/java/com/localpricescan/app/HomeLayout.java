package com.localpricescan.app;

/** Compact, width-driven home layout; no weighted gaps between business sections. */
final class HomeLayout {
    final int margin=12, columnGap=7;
    final int tileWidth,tileHeight,headerHeight,statsHeight,footerHeight;
    final int topGap,statsGap,rowGap,footerGap,gridPadding,logoSize,iconSize,iconGap,labelHeight;
    HomeLayout(int width,int height) {
        tileWidth=Math.max(44,(width-2*margin-8-3*columnGap)/4);
        boolean shortScreen=height<610;
        boolean veryShort=height<480;
        boolean tallScreen=height>=690;
        headerHeight=veryShort?76:shortScreen?94:tallScreen?114:110;
        statsHeight=veryShort?52:shortScreen?62:72;
        footerHeight=veryShort?38:shortScreen?46:tallScreen?58:56;
        topGap=veryShort?6:tallScreen?12:10;
        gridPadding=veryShort?4:tallScreen?9:7;
        // Keep spacing visually bounded even on tall phones.
        statsGap=veryShort?8:shortScreen?15:tallScreen?28:24;
        rowGap=veryShort?7:shortScreen?10:tallScreen?16:14;
        footerGap=veryShort?10:shortScreen?17:tallScreen?30:26;
        int fixed=headerHeight+statsHeight+footerHeight+topGap+statsGap+rowGap+footerGap+2*gridPadding;
        int target=Math.min(136,Math.round(tileWidth*(tallScreen?1.47f:1.41f)));
        // Reserve a small safe area for the bottom shadow and decorative wave.
        tileHeight=Math.max(28,Math.min(target,(height-fixed-12)/2));
        logoSize=veryShort?44:shortScreen?53:58;
        labelHeight=tileHeight<65?16:22;
        iconGap=tileHeight<65?2:7;
        iconSize=Math.max(10,Math.min(Math.min(54,Math.round(tileWidth*.65f)),tileHeight-labelHeight-iconGap-6));
    }
    int contentHeight(){return headerHeight+topGap+statsHeight+statsGap+2*gridPadding+2*tileHeight+rowGap+footerGap+footerHeight;}
}
