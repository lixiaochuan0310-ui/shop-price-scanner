package com.localpricescan.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import java.io.OutputStream;
import java.util.List;

/** 分页预览真实记录；选择格式后导出完整数据，不截断长字段。 */
public final class StoreReportPreviewActivity extends SwipeBackActivity {
    private static final int XLSX=941,DOCX=942,PAGE_SIZE=20;
    private ProductDatabase db;private StoreReportData data;
    private List<StoreExcel.Sheet> sheets;
    private Spinner tab;private LinearLayout list;private TextView counter;
    private int page=0,tabIndex=0;
    private int selectedFormat=XLSX;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);db=new ProductDatabase(this);
        selectedFormat="docx".equals(getIntent().getStringExtra("export_format"))?DOCX:XLSX;
        try{
            data=new StoreReportData(db,getIntent().getStringExtra("period"),
                    getIntent().getStringExtra("category"),getIntent().getStringExtra("term"));
            sheets=data.build();
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("报表读取失败")
                .setMessage(e.getMessage()).setPositiveButton("返回",(d,w)->finish()).show();return;}
        LinearLayout root=StoreUi.content(this,"报表预览");setContentView(root);
        LinearLayout body=StoreUi.padded(this,StoreUi.scroll(this,root));
        LinearLayout select=StoreUi.card(this);StoreUi.addCard(body,select);
        select.addView(StoreUi.text(this,data.description(),17,true));StoreUi.gap(select,10);
        TextView expl=StoreUi.text(this,"展示本次筛选的真实业务数据 · 内容较多时分页查看",12,false);
        expl.setTextColor(StoreUi.MUTED);select.addView(expl);StoreUi.gap(select,10);
        StoreUi.label(select,"选择查看的表格");
        tab=new Spinner(this);String[] labels=new String[sheets.size()];
        for(int i=0;i<labels.length;i++)labels[i]=sheets.get(i).name;
        tab.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));
        select.addView(tab);StoreUi.gap(select,10);
        counter=StoreUi.text(this,"",13,false);select.addView(counter);StoreUi.gap(select,9);
        LinearLayout nav=StoreUi.row(this);
        TextView prev=StoreUi.button(this,"上一页",0xffe2f1e7,StoreUi.GREEN);
        TextView next=StoreUi.button(this,"下一页",0xffe2f1e7,StoreUi.GREEN);
        nav.addView(prev,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,-2,1);np.leftMargin=StoreUi.d(this,9);
        nav.addView(next,np);select.addView(nav);
        prev.setOnClickListener(v->{if(page>0){page--;reload();}});
        next.setOnClickListener(v->{if((page+1)*PAGE_SIZE<Math.max(0,sheets.get(tabIndex).rows.size()-1)){page++;reload();}});
        list=StoreUi.column(this);body.addView(list);
        tab.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> parent,android.view.View view,int position,long id){
                tabIndex=position;page=0;reload();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent){}
        });
        LinearLayout actions=StoreUi.row(this);StoreUi.gap(body,8);
        TextView back=StoreUi.button(this,"‹  返回筛选",0xffedf6f3,StoreUi.GREEN);
        TextView export=StoreUi.button(this,selectedFormat==XLSX?"⬇  导出 Excel":"⬇  导出 Word",StoreUi.GREEN,0xffffffff);
        actions.addView(back,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,-2,1);ep.leftMargin=StoreUi.d(this,9);
        actions.addView(export,ep);body.addView(actions);
        back.setOnClickListener(v->finish());export.setOnClickListener(v->saveAs(selectedFormat));
        reload();
        // 导出入口直接调起所选格式的系统文件保存器；预览入口则留在当前页面。
        if(b==null && getIntent().getBooleanExtra("export_immediately",false)) {
            list.post(() -> saveAs(selectedFormat));
        }
    }
    private void reload(){
        if(list==null||sheets==null)return;
        StoreExcel.Sheet sheet=sheets.get(tabIndex);
        list.removeAllViews();int total=Math.max(0,sheet.rows.size()-1);
        int start=page*PAGE_SIZE,end=Math.min(total,start+PAGE_SIZE);
        counter.setText("共 "+total+" 条 · 当前第 "+(total==0?0:start+1)+"—"+end+" 条，可分页查看全部记录");
        if(total==0){TextView empty=StoreUi.text(this,"当前范围内没有符合条件的数据。",15,false);list.addView(empty);return;}
        List<Object> head=sheet.rows.get(0);
        for(int i=start;i<end;i++){
            List<Object> row=sheet.rows.get(i+1);LinearLayout card=StoreUi.card(this);StoreUi.addCard(list,card);
            card.addView(StoreUi.text(this,"记录 "+(i+1),16,true));StoreUi.gap(card,7);
            for(int col=0;col<head.size();col++){
                String title=head.get(col)==null?"":head.get(col).toString();
                String value=col<row.size()&&row.get(col)!=null?row.get(col).toString():"";
                TextView field=StoreUi.text(this,title+"："+value,13,false);
                field.setTextIsSelectable(true);card.addView(field);StoreUi.gap(card,3);
            }
        }
    }
    private void saveAs(int format){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(format==XLSX?"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        i.putExtra(Intent.EXTRA_TITLE,"门市进销存_"+data.term+"_"+data.category+
                (format==XLSX?".xlsx":".docx"));startActivityForResult(i,format);
    }
    @Override protected void onActivityResult(int req,int result,Intent intent){
        super.onActivityResult(req,result,intent);
        if((req!=XLSX&&req!=DOCX)||result!=RESULT_OK||intent==null||intent.getData()==null)return;
        Uri uri=intent.getData();
        try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
            if(out==null)throw new IllegalArgumentException("无法写入文件");
            if(req==XLSX)StoreExcel.write(out,sheets);
            else StoreWord.write(out,data.description(),sheets);
            new AlertDialog.Builder(this).setTitle("导出完成")
                    .setMessage("已导出本次筛选的完整记录。可用 Word 或 Excel 打开查看。")
                    .setPositiveButton("确定",null).show();
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("导出失败")
                .setMessage(e.getMessage()==null?"请选择其他保存位置":e.getMessage())
                .setPositiveButton("关闭",null).show();}
    }
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
