package com.localpricescan.app;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** 由原销售或领用单创建退货/退库，按商品逐项校验可退数量。 */
public final class StoreReturnActivity extends SwipeBackActivity {
    private ProductDatabase db;private InventoryStore store;
    private InventoryStore.Document source;
    private EditText date,note,refund;
    private final List<ReturnRow> rows=new ArrayList<>();
    private String cleanDraft="";
    private boolean confirming,submitting,saved;
    private TextView saveButton;
    private static final class ReturnRow {InventoryStore.Line origin;EditText quantity;}
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);db=new ProductDatabase(this);store=new InventoryStore(db);
        source=store.getDocument(getIntent().getLongExtra("source_id",0));
        if(source==null||source.voided||(!InventoryStore.SALE.equals(source.kind)&&!InventoryStore.ISSUE.equals(source.kind))) {
            new AlertDialog.Builder(this).setMessage("原销售单或领用单不可用")
                    .setPositiveButton("返回",(d,w)->finish()).show();return;
        }
        boolean sale=InventoryStore.SALE.equals(source.kind);
        LinearLayout root=StoreUi.content(this,sale?"销售退货":"内部领用退库");setContentView(root);
        LinearLayout body=StoreUi.padded(this,StoreUi.scroll(this,root));
        LinearLayout info=StoreUi.card(this);StoreUi.addCard(body,info);
        info.addView(StoreUi.text(this,"原单 #"+source.id+" · "+source.date,17,true));
        StoreUi.gap(info,6);
        StoreUi.label(info,"退回日期（点击选择）");
        date=StoreUi.input(this,"退回日期",InventoryStore.dateToday(),1);date.setFocusable(false);
        date.setOnClickListener(v->pick());info.addView(date);StoreUi.gap(info,9);
        StoreUi.label(info,"退回原因（选填）");note=StoreUi.input(this,"例如：客户退货、领用剩余", "",1);info.addView(note);
        for(InventoryStore.Line l:store.lines(source.id)){
            LinearLayout card=StoreUi.card(this);StoreUi.addCard(body,card);
            card.addView(StoreUi.text(this,l.name,17,true));StoreUi.gap(card,6);
            TextView t=StoreUi.text(this,"原单数量："+InventoryStore.qty(l.inputMilli)+" "+l.unit+
                    "  ·  退回单价："+Money.show(l.unitPrice),13,false);
            t.setTextColor(StoreUi.MUTED);card.addView(t);StoreUi.gap(card,9);
            StoreUi.label(card,"本次退回数量（不退填0）");
            ReturnRow row=new ReturnRow();row.origin=l;
            row.quantity=StoreUi.decimal(this,"数量", "0");card.addView(row.quantity);rows.add(row);
        }
        if(sale){
            LinearLayout refundCard=StoreUi.card(this);StoreUi.addCard(body,refundCard);
            StoreUi.label(refundCard,"实际退款金额（选填，默认等于退货金额）");
            refund=StoreUi.money(this,"实际退款金额","");refundCard.addView(refund);
        }
        saveButton=StoreUi.button(this,sale?"确认销售退货并增加库存":"确认内部退库并增加库存",StoreUi.GREEN,0xffffffff);
        StoreUi.gap(body,6);body.addView(saveButton);
        saveButton.setOnClickListener(v->confirm());
        if(b!=null){
            date.setText(b.getString("draftDate",StoreUi.value(date)));
            note.setText(b.getString("draftNote",""));
            if(refund!=null)refund.setText(b.getString("draftRefund",""));
            ArrayList<String> values=b.getStringArrayList("draftQty");
            if(values!=null)for(int i=0;i<Math.min(values.size(),rows.size());i++)rows.get(i).quantity.setText(values.get(i));
        }
        cleanDraft=b==null?signature():b.getString("cleanDraft",signature());
    }
    private String signature(){
        StringBuilder out=new StringBuilder(DraftSignature.of(date,note,refund));
        for(ReturnRow r:rows)out.append(DraftSignature.of(r.origin.barcode,r.quantity));
        return out.toString();
    }
    private boolean dirty(){return !saved&&!cleanDraft.equals(signature());}
    @Override protected boolean blockSwipeExitForUnsavedChanges(){return dirty();}
    @Override public void onBackPressed(){
        if(!dirty()){super.onBackPressed();return;}
        new AlertDialog.Builder(this).setTitle("放弃未保存的退回登记？")
                .setMessage("已填写的退回数量和备注将丢失。")
                .setNegativeButton("继续填写",null)
                .setPositiveButton("放弃",(d,w)->StoreReturnActivity.super.onBackPressed()).show();
    }
    @Override protected void onSaveInstanceState(Bundle state){
        super.onSaveInstanceState(state);state.putString("cleanDraft",cleanDraft);
        state.putString("draftDate",StoreUi.value(date));state.putString("draftNote",note.getText().toString());
        if(refund!=null)state.putString("draftRefund",refund.getText().toString());
        ArrayList<String> values=new ArrayList<>();for(ReturnRow r:rows)values.add(r.quantity.getText().toString());
        state.putStringArrayList("draftQty",values);
    }
    private void pick(){
        Calendar c=Calendar.getInstance();
        new DatePickerDialog(this,(view,y,m,d)->date.setText(String.format(Locale.ROOT,"%04d-%02d-%02d",y,m+1,d)),
                c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }
    private void confirm(){
        if(confirming||submitting||saved)return;
        try {
            List<InventoryStore.Line> selection=new ArrayList<>();long total=0;
            for(ReturnRow r:rows){
                Long q=InventoryStore.parseQty(StoreUi.value(r.quantity));
                if(q==null)throw new IllegalArgumentException("请填写正确的退回数量："+r.origin.name);
                if(q==0)continue;
                long base=BigDecimal.valueOf(q).multiply(BigDecimal.valueOf(r.origin.baseMilli))
                        .divide(BigDecimal.valueOf(r.origin.inputMilli),0,RoundingMode.UNNECESSARY).longValueExact();
                long amount=InventoryStore.amount(r.origin.unitPrice,q);
                selection.add(new InventoryStore.Line(r.origin.barcode,r.origin.name,r.origin.unit,q,base,r.origin.unitPrice,amount));
                total=Math.addExact(total,amount);
            }
            if(selection.isEmpty())throw new IllegalArgumentException("至少填写一项需要退回的商品数量");
            long value=total;
            Long manual=refund==null||StoreUi.value(refund).isEmpty()?null:Money.parseCents(StoreUi.value(refund));
            if(refund!=null&&!StoreUi.value(refund).isEmpty()&&manual==null)
                throw new IllegalArgumentException("实际退款金额填写错误");
            long actual=manual==null?value:manual;
            confirming=true;
            AlertDialog dialog=new AlertDialog.Builder(this).setTitle("确认退回")
                    .setMessage("原单 #"+source.id+"\n退回商品："+selection.size()+"种\n退货金额："+Money.show(value)+
                            (refund==null?"":"\n实际退款："+Money.show(actual))+
                            "\n确认后自动增加库存，记录独立退回单。")
                    .setNegativeButton("取消",null)
                    .setPositiveButton("确认",(d,w)->{
                        if(submitting||saved)return;
                        submitting=true;saveButton.setEnabled(false);
                        try{
                            store.createReturn(source.id,StoreUi.value(date),selection,actual,StoreUi.value(note));
                            saved=true;
                            new AlertDialog.Builder(this).setTitle("退回登记成功")
                                    .setMessage("已按本次实际退回数量增加库存，保存退回流水。")
                                    .setPositiveButton("确定",(x,y)->finish()).show();
                        }catch(Exception e){submitting=false;saveButton.setEnabled(true);
                            new AlertDialog.Builder(this).setTitle("登记失败")
                                .setMessage(e.getMessage()).setPositiveButton("关闭",null).show();}
                    }).create();
            dialog.setOnDismissListener(d->confirming=false);dialog.show();
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("数据有误")
                .setMessage(e.getMessage()).setPositiveButton("关闭",null).show();}
    }
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
