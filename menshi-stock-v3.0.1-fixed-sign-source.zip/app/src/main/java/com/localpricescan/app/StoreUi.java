package com.localpricescan.app;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** 简洁一致的门市业务表单组件，避免每个页面使用不相同的样式。 */
final class StoreUi {
    static final int GREEN=Color.rgb(27,124,107), INK=Color.rgb(32,64,63), MUTED=Color.rgb(99,119,117);
    static final int PALE=Color.rgb(246,250,249), WHITE=Color.WHITE;
    private StoreUi() {}
    static int d(Context c,float x) {return (int)(x*c.getResources().getDisplayMetrics().density+0.5f);}
    static GradientDrawable round(int color,int radius,Context c) {
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(d(c,radius));return g;
    }
    static GradientDrawable border(int color,int stroke,Context c) {
        GradientDrawable g=round(color,13,c);g.setStroke(d(c,1),stroke);return g;
    }
    static LinearLayout column(Context c) {
        LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.VERTICAL);return l;
    }
    static LinearLayout row(Context c) {
        LinearLayout l=new LinearLayout(c);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;
    }
    static LinearLayout.LayoutParams lp(int width,int height) {return new LinearLayout.LayoutParams(width,height);}
    static void gap(LinearLayout parent,int height) {
        View s=new View(parent.getContext());parent.addView(s,new LinearLayout.LayoutParams(1,d(parent.getContext(),height)));
    }
    static TextView text(Context c,String value,int sp,boolean bold) {
        TextView t=new TextView(c);t.setText(value);t.setTextColor(INK);t.setTextSize(sp);
        if (bold) t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;
    }
    static TextView button(Context c,String label,int bg,int fg) {
        TextView b=text(c,label,16,true);b.setTextColor(fg);b.setGravity(Gravity.CENTER);
        b.setPadding(d(c,12),d(c,12),d(c,12),d(c,12));b.setBackground(round(bg,14,c));
        b.setClickable(true);b.setFocusable(true);return b;
    }
    static EditText input(Context c,String hint,String value,int inputType) {
        EditText e=new EditText(c);e.setSingleLine(true);e.setTextSize(15);e.setTextColor(INK);
        e.setHint(hint);e.setText(value);e.setInputType(inputType);
        e.setPadding(d(c,12),d(c,11),d(c,12),d(c,11));e.setBackground(border(WHITE,0xffd5e5e1,c));
        return e;
    }
    static EditText decimal(Context c,String hint,String value) {
        EditText e=input(c,hint,value,InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setFilters(new android.text.InputFilter[]{new DecimalLimit(3)});
        return e;
    }
    static EditText money(Context c,String hint,String value) {
        EditText e=input(c,hint,value,InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setFilters(new android.text.InputFilter[]{new DecimalLimit(2)});
        return e;
    }
    static void label(LinearLayout parent,String value) {
        TextView t=text(parent.getContext(),value,13,false);t.setTextColor(MUTED);
        parent.addView(t);gap(parent,5);
    }
    static LinearLayout card(Context c) {
        LinearLayout l=column(c);l.setPadding(d(c,16),d(c,16),d(c,16),d(c,16));
        l.setBackground(border(WHITE,0xffe8efeb,c));l.setElevation(d(c,1));return l;
    }
    static LinearLayout content(Activity a,String title) {
        AppUi.apply(a);
        LinearLayout root=column(a);root.setBackgroundColor(PALE);
        LinearLayout head=row(a);head.setPadding(d(a,16),d(a,11),d(a,16),d(a,11));
        head.setBackgroundColor(0xffe2f3ef);
        TextView back=text(a,"‹  返回",16,true);back.setTextColor(GREEN);back.setOnClickListener(v->a.onBackPressed());
        head.addView(back);TextView heading=text(a,title,21,true);
        LinearLayout.LayoutParams hp=lp(0,ViewGroup.LayoutParams.WRAP_CONTENT);hp.weight=1;
        heading.setGravity(Gravity.CENTER);head.addView(heading,hp);
        TextView spacer=text(a,"",16,false);spacer.setWidth(d(a,47));head.addView(spacer);
        root.addView(head);
        return root;
    }
    static ScrollView scroll(Context c,LinearLayout root) {
        ScrollView s=new ScrollView(c);s.setFillViewport(true);s.setClipToPadding(false);
        s.setSmoothScrollingEnabled(true);s.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS);
        root.addView(s,new LinearLayout.LayoutParams(-1,0,1));return s;
    }
    static LinearLayout padded(Context c,ScrollView s) {
        LinearLayout body=column(c);body.setPadding(d(c,16),d(c,16),d(c,16),d(c,24));
        s.addView(body);return body;
    }
    static void addCard(LinearLayout body,View card) {
        LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=d(body.getContext(),12);
        body.addView(card,p);
    }
    static void clickableRow(LinearLayout parent,String label,View.OnClickListener action) {
        TextView b=button(parent.getContext(),label,0xffe3f2e9,GREEN);
        LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=d(parent.getContext(),8);
        parent.addView(b,p);b.setOnClickListener(action);
    }
    static String value(EditText e) {return e.getText().toString().trim();}
}
