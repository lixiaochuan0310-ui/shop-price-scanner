package com.localpricescan.app;

import android.app.AlertDialog;
import android.database.Cursor;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 入库、销售、内部领用、其他出库及盘点全部保留可查的单据流水。 */
public final class StoreRecordsActivity extends SwipeBackActivity {
    private ProductDatabase db;private InventoryStore store;
    private LinearLayout list;private EditText search;
    private String barcodeOnly;
    private static final class CountRow {
        long id,before,actual,delta;String date,code,name,note;
    }
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);db=new ProductDatabase(this);store=new InventoryStore(db);
        barcodeOnly=getIntent().getStringExtra("barcode");
        LinearLayout root=StoreUi.content(this,barcodeOnly==null?"业务流水记录":"商品流水记录");setContentView(root);
        LinearLayout body=StoreUi.padded(this,StoreUi.scroll(this,root));
        LinearLayout filters=StoreUi.card(this);StoreUi.addCard(body,filters);
        StoreUi.label(filters,"按日期、商品、人员、客户或工程搜索");
        search=StoreUi.input(this,"例如：2026-11、张三、摄像头","",1);filters.addView(search);
        StoreUi.gap(filters,8);
        TextView hint=StoreUi.text(this,"办理退货或领用退库：找到原销售／领用单，点击后选择「退货／退库」。",13,false);
        hint.setTextColor(StoreUi.MUTED);filters.addView(hint);
        StoreUi.gap(body,4);list=StoreUi.column(this);body.addView(list);
        search.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){reload();}
            @Override public void afterTextChanged(Editable e) {}
        });reload();
    }
    private List<CountRow> counts() {
        List<CountRow> out=new ArrayList<>();
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT id,business_date,barcode,product_name,"+
                "before_milli,actual_milli,delta_milli,note FROM stock_counts ORDER BY business_date DESC,id DESC",null)) {
            while(c.moveToNext()){CountRow r=new CountRow();r.id=c.getLong(0);r.date=c.getString(1);
                r.code=c.getString(2);r.name=c.getString(3);r.before=c.getLong(4);r.actual=c.getLong(5);
                r.delta=c.getLong(6);r.note=c.getString(7);out.add(r);}
        }return out;
    }
    private void reload() {
        if(list==null)return;
        list.removeAllViews();String q=StoreUi.value(search).toLowerCase(Locale.ROOT);
        int count=0;
        for(InventoryStore.Document doc:store.documents()) {
            List<InventoryStore.Line> lines=store.lines(doc.id);
            if(barcodeOnly!=null) {
                boolean related=false;for(InventoryStore.Line l:lines)if(barcodeOnly.equals(l.barcode))related=true;
                if(!related)continue;
            }
            StringBuilder names=new StringBuilder();for(InventoryStore.Line l:lines)names.append(l.name).append(' ');
            String target=(doc.date+doc.party+doc.department+doc.purpose+names+doc.id+
                    InventoryStore.kindName(doc.kind)).toLowerCase(Locale.ROOT);
            if(!q.isEmpty()&&!target.contains(q))continue;
            count++;
            LinearLayout card=StoreUi.card(this);
            TextView heading=StoreUi.text(this,InventoryStore.kindName(doc.kind)+
                    (doc.voided?"（已作废）":"")+"  ·  "+doc.date,17,true);
            card.addView(heading);StoreUi.gap(card,5);
            TextView info=StoreUi.text(this,"单号 #"+doc.id+"  ·  "+lines.size()+" 种商品\n"+
                    names.toString().trim(),13,false);info.setTextColor(StoreUi.MUTED);card.addView(info);
            if(InventoryStore.SALE.equals(doc.kind)||InventoryStore.IN.equals(doc.kind)||
                    InventoryStore.SALE_RETURN.equals(doc.kind)) {
                StoreUi.gap(card,6);TextView price=StoreUi.text(this,
                        "单据金额 "+Money.show(doc.total)+(InventoryStore.SALE.equals(doc.kind)?
                                "  ·  实收 "+Money.show(doc.paid):""),14,true);
                price.setTextColor(StoreUi.GREEN);card.addView(price);
            }
            StoreUi.addCard(list,card);card.setOnClickListener(v->showDocument(doc,lines));
        }
        // 已撤销的重复入库只留审计信息，不再参与库存和入库金额计算。
        try(Cursor c=db.getReadableDatabase().rawQuery(
                "SELECT business_date,barcode,product_name,base_qty_milli,amount_cents,"+
                "original_document_id,kept_barcode FROM stock_cancelled_inbound "+
                "ORDER BY cancelled_ms DESC,id DESC",null)) {
            while(c.moveToNext()) {
                String date=c.getString(0),code=c.getString(1),name=c.getString(2),kept=c.getString(6);
                if(barcodeOnly!=null&&!barcodeOnly.equals(code) && !barcodeOnly.equals(kept))continue;
                if(!q.isEmpty()&&!(date+code+name+kept+"撤销错误入库").toLowerCase(Locale.ROOT).contains(q))continue;
                count++;
                String detail="原日期："+date+"\n错误商品："+name+"\n条码："+code+
                        "\n原单号：#"+c.getLong(5)+"\n撤销数量："+InventoryStore.qty(c.getLong(3))+
                        "\n撤销金额："+Money.show(c.getLong(4))+"\n保留商品条码："+kept+
                        "\n原因：同一批货重复入库，已撤销错误登记";
                LinearLayout card=StoreUi.card(this);
                card.addView(StoreUi.text(this,"已撤销重复入库  ·  "+date,17,true));
                StoreUi.gap(card,5);
                TextView subtitle=StoreUi.text(this,name+"  ·  数量 "+InventoryStore.qty(c.getLong(3)),13,false);
                subtitle.setTextColor(StoreUi.MUTED);card.addView(subtitle);
                StoreUi.addCard(list,card);
                card.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("撤销记录")
                        .setMessage(detail).setPositiveButton("关闭",null).show());
            }
        }
        try(Cursor c=db.getReadableDatabase().rawQuery(
                "SELECT d.id,d.business_date,r.operation,r.reason,r.before_json,r.after_json,r.updated_ms " +
                "FROM stock_doc_revisions r JOIN stock_documents d ON d.id=r.document_id " +
                "ORDER BY r.updated_ms DESC,r.id DESC",null)) {
            while(c.moveToNext()){
                String id=Long.toString(c.getLong(0)),date=c.getString(1),op=c.getString(2),reason=c.getString(3);
                if(barcodeOnly!=null && !(c.getString(4)+c.getString(5)).contains(barcodeOnly))continue;
                if(!q.isEmpty()&&!(id+date+op+reason+c.getString(4)+c.getString(5)).toLowerCase(Locale.ROOT).contains(q))continue;
                count++;
                LinearLayout card=StoreUi.card(this);
                card.addView(StoreUi.text(this,("VOID".equals(op)?"单据作废":"单据修改")+"  ·  "+date,17,true));
                StoreUi.gap(card,4);TextView tip=StoreUi.text(this,"原单号 #"+id+" · 原因："+reason,13,false);
                tip.setTextColor(StoreUi.MUTED);card.addView(tip);
                StoreUi.addCard(list,card);
                String detail="单据 #"+id+"\n操作："+("VOID".equals(op)?"作废":"修改")+
                        "\n原因："+reason+"\n\n修改前：\n"+c.getString(4)+"\n\n修改后：\n"+c.getString(5);
                card.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("单据审计记录")
                        .setMessage(detail).setPositiveButton("关闭",null).show());
            }
        }
        for(CountRow c:counts()) {
            if(barcodeOnly!=null&&!barcodeOnly.equals(c.code))continue;
            if(!q.isEmpty() && !(c.date+c.name+c.code+c.note).toLowerCase(Locale.ROOT).contains(q))continue;
            count++;LinearLayout card=StoreUi.card(this);
            card.addView(StoreUi.text(this,"库存盘点  ·  "+c.date,17,true));
            StoreUi.gap(card,5);
            TextView t=StoreUi.text(this,c.name+"\n系统 "+InventoryStore.qty(c.before)+
                    "  →  实盘 "+InventoryStore.qty(c.actual)+"  ·  差额 "+InventoryStore.qty(c.delta),13,false);
            t.setTextColor(StoreUi.MUTED);card.addView(t);
            StoreUi.addCard(list,card);card.setOnClickListener(v->showCount(c));
        }
        if(count==0)list.addView(StoreUi.text(this,"没有符合条件的业务记录。",15,false));
    }
    private void showDocument(InventoryStore.Document d,List<InventoryStore.Line> lines) {
        StringBuilder sb=new StringBuilder("日期：").append(d.date).append("\n单据：#").append(d.id);
        if(!d.party.isEmpty())sb.append("\n客户／供货商／领用人：").append(d.party);
        if(!d.department.isEmpty())sb.append("\n部门／工程：").append(d.department);
        if(!d.purpose.isEmpty())sb.append("\n用途／原因：").append(d.purpose);
        sb.append("\n\n商品明细：");
        for(InventoryStore.Line l:lines){
            if(barcodeOnly!=null&&!barcodeOnly.equals(l.barcode))continue;
            sb.append("\n").append(l.name).append("\n  ").append(InventoryStore.qty(l.inputMilli)).append(" ")
                    .append(l.unit).append(" × ").append(Money.show(l.unitPrice)).append(" = ").append(Money.show(l.amount));
        }
        if(d.sourceId>0)sb.append("\n来源单号：#").append(d.sourceId);
        if(d.voided)sb.append("\n【本单已作废，不参与库存或销售统计】");
        sb.append("\n\n单据总额：").append(Money.show(d.total));
        if(InventoryStore.SALE.equals(d.kind))sb.append("\n实收金额：").append(Money.show(d.paid));
        new AlertDialog.Builder(this).setTitle(InventoryStore.kindName(d.kind)+"详情")
                .setMessage(sb.toString()).setNegativeButton("关闭",null)
                .setPositiveButton(d.voided?"知道了":"单据操作",(dialog,which)->{
                    if(!d.voided)showActions(d);
                }).show();
    }
    private void showActions(InventoryStore.Document d){
        List<String> choices=new ArrayList<>();
        if(d.sourceId==0)choices.add("修改原单据");
        choices.add("作废此单据");
        if(InventoryStore.SALE.equals(d.kind)||InventoryStore.ISSUE.equals(d.kind))
            choices.add(InventoryStore.SALE.equals(d.kind)?"登记销售退货":"登记领用退库");
        new AlertDialog.Builder(this).setTitle("单据 #"+d.id+" · 选择操作")
                .setItems(choices.toArray(new String[0]),(di,n)->{
                    String choice=choices.get(n);
                    if(choice.startsWith("修改")){
                        Intent intent=new Intent(this,StoreDocumentActivity.class);
                        intent.putExtra("edit_document_id",d.id);intent.putExtra("kind",d.kind);
                        startActivity(intent);
                    }else if(choice.startsWith("作废"))requestVoid(d);
                    else{
                        Intent intent=new Intent(this,StoreReturnActivity.class);
                        intent.putExtra("source_id",d.id);startActivity(intent);
                    }
                }).show();
    }
    private void requestVoid(InventoryStore.Document d){
        EditText reason=StoreUi.input(this,"必填：本次作废原因","",1);
        AlertDialog prompt=new AlertDialog.Builder(this).setTitle("确认作废单据 #"+d.id)
                .setMessage("作废会撤销这张单据对库存、销售统计的影响，原单和审计记录仍保留。").setView(reason)
                .setNegativeButton("取消",null).setPositiveButton("确认作废",(dialog,which)->{
                    try{
                        store.voidDocument(d.id,StoreUi.value(reason));
                        new AlertDialog.Builder(this).setTitle("作废成功")
                                .setMessage("库存与统计已重新计算，原始记录完整保留。")
                                .setPositiveButton("确定",(x,y)->reload()).show();
                    }catch(Exception e){new AlertDialog.Builder(this).setTitle("无法作废")
                                .setMessage(e.getMessage()).setPositiveButton("关闭",null).show();}
                }).create();
        prompt.show();KeyboardGuard.forDialog(prompt);
    }
    @Override protected void onResume(){super.onResume();if(list!=null)reload();}
    private void showCount(CountRow c) {
        new AlertDialog.Builder(this).setTitle("库存盘点详情")
                .setMessage("日期："+c.date+"\n商品："+c.name+"\n条码："+c.code+
                        "\n原库存："+InventoryStore.qty(c.before)+
                        "\n实盘数量："+InventoryStore.qty(c.actual)+
                        "\n盘点差额："+InventoryStore.qty(c.delta)+"\n备注："+c.note)
                .setPositiveButton("关闭",null).show();
    }
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
