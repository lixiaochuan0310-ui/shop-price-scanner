package com.localpricescan.app;

import android.database.Cursor;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** 按业务日期重放流水生成指定日/月/年的库存期初、期间变动及期末快照。 */
final class StoreReportData {
    final String period,category,term,start,end;
    private final ProductDatabase helper;private final InventoryStore store;
    static final String ALL="all", SALES="sales", STOCK="stock", ISSUE="issue";
    StoreReportData(ProductDatabase db,String period,String category,String term){
        this.helper=db;store=new InventoryStore(db);this.period=period;this.category=category;
        this.term=term==null?"":term.trim();
        if(!ALL.equals(category)&&!SALES.equals(category)&&!STOCK.equals(category)&&!ISSUE.equals(category))
            throw new IllegalArgumentException("统计内容有误");
        if("day".equals(period)&&InventoryStore.validDate(this.term)){
            start=this.term;end=this.term;
        }else if("month".equals(period)&&this.term.matches("\\d{4}-(0[1-9]|1[0-2])")){
            start=this.term+"-01";end=this.term+"-31";
        }else if("year".equals(period)&&this.term.matches("\\d{4}")){
            start=this.term+"-01-01";end=this.term+"-12-31";
        }else throw new IllegalArgumentException("请选择有效统计日期");
    }
    String description(){
        String periodName="day".equals(period)?"每日":"month".equals(period)?"每月":"每年";
        String label=ALL.equals(category)?"全部数据":SALES.equals(category)?"销售数据":STOCK.equals(category)?"库存数据":"内部领用数据";
        return periodName+" · "+term+" · "+label;
    }
    boolean inPeriod(String date){return date.compareTo(start)>=0&&date.compareTo(end)<=0;}
    private static BigDecimal q(long x){return BigDecimal.valueOf(x,3);}
    private static BigDecimal money(long x){return BigDecimal.valueOf(x,2);}
    private static final class InventoryRow {
        final ProductDatabase.Product product;final InventoryStore.Settings settings;
        long beginning,periodIn,sale,saleReturn,issue,issueReturn,other,adjust;
        InventoryRow(ProductDatabase.Product p,InventoryStore.Settings s){
            product=p;settings=s;beginning=s.opening;
        }
        long ending(){return beginning+periodIn-sale+saleReturn-issue+issueReturn-other+adjust;}
        void apply(String kind,long quantity,boolean before){
            long signed=(InventoryStore.IN.equals(kind)||InventoryStore.SALE_RETURN.equals(kind)||
                    InventoryStore.ISSUE_RETURN.equals(kind))?quantity:-quantity;
            if(before){beginning=Math.addExact(beginning,signed);return;}
            switch(kind){
                case InventoryStore.IN:periodIn+=quantity;break;
                case InventoryStore.SALE:sale+=quantity;break;
                case InventoryStore.SALE_RETURN:saleReturn+=quantity;break;
                case InventoryStore.ISSUE:issue+=quantity;break;
                case InventoryStore.ISSUE_RETURN:issueReturn+=quantity;break;
                case InventoryStore.OTHER:other+=quantity;break;
            }
        }
    }
    private List<InventoryRow> inventory(){
        Map<String,InventoryRow> map=new LinkedHashMap<>();
        for(ProductDatabase.Product p:helper.all())map.put(p.barcode,new InventoryRow(p,store.settings(p.barcode)));
        try(Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT l.barcode,d.business_date,d.kind,l.base_qty_milli FROM stock_lines l " +
                "JOIN stock_documents d ON d.id=l.document_id WHERE d.voided=0 AND d.business_date<=? " +
                "ORDER BY d.business_date,d.id,l.id",new String[]{end})){
            while(c.moveToNext()){
                InventoryRow row=map.get(c.getString(0));if(row==null)continue;
                row.apply(c.getString(2),c.getLong(3),c.getString(1).compareTo(start)<0);
            }
        }
        try(Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT barcode,business_date,delta_milli FROM stock_counts WHERE business_date<=? " +
                "ORDER BY business_date,id",new String[]{end})){
            while(c.moveToNext()){
                InventoryRow row=map.get(c.getString(0));if(row==null)continue;
                if(c.getString(1).compareTo(start)<0)row.beginning+=c.getLong(2);
                else row.adjust+=c.getLong(2);
            }
        }
        return new ArrayList<>(map.values());
    }
    List<StoreExcel.Sheet> build(){
        List<StoreExcel.Sheet> sheets=new ArrayList<>();
        StoreExcel.Sheet description=new StoreExcel.Sheet("报表说明");
        description.add("项目","内容");description.add("软件","门市进销存");
        description.add("报表范围",description());description.add("统计起始日期",start);
        description.add("统计结束日期",end);
        description.add("计算口径","按单据业务日期；已作废单据不参与销量和库存；退货、退库分别统计");
        description.add("历史库存","期初库存为所选期间第一天前的结存，期末库存为期间最后一天结存");
        description.add("单位","数量以商品基础单位统计，金额单位为人民币元");
        sheets.add(description);
        if(ALL.equals(category)||STOCK.equals(category)){
            StoreExcel.Sheet stock=new StoreExcel.Sheet("期间库存汇总");
            stock.add("商品名称","商品条码","基础单位","期初库存","期间入库","期间销售", "销售退货", "内部领用", "领用退库", "其他出库", "盘点调整", "期末库存");
            for(InventoryRow r:inventory())stock.add(r.product.name,r.product.barcode,r.settings.base,
                    q(r.beginning),q(r.periodIn),q(r.sale),q(r.saleReturn),q(r.issue),q(r.issueReturn),q(r.other),q(r.adjust),q(r.ending()));
            sheets.add(stock);
        }
        if(ALL.equals(category)){
            StoreExcel.Sheet product=new StoreExcel.Sheet("商品资料");
            product.add("名称","条码","基础单位","包装单位","换算比例","预设进价(元)","预设售价(元)");
            for(ProductDatabase.Product p:helper.all()){
                InventoryStore.Settings unit=store.settings(p.barcode);
                product.add(p.name,p.barcode,unit.base,unit.pack,unit.factor,money(p.purchaseCents),money(p.saleCents));
            }sheets.add(product);
        }
        StoreExcel.Sheet saleLines=new StoreExcel.Sheet("销售明细");
        saleLines.add("业务日期","单据类型","单号","商品名称","条码","数量","单位","单价(元)","金额(元)","客户","原销售单号");
        StoreExcel.Sheet saleDocs=new StoreExcel.Sheet("销售单汇总");
        saleDocs.add("业务日期","单据类型","单号","购买人/客户","商品种数","销售/退货金额(元)","实收/退回金额(元)","关联原单号");
        StoreExcel.Sheet issue=new StoreExcel.Sheet("内部领用明细");
        issue.add("业务日期","类型","单号","商品名称","条码","数量","单位","领用人","部门/工程","用途/退回原因","原领用单号");
        StoreExcel.Sheet in=new StoreExcel.Sheet("商品入库明细");
        in.add("业务日期","单号","名称","条码","数量","单位","单价(元)","小计(元)","供货商");
        StoreExcel.Sheet other=new StoreExcel.Sheet("其他出库明细");
        other.add("业务日期","单号","名称","条码","数量","单位","接收方","原因");
        StoreExcel.Sheet allDocs=new StoreExcel.Sheet("单据总览");
        allDocs.add("业务日期","业务类型","单号","来源单号","供货商/客户/领用人","部门/工程","用途","商品种数","总额(元)","实收/退回(元)");
        Map<String,long[]> days=new LinkedHashMap<>();
        for(InventoryStore.Document doc:store.documents()){
            if(doc.voided||!inPeriod(doc.date))continue;
            List<InventoryStore.Line> lines=store.lines(doc.id);
            boolean isSale=InventoryStore.SALE.equals(doc.kind)||InventoryStore.SALE_RETURN.equals(doc.kind);
            boolean isIssue=InventoryStore.ISSUE.equals(doc.kind)||InventoryStore.ISSUE_RETURN.equals(doc.kind);
            if(ALL.equals(category))allDocs.add(doc.date,InventoryStore.kindName(doc.kind),doc.id,
                    doc.sourceId>0?doc.sourceId:"",doc.party,doc.department,doc.purpose,
                    lines.size(),money(doc.total),isSale?money(doc.paid):"");
            if(isSale&&(SALES.equals(category)||ALL.equals(category))){
                saleDocs.add(doc.date,InventoryStore.kindName(doc.kind),doc.id,doc.party,lines.size(),
                        money(doc.total),money(doc.paid),doc.sourceId>0?doc.sourceId:"");
                long[] daily=days.computeIfAbsent(doc.date,k->new long[4]);
                int sign=InventoryStore.SALE_RETURN.equals(doc.kind)?-1:1;
                if(sign>0)daily[0]++;else daily[3]++;
                daily[1]+=sign*doc.total;daily[2]+=sign*doc.paid;
            }
            for(InventoryStore.Line l:lines){
                if(isSale&&(SALES.equals(category)||ALL.equals(category)))saleLines.add(
                        doc.date,InventoryStore.kindName(doc.kind),doc.id,l.name,l.barcode,
                        q(l.inputMilli),l.unit,money(l.unitPrice),money(l.amount),doc.party,
                        doc.sourceId>0?doc.sourceId:"");
                if(isIssue&&(ISSUE.equals(category)||ALL.equals(category)))issue.add(
                        doc.date,InventoryStore.kindName(doc.kind),doc.id,l.name,l.barcode,
                        q(l.inputMilli),l.unit,doc.party,doc.department,doc.purpose,
                        doc.sourceId>0?doc.sourceId:"");
                if(ALL.equals(category)&&InventoryStore.IN.equals(doc.kind))in.add(doc.date,doc.id,
                        l.name,l.barcode,q(l.inputMilli),l.unit,money(l.unitPrice),money(l.amount),doc.party);
                if(ALL.equals(category)&&InventoryStore.OTHER.equals(doc.kind))other.add(doc.date,
                        doc.id,l.name,l.barcode,q(l.inputMilli),l.unit,doc.party,doc.purpose);
            }
        }
        if(SALES.equals(category)||ALL.equals(category)){
            sheets.add(saleLines);sheets.add(saleDocs);
            StoreExcel.Sheet daySummary=new StoreExcel.Sheet("每日销售汇总");
            daySummary.add("业务日期","销售单数","退货单数","扣除退货后销售额(元)","扣除退款后实收(元)");
            for(Map.Entry<String,long[]> d:days.entrySet())daySummary.add(d.getKey(),d.getValue()[0],d.getValue()[3],money(d.getValue()[1]),money(d.getValue()[2]));
            sheets.add(daySummary);
        }
        if(ISSUE.equals(category)||ALL.equals(category))sheets.add(issue);
        if(ALL.equals(category)){
            sheets.add(in);sheets.add(other);sheets.add(allDocs);
            StoreExcel.Sheet counts=new StoreExcel.Sheet("库存盘点明细");
            counts.add("日期","商品名称","条码","系统库存","实盘库存","盘盈盘亏","备注");
            try(Cursor c=helper.getReadableDatabase().rawQuery(
                    "SELECT business_date,product_name,barcode,before_milli,actual_milli,delta_milli,note " +
                    "FROM stock_counts WHERE business_date>=? AND business_date<=? ORDER BY business_date,id",
                    new String[]{start,end})){
                while(c.moveToNext())counts.add(c.getString(0),c.getString(1),c.getString(2),
                        q(c.getLong(3)),q(c.getLong(4)),q(c.getLong(5)),c.getString(6));
            }sheets.add(counts);
            StoreExcel.Sheet correction=new StoreExcel.Sheet("单据修改作废");
            correction.add("原单号","操作","操作原因","操作时间(毫秒)","修改前内容(JSON)","修改后内容(JSON)");
            try(Cursor c=helper.getReadableDatabase().rawQuery(
                    "SELECT r.document_id,r.operation,r.reason,r.updated_ms,r.before_json,r.after_json " +
                    "FROM stock_doc_revisions r JOIN stock_documents d ON d.id=r.document_id " +
                    "WHERE d.business_date>=? AND d.business_date<=? ORDER BY r.updated_ms,r.id",
                    new String[]{start,end})){
                while(c.moveToNext())correction.add(c.getLong(0),c.getString(1),c.getString(2),
                        c.getLong(3),c.getString(4),c.getString(5));
            }sheets.add(correction);
            StoreExcel.Sheet cancelled=new StoreExcel.Sheet("撤销重复入库");
            cancelled.add("原入库日期","原单号","错误商品","错误条码","撤销数量","撤销金额(元)","保留条码","原因");
            try(Cursor c=helper.getReadableDatabase().rawQuery(
                    "SELECT business_date,original_document_id,product_name,barcode,base_qty_milli,"+
                    "amount_cents,kept_barcode,reason FROM stock_cancelled_inbound " +
                    "WHERE business_date>=? AND business_date<=? ORDER BY business_date,id",new String[]{start,end})){
                while(c.moveToNext())cancelled.add(c.getString(0),c.getLong(1),c.getString(2),c.getString(3),
                        q(c.getLong(4)),money(c.getLong(5)),c.getString(6),c.getString(7));
            }sheets.add(cancelled);
        }
        return sheets;
    }
}
