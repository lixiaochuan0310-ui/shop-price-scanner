package com.localpricescan.app;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** 进销存业务账本。所有数量以基础单位的千分之一存储，价格以分存储。 */
final class InventoryStore {
    static final String IN="IN", SALE="SALE", ISSUE="ISSUE", OTHER="OTHER", SALE_RETURN="SALE_RETURN", ISSUE_RETURN="ISSUE_RETURN";
    private final ProductDatabase helper;
    InventoryStore(ProductDatabase helper) { this.helper=helper; }

    static void createSchema(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS stock_settings ("+
                "barcode TEXT PRIMARY KEY NOT NULL, base_unit TEXT NOT NULL DEFAULT '件', "+
                "pack_unit TEXT NOT NULL DEFAULT '', pack_factor INTEGER NOT NULL DEFAULT 1 "+
                "CHECK(pack_factor >= 1), opening_milli INTEGER NOT NULL DEFAULT 0 "+
                "CHECK(opening_milli >= 0))");
        db.execSQL("CREATE TABLE IF NOT EXISTS stock_documents ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, business_date TEXT NOT NULL, "+
                "party TEXT NOT NULL DEFAULT '', department TEXT NOT NULL DEFAULT '', "+
                "purpose TEXT NOT NULL DEFAULT '', total_cents INTEGER NOT NULL DEFAULT 0, "+
                "paid_cents INTEGER NOT NULL DEFAULT 0, created_ms INTEGER NOT NULL, " +
                "voided INTEGER NOT NULL DEFAULT 0, source_document_id INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE IF NOT EXISTS stock_lines ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, document_id INTEGER NOT NULL, "+
                "barcode TEXT NOT NULL, product_name TEXT NOT NULL, "+
                "input_qty_milli INTEGER NOT NULL CHECK(input_qty_milli > 0), "+
                "unit_name TEXT NOT NULL, base_qty_milli INTEGER NOT NULL CHECK(base_qty_milli > 0), "+
                "unit_price_cents INTEGER NOT NULL CHECK(unit_price_cents >= 0), "+
                "amount_cents INTEGER NOT NULL CHECK(amount_cents >= 0), "+
                "FOREIGN KEY(document_id) REFERENCES stock_documents(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX IF NOT EXISTS stock_line_barcode_idx ON stock_lines(barcode)");
        db.execSQL("CREATE INDEX IF NOT EXISTS stock_doc_date_idx ON stock_documents(business_date)");
        db.execSQL("CREATE TABLE IF NOT EXISTS stock_counts ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, business_date TEXT NOT NULL, "+
                "barcode TEXT NOT NULL, product_name TEXT NOT NULL, before_milli INTEGER NOT NULL, "+
                "actual_milli INTEGER NOT NULL CHECK(actual_milli >= 0), "+
                "delta_milli INTEGER NOT NULL, note TEXT NOT NULL DEFAULT '', created_ms INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX IF NOT EXISTS stock_count_barcode_idx ON stock_counts(barcode)");
        createCancellationSchema(db);
        createRevisionSchema(db);
    }

    static void createCancellationSchema(SQLiteDatabase db) {
        // 审计留痕无外键：错误商品被删除后仍能追查原始撤销操作。
        db.execSQL("CREATE TABLE IF NOT EXISTS stock_cancelled_inbound ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, original_document_id INTEGER NOT NULL, " +
                "original_line_id INTEGER NOT NULL, business_date TEXT NOT NULL, " +
                "barcode TEXT NOT NULL, product_name TEXT NOT NULL, " +
                "base_qty_milli INTEGER NOT NULL, amount_cents INTEGER NOT NULL, " +
                "kept_barcode TEXT NOT NULL, reason TEXT NOT NULL, cancelled_ms INTEGER NOT NULL)");
    }

    static void createRevisionSchema(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS stock_doc_revisions ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, document_id INTEGER NOT NULL, " +
                "operation TEXT NOT NULL, before_json TEXT NOT NULL, after_json TEXT NOT NULL, " +
                "reason TEXT NOT NULL, updated_ms INTEGER NOT NULL)");
    }

    static final class Settings {
        final String base, pack;
        final long factor, opening;
        Settings(String base,String pack,long factor,long opening) {
            this.base=base;this.pack=pack;this.factor=factor;this.opening=opening;
        }
    }
    static final class Line {
        final String barcode, name, unit;
        final long inputMilli, baseMilli, unitPrice, amount;
        Line(String barcode,String name,String unit,long inputMilli,long baseMilli,long unitPrice,long amount) {
            this.barcode=barcode;this.name=name;this.unit=unit;this.inputMilli=inputMilli;
            this.baseMilli=baseMilli;this.unitPrice=unitPrice;this.amount=amount;
        }
    }
    static final class Document {
        final long id, total, paid, sourceId;
        final boolean voided;
        final String kind, date, party, department, purpose;
        Document(long id,String kind,String date,String party,String department,String purpose,long total,long paid,long sourceId,boolean voided) {
            this.id=id;this.kind=kind;this.date=date;this.party=party;
            this.department=department;this.purpose=purpose;this.total=total;this.paid=paid;
            this.sourceId=sourceId;this.voided=voided;
        }
    }
    static final class StockRow {
        final String barcode, name, unit;
        final long opening, incoming, sale, issue, other, adjustment, current, saleReturn, issueReturn;
        StockRow(String barcode,String name,String unit,long opening,long incoming,long sale,long issue,
                 long other,long adjustment,long saleReturn,long issueReturn) {
            this.barcode=barcode;this.name=name;this.unit=unit;this.opening=opening;this.incoming=incoming;
            this.sale=sale;this.issue=issue;this.other=other;this.adjustment=adjustment;
            this.saleReturn=saleReturn;this.issueReturn=issueReturn;
            this.current=opening+incoming+saleReturn+issueReturn-sale-issue-other+adjustment;
        }
    }

    static Long parseQty(String text) {
        if (text == null || !text.trim().matches("(?:0|[1-9][0-9]{0,8})(?:\\.[0-9]{1,3})?")) return null;
        try { return new BigDecimal(text.trim()).movePointRight(3).longValueExact(); }
        catch (ArithmeticException e) { return null; }
    }
    static String qty(long milli) { return BigDecimal.valueOf(milli,3).stripTrailingZeros().toPlainString(); }
    static String dateToday() { return new SimpleDateFormat("yyyy-MM-dd",Locale.CHINA).format(new Date()); }
    static boolean validDate(String date) {
        if (date==null || !date.matches("\\d{4}-\\d{2}-\\d{2}")) return false;
        try { SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd",Locale.CHINA);
            format.setLenient(false); return format.parse(date)!=null;
        } catch (Exception e) { return false; }
    }
    static long amount(long unitPriceCents,long inputQtyMilli) {
        if (unitPriceCents<0 || inputQtyMilli<=0) throw new IllegalArgumentException("数量或单价无效");
        return BigDecimal.valueOf(unitPriceCents).multiply(BigDecimal.valueOf(inputQtyMilli))
                .divide(BigDecimal.valueOf(1000),0,RoundingMode.HALF_UP).longValueExact();
    }

    Settings settings(String barcode) {
        try (Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT base_unit, pack_unit, pack_factor, opening_milli FROM stock_settings WHERE barcode=?",
                new String[]{barcode})) {
            if (c.moveToFirst()) return new Settings(c.getString(0),c.getString(1),c.getLong(2),c.getLong(3));
        }
        return new Settings("件","",1,0);
    }
    void saveSettings(String barcode,String base,String pack,long factor,long opening) {
        if (helper.get(barcode)==null) throw new IllegalArgumentException("商品不存在");
        if (base==null || base.trim().isEmpty() || base.length()>16 || pack==null || pack.length()>16 ||
                factor<1 || factor>1_000_000 || opening<0) throw new IllegalArgumentException("单位或库存数量无效");
        if (base.trim().equals(pack.trim()) && !pack.trim().isEmpty()) throw new IllegalArgumentException("包装单位不能与基础单位相同");
        Settings previous=settings(barcode);
        if(hasLedger(barcode) && (!previous.base.equals(base.trim()) ||
                !previous.pack.equals(pack.trim()) || previous.factor!=(pack.trim().isEmpty()?1:factor)))
            throw new IllegalArgumentException("已有业务流水，不能改变基础单位与换算比例");
        SQLiteDatabase db=helper.getWritableDatabase();db.beginTransaction();
        try{
            if(opening!=previous.opening && sum(db,"SELECT COUNT(*) FROM stock_counts WHERE barcode=?",barcode)>0)
                throw new IllegalArgumentException("已有盘点记录，期初数量不能直接追溯修改，请通过盘点记录调整");
            ContentValues v=new ContentValues();
            v.put("barcode",barcode);v.put("base_unit",base.trim());v.put("pack_unit",pack.trim());
            v.put("pack_factor",pack.trim().isEmpty()?1:factor);v.put("opening_milli",opening);
            db.insertWithOnConflict("stock_settings",null,v,SQLiteDatabase.CONFLICT_REPLACE);
            if(qtyOn(db,barcode)<0)throw new IllegalArgumentException("修改期初库存将产生负库存，未保存");
            if(sum(db,"SELECT COUNT(*) FROM stock_counts WHERE barcode=?",barcode)==0){
                java.util.Set<String> check=new java.util.HashSet<>();check.add(barcode);
                verifyTimelines(db,check);
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    boolean hasLedger(String barcode) {
        try (Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT (SELECT count(*) FROM stock_lines WHERE barcode=?) + "+
                "(SELECT count(*) FROM stock_counts WHERE barcode=?)",
                new String[]{barcode,barcode})) {return c.moveToFirst() && c.getLong(0)>0;}
    }
    /** 仅限误创建的商品：它必须只有入库记录、无期初、无出库及盘点。 */
    static final class DuplicatePreview {
        final int entries;
        final long inboundMilli, totalCents;
        final String baseUnit;
        DuplicatePreview(int entries,long inboundMilli,long totalCents,String baseUnit) {
            this.entries=entries;this.inboundMilli=inboundMilli;this.totalCents=totalCents;this.baseUnit=baseUnit;
        }
    }
    private static DuplicatePreview inspectDuplicate(SQLiteDatabase db,String wrong,String keep) {
        if(wrong==null || keep==null || wrong.equals(keep))
            throw new IllegalArgumentException("请选择两条不同的商品记录");
        try(Cursor c=db.rawQuery("SELECT count(*) FROM products WHERE barcode IN (?,?)",new String[]{wrong,keep})) {
            if(!c.moveToFirst() || c.getInt(0)!=2)
                throw new IllegalArgumentException("保留商品或重复商品已不存在");
        }
        if(sum(db,"SELECT COALESCE(opening_milli,0) FROM stock_settings WHERE barcode=?",wrong)!=0)
            throw new IllegalStateException("重复商品登记了期初库存，不能自动清理");
        if(sum(db,"SELECT count(*) FROM stock_counts WHERE barcode=?",wrong)>0)
            throw new IllegalStateException("重复商品已有盘点记录，不能自动清理");
        try(Cursor c=db.rawQuery("SELECT count(*) FROM stock_lines l "+
                "JOIN stock_documents d ON d.id=l.document_id "+
                "WHERE l.barcode=? AND (d.kind<>'IN' OR d.voided<>0)",new String[]{wrong})) {
            if(c.moveToFirst() && c.getLong(0)>0)
                throw new IllegalStateException("重复商品已有销售、领用或其他出库记录，不能自动清理");
        }
        long count=0,qty=0,amount=0;
        try(Cursor c=db.rawQuery("SELECT count(*),COALESCE(SUM(l.base_qty_milli),0),"+
                "COALESCE(SUM(l.amount_cents),0) FROM stock_lines l "+
                "JOIN stock_documents d ON d.id=l.document_id "+
                "WHERE l.barcode=? AND d.kind='IN' AND d.voided=0",new String[]{wrong})) {
            if(c.moveToFirst()){count=c.getLong(0);qty=c.getLong(1);amount=c.getLong(2);}
        }
        if(count==0)throw new IllegalArgumentException("这条商品没有可撤销的入库记录，请使用普通删除");
        if(count>Integer.MAX_VALUE || qty<=0 || qtyOn(db,wrong)!=qty)
            throw new IllegalStateException("重复商品库存账目存在异常，请先核实，未执行删除");
        String unit="件";
        try(Cursor c=db.rawQuery("SELECT base_unit FROM stock_settings WHERE barcode=?",new String[]{wrong})) {
            if(c.moveToFirst())unit=c.getString(0);
        }
        return new DuplicatePreview((int)count,qty,amount,unit);
    }
    DuplicatePreview previewDuplicate(String wrong,String keep) {
        return inspectDuplicate(helper.getReadableDatabase(),wrong,keep);
    }

    /** 原子撤销错误入库并删除重复商品；同一单据中的其他商品保持不变。 */
    void removeDuplicateInboundProduct(String wrong,String keep) {
        SQLiteDatabase db=helper.getWritableDatabase();
        db.beginTransaction();
        try {
            inspectDuplicate(db,wrong,keep); // 提交前再检查，拒绝条件变化的账目。
            List<Long> affectedDocs=new ArrayList<>();
            long when=System.currentTimeMillis();
            try(Cursor c=db.rawQuery("SELECT l.id,l.document_id,d.business_date,l.product_name,"+
                    "l.base_qty_milli,l.amount_cents FROM stock_lines l "+
                    "JOIN stock_documents d ON d.id=l.document_id "+
                    "WHERE l.barcode=? AND d.kind='IN' AND d.voided=0 ORDER BY l.id",new String[]{wrong})) {
                while(c.moveToNext()) {
                    ContentValues audit=new ContentValues();
                    audit.put("original_line_id",c.getLong(0));
                    audit.put("original_document_id",c.getLong(1));
                    audit.put("business_date",c.getString(2));
                    audit.put("barcode",wrong);audit.put("product_name",c.getString(3));
                    audit.put("base_qty_milli",c.getLong(4));
                    audit.put("amount_cents",c.getLong(5));
                    audit.put("kept_barcode",keep);
                    audit.put("reason","重复登记同一批货，撤销错误入库");
                    audit.put("cancelled_ms",when);
                    db.insertOrThrow("stock_cancelled_inbound",null,audit);
                    if(!affectedDocs.contains(c.getLong(1)))affectedDocs.add(c.getLong(1));
                }
            }
            if(sum(db,"SELECT COUNT(*) FROM stock_doc_revisions WHERE before_json LIKE ?", "%\"barcode\":\""+wrong+"\"%")>0)
                throw new IllegalStateException("重复商品关联已修改单据，请先核对流水，不能自动清理");
            db.delete("stock_lines","barcode=?",new String[]{wrong});
            for(Long docId:affectedDocs) {
                String[] arg={Long.toString(docId)};
                long remaining;
                try(Cursor c=db.rawQuery("SELECT count(*) FROM stock_lines WHERE document_id=?",arg)) {
                    remaining=c.moveToFirst()?c.getLong(0):0;
                }
                if(remaining==0)db.delete("stock_documents","id=?",arg);
                else {
                    long total;
                    try(Cursor c=db.rawQuery("SELECT COALESCE(SUM(amount_cents),0) "+
                            "FROM stock_lines WHERE document_id=?",arg)) {
                        total=c.moveToFirst()?c.getLong(0):0;
                    }
                    ContentValues v=new ContentValues();v.put("total_cents",total);
                    db.update("stock_documents",v,"id=?",arg);
                }
            }
            db.delete("product_images","barcode=?",new String[]{wrong});
            db.delete("stock_settings","barcode=?",new String[]{wrong});
            if(db.delete("products","barcode=?",new String[]{wrong})!=1)
                throw new IllegalStateException("删除重复商品失败，所有更改已取消");
            db.setTransactionSuccessful();
        } finally {db.endTransaction();}
    }

    private static long sum(SQLiteDatabase db,String sql,String barcode) {
        try (Cursor c=db.rawQuery(sql,new String[]{barcode})) {return c.moveToFirst() ? c.getLong(0):0;}
    }
    private static long qtyOn(SQLiteDatabase db,String barcode) {
        long opening=sum(db,"SELECT COALESCE(opening_milli,0) FROM stock_settings WHERE barcode=?",barcode);
        long ledger=sum(db,"SELECT COALESCE(SUM(CASE WHEN d.kind='IN' THEN l.base_qty_milli "+
                "WHEN d.kind IN ('SALE_RETURN','ISSUE_RETURN') THEN l.base_qty_milli "+
                "ELSE -l.base_qty_milli END),0) FROM stock_lines l "+
                "JOIN stock_documents d ON d.id=l.document_id WHERE l.barcode=? AND d.voided=0",barcode);
        long adjust=sum(db,"SELECT COALESCE(SUM(delta_milli),0) FROM stock_counts WHERE barcode=?",barcode);
        return Math.addExact(Math.addExact(opening,ledger),adjust);
    }
    long current(String barcode) { return qtyOn(helper.getReadableDatabase(),barcode); }

    /** 一次 SQL 汇总库存，避免商品较多时逐件查询导致页面卡顿。 */
    List<StockRow> stocks() {
        List<StockRow> rows=new ArrayList<>();
        String sql="SELECT p.barcode,p.name,COALESCE(s.base_unit,'件'),"+
                "COALESCE(s.opening_milli,0),COALESCE(m.incoming,0),COALESCE(m.sold,0),"+
                "COALESCE(m.issued,0),COALESCE(m.other_out,0),COALESCE(a.adjusted,0),"+
                "COALESCE(m.sale_return,0),COALESCE(m.issue_return,0) " +
                "FROM products p LEFT JOIN stock_settings s ON s.barcode=p.barcode " +
                "LEFT JOIN (SELECT l.barcode,"+
                "SUM(CASE WHEN d.kind='IN' THEN l.base_qty_milli ELSE 0 END) incoming,"+
                "SUM(CASE WHEN d.kind='SALE' THEN l.base_qty_milli ELSE 0 END) sold,"+
                "SUM(CASE WHEN d.kind='ISSUE' THEN l.base_qty_milli ELSE 0 END) issued,"+
                "SUM(CASE WHEN d.kind='OTHER' THEN l.base_qty_milli ELSE 0 END) other_out,"+
                "SUM(CASE WHEN d.kind='SALE_RETURN' THEN l.base_qty_milli ELSE 0 END) sale_return,"+
                "SUM(CASE WHEN d.kind='ISSUE_RETURN' THEN l.base_qty_milli ELSE 0 END) issue_return " +
                "FROM stock_lines l JOIN stock_documents d ON d.id=l.document_id " +
                "WHERE d.voided=0 GROUP BY l.barcode) m ON m.barcode=p.barcode " +
                "LEFT JOIN (SELECT barcode,SUM(delta_milli) adjusted FROM stock_counts GROUP BY barcode) a " +
                "ON a.barcode=p.barcode ORDER BY p.name COLLATE NOCASE,p.barcode";
        try(Cursor c=helper.getReadableDatabase().rawQuery(sql,null)) {
            while(c.moveToNext()) rows.add(new StockRow(c.getString(0),c.getString(1),c.getString(2),
                    c.getLong(3),c.getLong(4),c.getLong(5),c.getLong(6),c.getLong(7),c.getLong(8),c.getLong(9),c.getLong(10)));
        }
        return rows;
    }

    static String kindName(String kind) {
        switch(kind) {case IN:return "商品入库";case SALE:return "商品销售";
            case ISSUE:return "内部领用";case OTHER:return "其他出库";
            case SALE_RETURN:return "销售退货";case ISSUE_RETURN:return "领用退库";default:return kind;}
    }
    /** 将一整张多商品单据原子提交；出库库存不足则全部回滚。 */
    long saveDocument(String kind,String date,String party,String department,String purpose,
                      List<Line> lines,long actualPaid) {
        if (!IN.equals(kind) && !SALE.equals(kind) && !ISSUE.equals(kind) && !OTHER.equals(kind))
            throw new IllegalArgumentException("未知单据类型");
        if (!validDate(date) || lines==null || lines.isEmpty()) throw new IllegalArgumentException("日期或商品明细无效");
        if (ISSUE.equals(kind) && (party.trim().isEmpty() || department.trim().isEmpty() || purpose.trim().isEmpty()))
            throw new IllegalArgumentException("请填写领用人、部门/工程和领用用途");
        if (actualPaid<0) throw new IllegalArgumentException("实收金额无效");
        long total=0;
        for(Line line:lines) {
            if (line.baseMilli<=0 || line.inputMilli<=0 || line.unitPrice<0 || line.amount<0 ||
                    helper.get(line.barcode)==null) throw new IllegalArgumentException("商品明细无效");
            total=Math.addExact(total,line.amount);
        }
        SQLiteDatabase db=helper.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues doc=new ContentValues();
            doc.put("kind",kind);doc.put("business_date",date);doc.put("party",party.trim());
            doc.put("department",department.trim());doc.put("purpose",purpose.trim());
            doc.put("total_cents",total);doc.put("paid_cents",SALE.equals(kind)?actualPaid:0);
            doc.put("created_ms",System.currentTimeMillis());
            long docId=db.insertOrThrow("stock_documents",null,doc);
            for(Line l:lines) {
                try(Cursor count=db.rawQuery("SELECT MAX(business_date) FROM stock_counts WHERE barcode=?",new String[]{l.barcode})){
                    if(count.moveToFirst()&&!count.isNull(0)&&date.compareTo(count.getString(0))<=0)
                        throw new IllegalArgumentException("商品已有该日期之后的盘点，不能倒填这张业务单："+l.name);
                }
                ContentValues row=new ContentValues();
                row.put("document_id",docId);row.put("barcode",l.barcode);
                row.put("product_name",l.name);row.put("input_qty_milli",l.inputMilli);
                row.put("unit_name",l.unit);row.put("base_qty_milli",l.baseMilli);
                row.put("unit_price_cents",l.unitPrice);row.put("amount_cents",l.amount);
                db.insertOrThrow("stock_lines",null,row);
                if (!IN.equals(kind) && qtyOn(db,l.barcode)<0)
                    throw new IllegalArgumentException("库存不足："+l.name+"，本单未保存");
            }
            java.util.Set<String> affected=new java.util.HashSet<>();
            for(Line line:lines)affected.add(line.barcode);
            // 对时间倒填的单据也检查历史各节点不会出现负库存。
            // 已有盘点的商品不在此处重新推算盘点前历史，以免误判。
            boolean hasCounts=false;
            for(String code:affected)if(sum(db,"SELECT COUNT(*) FROM stock_counts WHERE barcode=?",code)>0)hasCounts=true;
            if(!hasCounts)verifyTimelines(db,affected);
            db.setTransactionSuccessful();
            return docId;
        } finally {db.endTransaction();}
    }
    /** 盘点按保存瞬间库存计算差额，原子记录，不覆写历史流水。 */
    void count(String barcode,String date,long actualMilli,String note) {
        if (!validDate(date) || actualMilli<0) throw new IllegalArgumentException("日期或实盘数量无效");
        ProductDatabase.Product p=helper.get(barcode);
        if (p==null) throw new IllegalArgumentException("商品不存在");
        SQLiteDatabase db=helper.getWritableDatabase();
        db.beginTransaction();
        try {
            try(Cursor c=db.rawQuery("SELECT MAX(d.business_date) FROM stock_lines l " +
                    "JOIN stock_documents d ON d.id=l.document_id " +
                    "WHERE l.barcode=? AND d.voided=0",new String[]{barcode})){
                if(c.moveToFirst()&&!c.isNull(0)&&date.compareTo(c.getString(0))<0)
                    throw new IllegalArgumentException("该日期之后已有出入库记录，不能倒填盘点日期");
            }
            try(Cursor c=db.rawQuery("SELECT MAX(business_date) FROM stock_counts WHERE barcode=?",new String[]{barcode})){
                if(c.moveToFirst()&&!c.isNull(0)&&date.compareTo(c.getString(0))<0)
                    throw new IllegalArgumentException("该日期之后已有盘点，不能倒填盘点日期");
            }
            long before=qtyOn(db,barcode);
            long difference=Math.subtractExact(actualMilli,before);
            ContentValues v=new ContentValues();v.put("business_date",date);v.put("barcode",barcode);
            v.put("product_name",p.name);v.put("before_milli",before);v.put("actual_milli",actualMilli);
            v.put("delta_milli",difference);v.put("note",note.trim());v.put("created_ms",System.currentTimeMillis());
            db.insertOrThrow("stock_counts",null,v);
            db.setTransactionSuccessful();
        } finally {db.endTransaction();}
    }
    List<Document> documents() {
        List<Document> docs=new ArrayList<>();
        try(Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT id,kind,business_date,party,department,purpose,total_cents,paid_cents,source_document_id,voided " +
                        "FROM stock_documents ORDER BY business_date DESC,id DESC",null)) {
            while(c.moveToNext()) docs.add(new Document(c.getLong(0),c.getString(1),c.getString(2),
                    c.getString(3),c.getString(4),c.getString(5),c.getLong(6),c.getLong(7),c.getLong(8),c.getInt(9)!=0));
        }
        return docs;
    }
    List<Line> lines(long documentId) {
        List<Line> rows=new ArrayList<>();
        try(Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT barcode,product_name,unit_name,input_qty_milli,base_qty_milli,unit_price_cents,amount_cents " +
                        "FROM stock_lines WHERE document_id=? ORDER BY id",new String[]{Long.toString(documentId)})) {
            while(c.moveToNext()) rows.add(new Line(c.getString(0),c.getString(1),c.getString(2),
                    c.getLong(3),c.getLong(4),c.getLong(5),c.getLong(6)));
        }
        return rows;
    }
    long[] salesSummary(String prefix) {
        long[] out={0,0,0};
        try(Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT count(*),COALESCE(SUM(total_cents),0),COALESCE(SUM(paid_cents),0) "+
                "FROM stock_documents WHERE kind='SALE' AND voided=0 AND business_date LIKE ?",new String[]{prefix+"%"})) {
            if(c.moveToFirst()) {out[0]=c.getLong(0);out[1]=c.getLong(1);out[2]=c.getLong(2);}
        }
        try(Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT COALESCE(SUM(total_cents),0),COALESCE(SUM(paid_cents),0) " +
                "FROM stock_documents WHERE kind='SALE_RETURN' AND voided=0 AND business_date LIKE ?",
                new String[]{prefix+"%"})) {
            if(c.moveToFirst()) {out[1]-=c.getLong(0);out[2]-=c.getLong(1);}
        }
        return out;
    }
    /** 每次改单、作废、退货都在单个事务中执行，并记录可审计快照。 */
    Document getDocument(long id) {
        try(Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT id,kind,business_date,party,department,purpose,total_cents,paid_cents,source_document_id,voided " +
                "FROM stock_documents WHERE id=?",new String[]{Long.toString(id)})) {
            if(!c.moveToFirst())return null;
            return new Document(c.getLong(0),c.getString(1),c.getString(2),c.getString(3),
                    c.getString(4),c.getString(5),c.getLong(6),c.getLong(7),c.getLong(8),c.getInt(9)!=0);
        }
    }
    private static long delta(String kind,long qty) {
        return IN.equals(kind)||SALE_RETURN.equals(kind)||ISSUE_RETURN.equals(kind) ? qty : -qty;
    }
    private static void requireNoCounts(SQLiteDatabase db,java.util.Set<String> codes) {
        for(String code:codes) if(sum(db,"SELECT COUNT(*) FROM stock_counts WHERE barcode=?",code)>0)
            throw new IllegalStateException("商品已有盘点记录，请先核实盘点后库存，不能直接改单或作废："+code);
    }
    private static void verifyTimelines(SQLiteDatabase db,java.util.Set<String> codes) {
        for(String barcode:codes){
            long quantity=sum(db,"SELECT COALESCE(opening_milli,0) FROM stock_settings WHERE barcode=?",barcode);
            try(Cursor c=db.rawQuery("SELECT d.kind,l.base_qty_milli FROM stock_lines l " +
                    "JOIN stock_documents d ON d.id=l.document_id WHERE l.barcode=? AND d.voided=0 " +
                    "ORDER BY d.business_date,d.created_ms,d.id,l.id",new String[]{barcode})) {
                while(c.moveToNext()){
                    quantity=Math.addExact(quantity,delta(c.getString(0),c.getLong(1)));
                    if(quantity<0)throw new IllegalArgumentException("改单后将导致历史负库存，未保存："+barcode);
                }
            }
            if(quantity<0)throw new IllegalArgumentException("库存不足："+barcode);
        }
    }
    private static org.json.JSONObject snapshot(SQLiteDatabase db,long id) {
        org.json.JSONObject snap=new org.json.JSONObject();
        try {
            try(Cursor c=db.rawQuery("SELECT kind,business_date,party,department,purpose,total_cents,"+
                    "paid_cents,voided,source_document_id FROM stock_documents WHERE id=?",new String[]{Long.toString(id)})){
                if(!c.moveToFirst())throw new IllegalArgumentException("单据不存在");
                snap.put("kind",c.getString(0));snap.put("date",c.getString(1));
                snap.put("party",c.getString(2));snap.put("department",c.getString(3));
                snap.put("purpose",c.getString(4));snap.put("total",c.getLong(5));
                snap.put("paid",c.getLong(6));snap.put("voided",c.getInt(7));snap.put("source_id",c.getLong(8));
            }
            org.json.JSONArray rows=new org.json.JSONArray();
            try(Cursor c=db.rawQuery("SELECT barcode,product_name,input_qty_milli,unit_name,base_qty_milli,"+
                    "unit_price_cents,amount_cents FROM stock_lines WHERE document_id=? ORDER BY id",new String[]{Long.toString(id)})){
                while(c.moveToNext()){
                    org.json.JSONObject row=new org.json.JSONObject();
                    row.put("barcode",c.getString(0));row.put("name",c.getString(1));
                    row.put("qty",c.getLong(2));row.put("unit",c.getString(3));
                    row.put("base_qty",c.getLong(4));row.put("price",c.getLong(5));row.put("amount",c.getLong(6));
                    rows.put(row);
                }
            }
            snap.put("lines",rows);
        }catch(org.json.JSONException e){throw new IllegalStateException("生成审计记录失败",e);}
        return snap;
    }
    private static void audit(SQLiteDatabase db,long id,String op,String before,String after,String reason) {
        ContentValues v=new ContentValues();v.put("document_id",id);v.put("operation",op);
        v.put("before_json",before);v.put("after_json",after);
        v.put("reason",reason);v.put("updated_ms",System.currentTimeMillis());
        db.insertOrThrow("stock_doc_revisions",null,v);
    }
    private static void addLine(SQLiteDatabase db,long docId,Line l) {
        ContentValues row=new ContentValues();row.put("document_id",docId);row.put("barcode",l.barcode);
        row.put("product_name",l.name);row.put("input_qty_milli",l.inputMilli);
        row.put("unit_name",l.unit);row.put("base_qty_milli",l.baseMilli);
        row.put("unit_price_cents",l.unitPrice);row.put("amount_cents",l.amount);
        db.insertOrThrow("stock_lines",null,row);
    }
    private void validateEditLines(List<Line> rows) {
        if(rows==null||rows.isEmpty())throw new IllegalArgumentException("至少需要一项商品");
        for(Line l:rows)if(l.inputMilli<=0||l.baseMilli<=0||l.amount<0||l.unitPrice<0||helper.get(l.barcode)==null)
            throw new IllegalArgumentException("单据商品明细无效");
    }
    /** 编辑原单时保留单号，改动及修改前明细均留审计历史。 */
    void reviseDocument(long id,String date,String party,String department,String purpose,List<Line> rows,long paid,String reason) {
        Document old=getDocument(id);
        if(old==null||old.voided||old.sourceId!=0)throw new IllegalArgumentException("原单据已作废或属于退货单，不能直接编辑");
        if(!validDate(date)||reason==null||reason.trim().isEmpty())throw new IllegalArgumentException("请输入有效日期和修改原因");
        if(ISSUE.equals(old.kind)&&(party.trim().isEmpty()||department.trim().isEmpty()||purpose.trim().isEmpty()))
            throw new IllegalArgumentException("领用人、工程和用途不能为空");
        validateEditLines(rows);
        if(paid<0)throw new IllegalArgumentException("实收金额不能小于0");
        SQLiteDatabase db=helper.getWritableDatabase();db.beginTransaction();
        try{
            if(sum(db,"SELECT COUNT(*) FROM stock_documents WHERE source_document_id=? AND voided=0",Long.toString(id))>0)
                throw new IllegalArgumentException("原单有有效退货或退库记录，不能直接修改，请先处理退货单");
            java.util.Set<String> affected=new java.util.HashSet<>();
            for(Line l:lines(id))affected.add(l.barcode);
            for(Line l:rows)affected.add(l.barcode);
            requireNoCounts(db,affected);
            String before=snapshot(db,id).toString();
            long total=0;for(Line l:rows)total=Math.addExact(total,l.amount);
            ContentValues update=new ContentValues();update.put("business_date",date);
            update.put("party",party.trim());update.put("department",department.trim());
            update.put("purpose",purpose.trim());update.put("total_cents",total);
            update.put("paid_cents",SALE.equals(old.kind)?paid:0);
            db.update("stock_documents",update,"id=?",new String[]{Long.toString(id)});
            db.delete("stock_lines","document_id=?",new String[]{Long.toString(id)});
            for(Line l:rows)addLine(db,id,l);
            verifyTimelines(db,affected);
            audit(db,id,"EDIT",before,snapshot(db,id).toString(),reason.trim());
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    void voidDocument(long id,String reason){
        Document doc=getDocument(id);
        if(doc==null||doc.voided)throw new IllegalArgumentException("单据不存在或已经作废");
        if(reason==null||reason.trim().isEmpty())throw new IllegalArgumentException("请填写作废原因");
        SQLiteDatabase db=helper.getWritableDatabase();db.beginTransaction();
        try {
            if(sum(db,"SELECT COUNT(*) FROM stock_documents WHERE source_document_id=? AND voided=0",Long.toString(id))>0)
                throw new IllegalArgumentException("该单有有效退货或退库，不能先作废原单");
            java.util.Set<String> affected=new java.util.HashSet<>();for(Line l:lines(id))affected.add(l.barcode);
            requireNoCounts(db,affected);
            String before=snapshot(db,id).toString();
            ContentValues v=new ContentValues();v.put("voided",1);
            db.update("stock_documents",v,"id=?",new String[]{Long.toString(id)});
            verifyTimelines(db,affected);
            audit(db,id,"VOID",before,snapshot(db,id).toString(),reason.trim());
            db.setTransactionSuccessful();
        }finally {db.endTransaction();}
    }
    /** 退货/退库必须关联有效原单，不能超过原单未退回的数量。 */
    long createReturn(long originalId,String date,List<Line> requested,long refundCents,String note) {
        if(!validDate(date)||requested==null||requested.isEmpty())throw new IllegalArgumentException("日期或退回商品无效");
        SQLiteDatabase db=helper.getWritableDatabase();db.beginTransaction();
        try {
            Document source=getDocument(originalId);
            if(source==null||source.voided||(!SALE.equals(source.kind)&&!ISSUE.equals(source.kind)))
                throw new IllegalArgumentException("只允许从有效销售单或内部领用单办理退回");
            if(date.compareTo(source.date)<0)
                throw new IllegalArgumentException("退回日期不能早于原销售或领用日期");
            java.util.Map<String,Line> originals=new java.util.HashMap<>();
            for(Line l:lines(source.id))originals.put(l.barcode,l);
            java.util.Set<String> used=new java.util.HashSet<>();long total=0;
            for(Line l:requested){
                Line origin=originals.get(l.barcode);
                if(origin==null||l.baseMilli<=0||l.inputMilli<=0||!used.add(l.barcode))
                    throw new IllegalArgumentException("退回数量或原商品不正确");
                if(!java.math.BigInteger.valueOf(l.baseMilli).multiply(java.math.BigInteger.valueOf(origin.inputMilli))
                        .equals(java.math.BigInteger.valueOf(l.inputMilli).multiply(java.math.BigInteger.valueOf(origin.baseMilli))))
                    throw new IllegalArgumentException("退回数量的单位换算与原单不符");
                if(!l.unit.equals(origin.unit)||l.unitPrice!=origin.unitPrice)
                    throw new IllegalArgumentException("退货单位和原销售/领用单不一致");
                long already=0;
                try(Cursor c=db.rawQuery("SELECT COALESCE(SUM(x.base_qty_milli),0) FROM stock_lines x " +
                        "JOIN stock_documents d ON d.id=x.document_id WHERE d.source_document_id=? " +
                        "AND d.voided=0 AND x.barcode=?",new String[]{Long.toString(originalId),l.barcode})) {
                    if(c.moveToFirst())already=c.getLong(0);
                }
                try(Cursor c=db.rawQuery("SELECT MAX(business_date) FROM stock_counts WHERE barcode=?",new String[]{l.barcode})){
                    if(c.moveToFirst()&&!c.isNull(0)&&date.compareTo(c.getString(0))<=0)
                        throw new IllegalArgumentException("退回日期不能早于或等于该商品已有盘点日期");
                }
                if(Math.addExact(already,l.baseMilli)>origin.baseMilli)
                    throw new IllegalArgumentException("退回数量超过原单未退数量："+origin.name);
                total=Math.addExact(total,l.amount);
            }
            if(refundCents<0)throw new IllegalArgumentException("实际退款金额不能为负数");
            String type=SALE.equals(source.kind)?SALE_RETURN:ISSUE_RETURN;
            ContentValues d=new ContentValues();d.put("kind",type);d.put("business_date",date);
            d.put("party",source.party);d.put("department",source.department);
            d.put("purpose",note==null?"":note.trim());d.put("total_cents",total);
            d.put("paid_cents",SALE.equals(source.kind)?refundCents:0);
            d.put("source_document_id",originalId);d.put("created_ms",System.currentTimeMillis());
            long id=db.insertOrThrow("stock_documents",null,d);
            for(Line l:requested)addLine(db,id,l);
            java.util.Set<String> affected=new java.util.HashSet<>();for(Line l:requested)affected.add(l.barcode);
            verifyTimelines(db,affected);
            db.setTransactionSuccessful();return id;
        }finally{db.endTransaction();}
    }

}
