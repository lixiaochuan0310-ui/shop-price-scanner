package com.localpricescan.app;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Word .docx 标准 OOXML：宽表转为逐记录双列表格，保持字段和值完整换行。 */
final class StoreWord {
    private StoreWord(){}
    private static String escape(String t){
        if(t==null)return "";
        StringBuilder b=new StringBuilder();
        for(int i=0;i<t.length();i++){
            char c=t.charAt(i);
            switch(c){case '&':b.append("&amp;");break;case '<':b.append("&lt;");break;
                case '>':b.append("&gt;");break;case '"':b.append("&quot;");break;
                default:if(c==9||c==10||c==13||c>=32)b.append(c);
            }
        }return b.toString();
    }
    private static void entry(ZipOutputStream out,String name,String value)throws IOException{
        out.putNextEntry(new ZipEntry(name));out.write(value.getBytes(StandardCharsets.UTF_8));out.closeEntry();
    }
    private static String p(String text,boolean heading){
        StringBuilder b=new StringBuilder("<w:p><w:pPr>");
        if(heading)b.append("<w:keepNext/><w:spacing w:before=\"180\" w:after=\"80\"/>");
        b.append("</w:pPr><w:r><w:rPr><w:rFonts w:eastAsia=\"SimSun\"/>");
        if(heading)b.append("<w:b/><w:sz w:val=\"24\"/>");
        else b.append("<w:sz w:val=\"20\"/>");
        b.append("</w:rPr>");
        String[] parts=(text==null?"":text).split("\\n",-1);
        for(int i=0;i<parts.length;i++){
            if(i>0)b.append("<w:br/>");
            b.append("<w:t xml:space=\"preserve\">").append(escape(parts[i])).append("</w:t>");
        }
        return b.append("</w:r></w:p>").toString();
    }
    private static String cell(String text,int width,boolean label){
        return "<w:tc><w:tcPr><w:tcW w:w=\""+width+"\" w:type=\"dxa\"/>"+
                (label?"<w:shd w:fill=\"E6F3E9\"/>":"")+"</w:tcPr>"+p(text,false)+"</w:tc>";
    }
    private static String tableFor(StoreExcel.Sheet sheet,List<Object> record){
        StringBuilder b=new StringBuilder("<w:tbl><w:tblPr><w:tblW w:w=\"10300\" w:type=\"dxa\"/>"+
                "<w:tblBorders><w:top w:val=\"single\" w:sz=\"4\" w:color=\"BED2C4\"/>"+
                "<w:left w:val=\"single\" w:sz=\"4\" w:color=\"BED2C4\"/>"+
                "<w:bottom w:val=\"single\" w:sz=\"4\" w:color=\"BED2C4\"/>"+
                "<w:right w:val=\"single\" w:sz=\"4\" w:color=\"BED2C4\"/>"+
                "<w:insideH w:val=\"single\" w:sz=\"3\" w:color=\"DFE8E2\"/>"+
                "</w:tblBorders></w:tblPr><w:tblGrid><w:gridCol w:w=\"3000\"/><w:gridCol w:w=\"7300\"/></w:tblGrid>");
        List<Object> header=sheet.rows.get(0);
        for(int i=0;i<header.size();i++){
            String key=header.get(i)==null?"":header.get(i).toString();
            String value=i<record.size()&&record.get(i)!=null?record.get(i).toString():"";
            b.append("<w:tr>").append(cell(key,3000,true)).append(cell(value,7300,false)).append("</w:tr>");
        }
        return b.append("</w:tbl>").toString();
    }
    static void write(OutputStream output,String title,List<StoreExcel.Sheet> sheets)throws IOException{
        if(sheets.isEmpty())throw new IOException("没有报表数据");
        StringBuilder doc=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"+
                "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>");
        doc.append(p("门市进销存 · "+title,true));
        for(StoreExcel.Sheet sheet:sheets){
            doc.append(p(sheet.name,true));
            if(sheet.rows.size()<=1){doc.append(p("本次统计期间暂无记录。",false));continue;}
            for(int i=1;i<sheet.rows.size();i++){
                if(sheet.rows.size()>2)doc.append(p("记录 "+i,false));
                doc.append(tableFor(sheet,sheet.rows.get(i)));
                doc.append(p("",false));
            }
        }
        doc.append("<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>"+
                "<w:pgMar w:top=\"800\" w:right=\"720\" w:bottom=\"800\" w:left=\"720\"/>"+
                "</w:sectPr></w:body></w:document>");
        ZipOutputStream zip=new ZipOutputStream(output);
        entry(zip,"[Content_Types].xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"+
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"+
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"+
                "<Override PartName=\"/word/document.xml\" " +
                "ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>"+
                "</Types>");
        entry(zip,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"+
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>"+
                "</Relationships>");
        entry(zip,"word/document.xml",doc.toString());zip.finish();zip.flush();
    }
}
