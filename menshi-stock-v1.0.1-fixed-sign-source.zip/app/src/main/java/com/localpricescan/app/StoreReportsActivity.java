package com.localpricescan.app;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.Calendar;
import java.util.Locale;

/** 按日/月/年选择报表范围，先看预览，再决定 Excel 还是 Word。 */
public final class StoreReportsActivity extends SwipeBackActivity {
    private ProductDatabase db;private InventoryStore store;
    private Spinner period,category;private EditText term;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);db=new ProductDatabase(this);store=new InventoryStore(db);
        LinearLayout root=StoreUi.content(this,"统计报表");setContentView(root);
        LinearLayout body=StoreUi.padded(this,StoreUi.scroll(this,root));
        String today=InventoryStore.dateToday();
        salesCard(body,"今日销售 · "+today,store.salesSummary(today));
        salesCard(body,"本月销售 · "+today.substring(0,7),store.salesSummary(today.substring(0,7)));
        LinearLayout box=StoreUi.card(this);StoreUi.addCard(body,box);
        box.addView(StoreUi.text(this,"筛选并导出业务报表",18,true));StoreUi.gap(box,12);
        StoreUi.label(box,"1. 选择统计时间：某日 / 某月 / 某年");
        period=selector(new String[]{"某一日","某一月","某一年"});box.addView(period);StoreUi.gap(box,12);
        StoreUi.label(box,"选择具体日期（点击更改）");
        term=StoreUi.input(this,"选择日期",today,1);term.setFocusable(false);
        term.setOnClickListener(v->pickDate());box.addView(term);StoreUi.gap(box,12);
        StoreUi.label(box,"2. 选择统计内容");
        category=selector(new String[]{"全部业务数据","销售数据","库存数据","内部领用数据"});
        box.addView(category);StoreUi.gap(box,12);
        TextView note=StoreUi.text(this,"库存数据采用所选期间的期初、期间入库／销售／退货／领用／退库／出库／盘点和期末库存。",13,false);
        note.setTextColor(StoreUi.MUTED);box.addView(note);StoreUi.gap(box,14);
        TextView preview=StoreUi.button(this,"预览所选报表，选择 Word / Excel 导出",StoreUi.GREEN,0xffffffff);
        box.addView(preview);preview.setOnClickListener(v->openPreview());
        period.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> parent,android.view.View v,int pos,long id){
                String current=InventoryStore.dateToday();
                term.setText(pos==0?current:pos==1?current.substring(0,7):current.substring(0,4));
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent){}
        });
        LinearLayout record=StoreUi.card(this);StoreUi.addCard(body,record);
        TextView all=StoreUi.button(this,"查看全部业务流水（可修改、作废、退货和退库）",0xffe0f2e8,StoreUi.GREEN);
        all.setTextSize(14);record.addView(all);
        all.setOnClickListener(v->startActivity(new Intent(this,StoreRecordsActivity.class)));
    }
    private Spinner selector(String[] labels){
        Spinner spinner=new Spinner(this);
        spinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));
        return spinner;
    }
    private void salesCard(LinearLayout body,String heading,long[] totals){
        LinearLayout card=StoreUi.card(this);StoreUi.addCard(body,card);
        card.addView(StoreUi.text(this,heading,17,true));StoreUi.gap(card,8);
        TextView t=StoreUi.text(this,"销售单数："+totals[0]+" 单\n净销售总额："+Money.show(totals[1])+
                "\n净实收金额："+Money.show(totals[2]),15,false);
        t.setLineSpacing(StoreUi.d(this,2),1f);card.addView(t);
    }
    private void pickDate(){
        Calendar c=Calendar.getInstance();
        new DatePickerDialog(this,(view,y,m,d)->{
            String result=String.format(Locale.ROOT,"%04d-%02d-%02d",y,m+1,d);
            int mode=period.getSelectedItemPosition();
            term.setText(mode==0?result:mode==1?result.substring(0,7):result.substring(0,4));
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }
    private void openPreview(){
        String[] times={"day","month","year"};String[] kinds={"all","sales","stock","issue"};
        int t=period.getSelectedItemPosition(),k=category.getSelectedItemPosition();
        try{
            StoreReportData test=new StoreReportData(db,times[t],kinds[k],StoreUi.value(term));
            Intent intent=new Intent(this,StoreReportPreviewActivity.class);
            intent.putExtra("period",times[t]);intent.putExtra("category",kinds[k]);
            intent.putExtra("term",test.term);startActivity(intent);
        }catch(Exception e){new android.app.AlertDialog.Builder(this).setTitle("统计条件不正确")
                .setMessage(e.getMessage()).setPositiveButton("确定",null).show();}
    }
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
