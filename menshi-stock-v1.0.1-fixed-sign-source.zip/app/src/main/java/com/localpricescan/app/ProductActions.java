package com.localpricescan.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 列表和详情共用相同的长按操作与删除确认。 */
final class ProductActions {
    private ProductActions() {}
    static void menu(Activity activity,ProductDatabase db,ProductDatabase.Product p,Runnable refresh) {
        new AlertDialog.Builder(activity).setTitle(p.name)
                .setItems(new String[]{"编辑商品", "设置单位/期初库存", "查看商品库存", "删除商品", "清理重复商品（撤销错误入库）"},(dialog,index)-> {
                    if(index==0) {
                        Intent intent=new Intent(activity,ProductEditorActivity.class);
                        intent.putExtra("barcode",p.barcode);
                        intent.putExtra("edit",true);
                        BackPreview.capture(activity);
                        activity.startActivity(intent);
                    } else if(index==1 || index==2) {
                        Intent intent=new Intent(activity,index==1?StoreSettingsActivity.class:StoreStockActivity.class);
                        intent.putExtra("barcode",p.barcode);
                        BackPreview.capture(activity);
                        activity.startActivity(intent);
                    } else if(index==3) confirmDelete(activity,db,p,refresh);
                    else selectProductToKeep(activity,db,p,refresh);
                }).setNegativeButton("取消",null).show();
    }
    /** 用户先选中要删除的重复项，再从完整商品库明确指定保留项。 */
    private static void selectProductToKeep(Activity activity,ProductDatabase db,
                                           ProductDatabase.Product wrong,Runnable refresh) {
        final List<ProductDatabase.Product> candidates=new ArrayList<>();
        for(ProductDatabase.Product p:db.all())if(!p.barcode.equals(wrong.barcode))candidates.add(p);
        if(candidates.isEmpty()) {
            Toast.makeText(activity,"没有其他商品可保留，无法处理重复登记",Toast.LENGTH_LONG).show();return;
        }
        LinearLayout content=new LinearLayout(activity);
        content.setOrientation(LinearLayout.VERTICAL);
        int pad=(int)(14*activity.getResources().getDisplayMetrics().density);
        content.setPadding(pad,pad,pad,0);
        android.widget.TextView tip=new android.widget.TextView(activity);
        tip.setText("准备删除的重复商品："+wrong.name+"\n条码："+wrong.barcode+
                "\n\n请搜索并选择要保留的正确商品。不会把两边库存相加。");
        tip.setTextSize(15);content.addView(tip);
        EditText filter=new EditText(activity);filter.setSingleLine(true);
        filter.setHint("搜索保留商品名称或条码");content.addView(filter);
        List<ProductDatabase.Product> shown=new ArrayList<>(candidates);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(activity,android.R.layout.simple_list_item_1);
        for(ProductDatabase.Product p:shown)adapter.add(p.name+"  |  "+p.barcode);
        ListView picker=new ListView(activity);picker.setAdapter(adapter);
        content.addView(picker,new LinearLayout.LayoutParams(-1,(int)(260*activity.getResources().getDisplayMetrics().density)));
        AlertDialog dialog=new AlertDialog.Builder(activity).setTitle("选择保留的商品")
                .setView(content).setNegativeButton("取消",null).create();
        filter.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){
                String query=s.toString().trim().toLowerCase(Locale.ROOT);
                shown.clear();adapter.clear();
                for(ProductDatabase.Product p:candidates)if(query.isEmpty()||
                        p.name.toLowerCase(Locale.ROOT).contains(query)||p.barcode.contains(query)) {
                    shown.add(p);adapter.add(p.name+"  |  "+p.barcode);
                }
                adapter.notifyDataSetChanged();
            }
            @Override public void afterTextChanged(Editable e){}
        });
        picker.setOnItemClickListener((parent,view,index,id)->{
            if(index<0||index>=shown.size())return;
            ProductDatabase.Product keep=shown.get(index);
            dialog.dismiss();
            confirmDuplicateCleanup(activity,db,wrong,keep,refresh);
        });
        dialog.show();
    }

    private static void confirmDuplicateCleanup(Activity activity,ProductDatabase db,
                                               ProductDatabase.Product wrong,
                                               ProductDatabase.Product keep,Runnable refresh) {
        final InventoryStore store=new InventoryStore(db);
        final InventoryStore.DuplicatePreview preview;
        try { preview=store.previewDuplicate(wrong.barcode,keep.barcode); }
        catch(Exception e){ new AlertDialog.Builder(activity).setTitle("不能自动清理")
                .setMessage(e.getMessage()==null?"商品业务记录不符合安全清理条件":e.getMessage())
                .setPositiveButton("知道了",null).show();return; }
        String message="保留："+keep.name+"\n"+keep.barcode+
                "\n\n删除重复商品："+wrong.name+"\n"+wrong.barcode+
                "\n\n将撤销错误入库 "+preview.entries+" 条，合计 "+
                InventoryStore.qty(preview.inboundMilli)+" "+preview.baseUnit+
                "，入库金额 "+Money.show(preview.totalCents)+"。"+
                "\n\n不会把撤销的库存转到保留商品，也不会删除同一单据中的其他商品。"+
                "\n本次操作不可在页面内撤销，请先备份现有数据。";
        new AlertDialog.Builder(activity).setTitle("确认撤销错误入库并删除重复商品？")
                .setMessage(message).setNegativeButton("取消",null)
                .setPositiveButton("确认清理",(d,w)->{
                    try {
                        store.removeDuplicateInboundProduct(wrong.barcode,keep.barcode);
                        refresh.run();
                        new AlertDialog.Builder(activity).setTitle("重复商品已清理")
                                .setMessage("错误入库已撤销，多余商品已删除。保留商品的库存未增加。"+
                                        "\n撤销记录可在业务流水里查看。")
                                .setPositiveButton("确定",null).show();
                    }catch(Exception e) {
                        new AlertDialog.Builder(activity).setTitle("清理失败，数据未更改")
                                .setMessage(e.getMessage()==null?"请核对业务单据":e.getMessage())
                                .setPositiveButton("确定",null).show();
                    }
                }).show();
    }

    private static void confirmDelete(Activity activity,ProductDatabase db,
                                      ProductDatabase.Product p,Runnable refresh) {
        new AlertDialog.Builder(activity).setTitle("确认删除商品")
                .setMessage("商品："+p.name+"\n条形码："+p.barcode+
                        "\n\n删除后，该条码再次扫码需要重新录入。")
                .setNegativeButton("取消",null)
                .setPositiveButton("确认删除",(d,w)-> {
                    try {
                        if(db.delete(p.barcode)) {
                            refresh.run();
                            Toast.makeText(activity,"商品已删除",Toast.LENGTH_SHORT).show();
                        } else Toast.makeText(activity,"商品已不存在",Toast.LENGTH_SHORT).show();
                    } catch(Exception error) {
                        Toast.makeText(activity,error.getMessage()==null?"删除失败":error.getMessage(),Toast.LENGTH_LONG).show();
                    }
                }).show();
    }
}
