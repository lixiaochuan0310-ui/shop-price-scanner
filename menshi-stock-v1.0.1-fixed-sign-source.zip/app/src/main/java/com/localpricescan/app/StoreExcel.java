package com.localpricescan.app;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** 不依赖外部库的标准 Office Open XML(.xlsx) 导出。首行冻结、筛选、数值单元格。 */
final class StoreExcel {
    static final class Sheet {
        final String name;
        final List<List<Object>> rows=new ArrayList<>();
        Sheet(String name){this.name=name;}
        void add(Object... values){
            List<Object> row=new ArrayList<>();for(Object o:values)row.add(o);rows.add(row);
        }
    }
    private StoreExcel() {}
    private static String escape(String raw){
        if(raw==null)return "";
        StringBuilder s=new StringBuilder();
        for(int i=0;i<raw.length();i++) {
            char c=raw.charAt(i);
            if(c=='&')s.append("&amp;");else if(c=='<')s.append("&lt;");
            else if(c=='>')s.append("&gt;");else if(c=='\"')s.append("&quot;");
            else if(c=='\'')s.append("&apos;");
            else if(c==9||c==10||c==13||c>=32)s.append(c);
        }
        return s.toString();
    }
    private static String col(int index){StringBuilder s=new StringBuilder();
        int i=index;do{s.insert(0,(char)('A'+(i%26)));i=i/26-1;}while(i>=0);
        return s.toString();}
    private static void entry(ZipOutputStream out,String name,String content)throws IOException{
        out.putNextEntry(new ZipEntry(name));out.write(content.getBytes(StandardCharsets.UTF_8));out.closeEntry();
    }
    private static String sheetXml(Sheet sheet){
        StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"+
                "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"+
                "<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" "+
                "activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
        int columns=sheet.rows.isEmpty()?1:sheet.rows.get(0).size();
        s.append("<cols>");for(int i=0;i<columns;i++) {
            int width=18;
            if(!sheet.rows.isEmpty()&&i<sheet.rows.get(0).size()) {
                int max=sheet.rows.get(0).get(i).toString().length()*2;
                int sampled=0;
                for(int row=1;row<sheet.rows.size()&&sampled<120;row++,sampled++) {
                    Object v=i<sheet.rows.get(row).size()?sheet.rows.get(row).get(i):"";
                    if(v!=null)max=Math.max(max,Math.min(66,v.toString().length()*2));
                }
                width=Math.min(40,Math.max(15,max+4));
            }
            s.append("<col min=\"").append(i+1).append("\" max=\"").append(i+1)
                    .append("\" width=\"").append(width).append("\" customWidth=\"1\"/>");
        }
        s.append("</cols><sheetData>");
        int n=0;for(List<Object> row:sheet.rows){n++;
            int lines=1;
            if(n>1) for(Object value:row){
                String raw=value==null?"":value.toString();
                lines=Math.max(lines,Math.max(1,(raw.length()+18)/19));
            }
            int height=Math.min(396,Math.max(24,lines*16));
            s.append("<row r=\"").append(n).append("\" ht=\"").append(height)
                    .append("\" customHeight=\"1\">");
            for(int j=0;j<row.size();j++){
                String cell=col(j)+(n);
                Object value=row.get(j);
                s.append("<c r=\"").append(cell).append("\"");
                s.append(n==1?" s=\"1\"":" s=\"2\"");
                if(value instanceof Number){
                    s.append("><v>").append(value).append("</v></c>");
                } else {
                    s.append(" t=\"inlineStr\"><is><t xml:space=\"preserve\">")
                            .append(escape(value==null?"":value.toString()))
                            .append("</t></is></c>");
                }
            }
            s.append("</row>");
        }
        s.append("</sheetData>");
        if(!sheet.rows.isEmpty()&&sheet.rows.size()>1)s.append("<autoFilter ref=\"A1:")
                .append(col(columns-1)).append(sheet.rows.size()).append("\"/>");
        s.append("</worksheet>");return s.toString();
    }
    static void write(OutputStream destination,List<Sheet> sheets)throws IOException{
        if(sheets.isEmpty())throw new IOException("无报表");
        ZipOutputStream z=new ZipOutputStream(destination);
        StringBuilder types=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"+
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"+
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"+
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"+
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
        StringBuilder workbook=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
                "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "+
                "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
        StringBuilder rels=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for(int i=0;i<sheets.size();i++){
            int n=i+1;
            types.append("<Override PartName=\"/xl/worksheets/sheet").append(n).append(".xml\" "+
                    "ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            workbook.append("<sheet name=\"").append(escape(sheets.get(i).name)).append("\" sheetId=\"")
                    .append(n).append("\" r:id=\"rId").append(n).append("\"/>");
            rels.append("<Relationship Id=\"rId").append(n).append("\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet")
                    .append(n).append(".xml\"/>");
        }
        types.append("</Types>");workbook.append("</sheets></workbook>");
        rels.append("<Relationship Id=\"rIdStyles\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
        entry(z,"[Content_Types].xml",types.toString());
        entry(z,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"+
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" "+
                "Target=\"xl/workbook.xml\"/></Relationships>");
        entry(z,"xl/workbook.xml",workbook.toString());entry(z,"xl/_rels/workbook.xml.rels",rels.toString());
        entry(z,"xl/styles.xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
                "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"+
                "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font>"+
                "<font><b/><color rgb=\"FFFFFFFF\"/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>"+
                "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill>"+
                "<fill><patternFill patternType=\"gray125\"/></fill>"+
                "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF23744D\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>"+
                "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"+
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"+
                "<cellXfs count=\"3\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"+
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\"><alignment wrapText=\"1\" vertical=\"center\"/></xf>"+
                "<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"><alignment wrapText=\"1\" vertical=\"center\"/></xf></cellXfs>"+
                "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>");
        for(int i=0;i<sheets.size();i++)entry(z,"xl/worksheets/sheet"+(i+1)+".xml",sheetXml(sheets.get(i)));
        z.finish();z.flush();
    }
}
