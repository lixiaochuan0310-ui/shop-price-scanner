package com.localpricescan.app;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import com.journeyapps.barcodescanner.CaptureActivity;

/** 扫码页也使用相同的模糊交叉淡出返回效果。 */
public final class PortraitCaptureActivity extends CaptureActivity {
    private float startX, startY;
    private boolean tracking, dragging;
    private SwipeBackEffect backEffect;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Bitmap previous = BackPreview.take();
        backEffect = new SwipeBackEffect(this,previous);
        getWindow().setBackgroundDrawableResource(R.drawable.nature_wallpaper);
    }

    @Override protected void onPostCreate(Bundle state) {
        super.onPostCreate(state);
        backEffect.install();
    }

    private float dp(float amount) {
        return amount * getResources().getDisplayMetrics().density;
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        if (backEffect != null && backEffect.isFinishing()) return true;
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            View content = findViewById(android.R.id.content);
            startX = event.getX();
            startY = event.getY();
            dragging = false;
            tracking = content != null && startX <= dp(90);
            return super.dispatchTouchEvent(event);
        }
        if (event.getPointerCount() > 1) {
            if (dragging) backEffect.restore(false);
            dragging = false;
            tracking = false;
            return super.dispatchTouchEvent(event);
        }
        if (action == MotionEvent.ACTION_MOVE && tracking) {
            float dx = event.getX() - startX;
            float dy = event.getY() - startY;
            if (!dragging && Math.abs(dy) > dp(18) && Math.abs(dy) > Math.abs(dx)) {
                tracking = false;
            } else {
                if (!dragging && dx > dp(14) && dx > Math.abs(dy) * 1.4f) {
                    dragging = true;
                    MotionEvent cancel = MotionEvent.obtain(event);
                    cancel.setAction(MotionEvent.ACTION_CANCEL);
                    super.dispatchTouchEvent(cancel);
                    cancel.recycle();
                }
                if (dragging) {
                    backEffect.drag(dx);
                    return true;
                }
            }
        }
        if (action == MotionEvent.ACTION_UP && dragging) {
            float distance = event.getX()-startX;
            View content = findViewById(android.R.id.content);
            boolean goBack = content != null &&
                    distance > Math.max(dp(92),content.getWidth()*.23f);
            dragging = false;
            tracking = false;
            if (goBack) {
                backEffect.dismiss(() -> {
                    if (!isFinishing() && !isDestroyed()) onBackPressed();
                });
            } else backEffect.restore(false);
            return true;
        }
        if (action == MotionEvent.ACTION_CANCEL && dragging) {
            backEffect.restore(false);
            dragging = false;
            tracking = false;
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) tracking = false;
        return super.dispatchTouchEvent(event);
    }

    @Override public void finish() {
        super.finish();
        overridePendingTransition(0,0);
    }
}
