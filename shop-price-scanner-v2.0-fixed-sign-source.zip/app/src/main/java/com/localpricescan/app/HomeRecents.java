package com.localpricescan.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/** 只记录实际成功查询/录入的最近三个条码；不复制价格或照片。 */
final class HomeRecents {
    private static final String PREFS = "home_recent_scans";
    private static final String KEY = "barcodes";
    private static final int LIMIT = 3;

    private HomeRecents() {}

    static void record(Context context, String barcode) {
        if (barcode == null || barcode.trim().isEmpty()) return;
        List<String> barcodes = read(context);
        barcodes.remove(barcode);
        barcodes.add(0, barcode);
        JSONArray array = new JSONArray();
        for (int i = 0; i < Math.min(LIMIT, barcodes.size()); i++) array.put(barcodes.get(i));
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, array.toString()).apply();
    }

    static List<String> read(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY, "[]");
        if (raw == null) raw = "[]";
        ArrayList<String> barcodes = new ArrayList<>();
        HashSet<String> seen = new HashSet<>();
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length() && barcodes.size() < LIMIT; i++) {
                String barcode = array.optString(i, "");
                if (!barcode.isEmpty() && seen.add(barcode)) barcodes.add(barcode);
            }
        } catch (JSONException ignored) {
            // 若偏好设置意外损坏，只清空最近记录，不影响商品数据库。
        }
        return barcodes;
    }
}
