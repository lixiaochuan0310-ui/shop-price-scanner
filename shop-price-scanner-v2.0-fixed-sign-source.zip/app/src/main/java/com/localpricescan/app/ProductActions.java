package com.localpricescan.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.widget.Toast;

/** 列表和详情共用相同的长按操作与删除确认。 */
final class ProductActions {
    private ProductActions() {}
    static void menu(Activity activity,ProductDatabase db,ProductDatabase.Product p,Runnable refresh) {
        new AlertDialog.Builder(activity).setTitle(p.name)
                .setItems(new String[]{"编辑商品", "删除商品"},(dialog,index)-> {
                    if(index==0) {
                        Intent intent=new Intent(activity,ProductEditorActivity.class);
                        intent.putExtra("barcode",p.barcode);
                        intent.putExtra("edit",true);
                        BackPreview.capture(activity);
                        activity.startActivity(intent);
                    } else confirmDelete(activity,db,p,refresh);
                }).setNegativeButton("取消",null).show();
    }
    private static void confirmDelete(Activity activity,ProductDatabase db,
                                      ProductDatabase.Product p,Runnable refresh) {
        new AlertDialog.Builder(activity).setTitle("确认删除商品")
                .setMessage("商品："+p.name+"\n条形码："+p.barcode+
                        "\n\n删除后，该条码再次扫码需要重新录入。")
                .setNegativeButton("取消",null)
                .setPositiveButton("确认删除",(d,w)-> {
                    try {
                        if(db.delete(p.barcode)) {
                            refresh.run();
                            Toast.makeText(activity,"商品已删除",Toast.LENGTH_SHORT).show();
                        } else Toast.makeText(activity,"商品已不存在",Toast.LENGTH_SHORT).show();
                    } catch(SQLiteException error) { Toast.makeText(activity,"删除失败",Toast.LENGTH_LONG).show(); }
                }).show();
    }
}
