package com.localpricescan.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.provider.MediaStore;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;

import androidx.core.content.FileProvider;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;

/** 本地照片压缩为 JPEG，存入 SQLite；不需要网络、相册读权限或全盘存储权限。 */
final class PhotoUtils {
    private PhotoUtils() {}

    static Uri newCaptureUri(Activity activity) throws Exception {
        File f = File.createTempFile("price_photo_", ".jpg", activity.getCacheDir());
        return FileProvider.getUriForFile(activity,
                activity.getPackageName() + ".fileprovider", f);
    }

    static Intent photoIntent(Uri output) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, output);
        intent.setClipData(ClipData.newRawUri("商品照片", output));
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        return intent;
    }

    static Intent galleryIntent() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        return Intent.createChooser(intent, "选择商品照片");
    }

    static byte[] readJpeg(Activity activity, Uri uri) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream stream = activity.getContentResolver().openInputStream(uri)) {
            if (stream == null) throw new IllegalArgumentException("无法读取照片");
            BitmapFactory.decodeStream(stream, null, bounds);
        }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IllegalArgumentException("无效的图片");
        if ((long) bounds.outWidth * bounds.outHeight > 100_000_000L) throw new IllegalArgumentException("图片尺寸过大");
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 1;
        while (Math.max(bounds.outWidth / options.inSampleSize,
                bounds.outHeight / options.inSampleSize) > 1200) options.inSampleSize *= 2;
        Bitmap bitmap;
        try (InputStream stream = activity.getContentResolver().openInputStream(uri)) {
            if (stream == null) throw new IllegalArgumentException("无法读取照片");
            bitmap = BitmapFactory.decodeStream(stream, null, options);
        }
        if (bitmap == null) throw new IllegalArgumentException("无法解析照片");
        int rotation = 0;
        try (InputStream stream = activity.getContentResolver().openInputStream(uri)) {
            if (stream != null) {
                int orientation = new ExifInterface(stream).getAttributeInt(
                        ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                if (orientation == ExifInterface.ORIENTATION_ROTATE_90) rotation = 90;
                if (orientation == ExifInterface.ORIENTATION_ROTATE_180) rotation = 180;
                if (orientation == ExifInterface.ORIENTATION_ROTATE_270) rotation = 270;
            }
        } catch (Exception ignored) { /* 无 EXIF 的图片按原方向保存 */ }
        if (rotation != 0) {
            Matrix matrix = new Matrix(); matrix.postRotate(rotation);
            Bitmap rotated = Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
            if (rotated != bitmap) bitmap.recycle();
            bitmap = rotated;
        }
        // 压缩比例严格限定备份文件及数据库的空间占用。
        byte[] bytes = null;
        for (int quality : new int[]{82,72,60,45}) {
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, quality, output)) continue;
            bytes = output.toByteArray();
            if (bytes.length <= ProductDatabase.MAX_PHOTO_BYTES) break;
        }
        bitmap.recycle();
        ProductDatabase.requirePhoto(bytes);
        return bytes;
    }

    static void show(byte[] data, ImageView image, TextView placeholder) {
        if (data == null || data.length == 0) {
            image.setImageDrawable(null);
            image.setVisibility(View.GONE);
            placeholder.setVisibility(View.VISIBLE);
            return;
        }
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(data, 0, data.length, bounds);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 1;
        while (Math.max(bounds.outWidth / options.inSampleSize,
                bounds.outHeight / options.inSampleSize) > 700) options.inSampleSize *= 2;
        Bitmap bitmap = BitmapFactory.decodeByteArray(data,0,data.length,options);
        if (bitmap == null) {
            image.setVisibility(View.GONE);
            placeholder.setVisibility(View.VISIBLE);
        } else {
            image.setImageBitmap(bitmap);
            image.setVisibility(View.VISIBLE);
            placeholder.setVisibility(View.GONE);
        }
    }
}
