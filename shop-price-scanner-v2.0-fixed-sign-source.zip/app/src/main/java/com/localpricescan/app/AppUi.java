package com.localpricescan.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.view.View;

final class AppUi {
    private AppUi() {}
    static void apply(Activity activity) {
        activity.getWindow().setStatusBarColor(Color.rgb(33,114,62));
        activity.getWindow().setNavigationBarColor(Color.rgb(247,248,235));
        activity.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }
}
