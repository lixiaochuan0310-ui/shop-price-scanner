package com.localpricescan.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

/** 纯本地系统文件选择器：导出全部商品+照片，支持恢复以前没有照片的 V1 备份。 */
public final class BackupActivity extends SwipeBackActivity {
    private static final int SAVE_REQUEST = 201, OPEN_REQUEST = 202;
    private static final int MAX_BACKUP_BYTES = 50 * 1024 * 1024;
    private static final int MAX_PRODUCTS = 200_000;
    private ProductDatabase db;
    private TextView countView;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppUi.apply(this);
        setContentView(R.layout.activity_backup);
        db = new ProductDatabase(this);
        countView = findViewById(R.id.backupCount);
        findViewById(R.id.backupBackButton).setOnClickListener(v -> onBackPressed());
        findViewById(R.id.exportButton).setOnClickListener(v -> exportWithPicker());
        findViewById(R.id.importButton).setOnClickListener(v -> importWithPicker());
        refreshCount();
    }

    private void refreshCount() {
        try { countView.setText("当前手机已保存 " + db.count() + " 件商品（含已拍摄照片）"); }
        catch (SQLiteException e) { countView.setText("商品数量读取失败"); }
    }

    private void exportWithPicker() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "商品查价完整备份_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.CHINA).format(new Date()) + ".json");
        startActivityForResult(intent,SAVE_REQUEST);
    }

    private void importWithPicker() {
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent,OPEN_REQUEST);
    }

    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if (result!=RESULT_OK || data==null || data.getData()==null) return;
        if (request==SAVE_REQUEST) exportTo(data.getData());
        else if (request==OPEN_REQUEST) importFrom(data.getData());
    }

    private void exportTo(Uri uri) {
        try {
            List<ProductDatabase.Product> products=db.all();
            if (products.size()>MAX_PRODUCTS) throw new IllegalArgumentException("商品数量过多");
            JSONObject root=new JSONObject();
            root.put("format","local_price_scanner_backup");
            root.put("version",2);
            JSONArray array=new JSONArray();
            for (ProductDatabase.Product p:products) {
                JSONObject item=new JSONObject();
                item.put("barcode",p.barcode);
                item.put("name",p.name);
                item.put("purchase_cents",p.purchaseCents);
                item.put("sale_cents",p.saleCents);
                byte[] photo=db.photo(p.barcode);
                if (photo!=null) item.put("photo_jpeg_base64",Base64.encodeToString(photo,Base64.NO_WRAP));
                array.put(item);
            }
            root.put("products",array);
            byte[] bytes=root.toString().getBytes(StandardCharsets.UTF_8);
            if(bytes.length>MAX_BACKUP_BYTES) {
                Toast.makeText(this,"商品及照片备份超过50MB，请减少照片后重试",Toast.LENGTH_LONG).show();
                return;
            }
            try(OutputStream output=getContentResolver().openOutputStream(uri,"wt")) {
                if(output==null) throw new IllegalStateException("无法写入");
                output.write(bytes); output.flush();
            }
            new AlertDialog.Builder(this).setTitle("备份完成")
                    .setMessage("已备份 "+products.size()+" 件商品及其照片。\n\n换手机时传输这个 JSON 文件并选择「恢复数据」。")
                    .setPositiveButton("知道了",null).show();
        } catch(Exception e) { Toast.makeText(this,"备份失败，请重试或另选位置",Toast.LENGTH_LONG).show(); }
    }

    private void importFrom(Uri uri) {
        try {
            ByteArrayOutputStream output=new ByteArrayOutputStream();
            try(InputStream in=getContentResolver().openInputStream(uri)) {
                if(in==null) throw new IllegalStateException("文件不可读取");
                byte[] buffer=new byte[16384]; int n;
                while((n=in.read(buffer))!=-1) {
                    if(output.size()+n>MAX_BACKUP_BYTES) throw new IllegalArgumentException("文件过大");
                    output.write(buffer,0,n);
                }
            }
            JSONObject root=new JSONObject(new String(output.toByteArray(),StandardCharsets.UTF_8));
            int version=root.optInt("version",-1);
            if (!"local_price_scanner_backup".equals(root.optString("format")) ||
                    (version!=1 && version!=2)) throw new IllegalArgumentException("不是支持的备份");
            JSONArray items=root.getJSONArray("products");
            if(items.length()>MAX_PRODUCTS) throw new IllegalArgumentException("商品数量超限");
            List<ProductDatabase.Record> records=new ArrayList<>(items.length());
            HashSet<String> keys=new HashSet<>();
            for(int i=0;i<items.length();i++) {
                JSONObject p=items.getJSONObject(i);
                String barcode=p.getString("barcode");
                String name=p.getString("name").trim();
                long cost=p.getLong("purchase_cents"), sale=p.getLong("sale_cents");
                if(barcode.isEmpty() || barcode.length()>200 || name.isEmpty() || name.length()>500 ||
                        cost<0 || sale<0 || cost>99999999900L || sale>99999999900L ||
                        !keys.add(barcode)) throw new IllegalArgumentException("商品数据无效");
                byte[] photo=null;
                if(version==2 && p.has("photo_jpeg_base64") && !p.isNull("photo_jpeg_base64")) {
                    String encoded=p.getString("photo_jpeg_base64");
                    if(encoded.length()>(ProductDatabase.MAX_PHOTO_BYTES*4L/3L)+20)
                        throw new IllegalArgumentException("照片过大");
                    photo=Base64.decode(encoded,Base64.NO_WRAP);
                    ProductDatabase.requirePhoto(photo);
                }
                records.add(new ProductDatabase.Record(new ProductDatabase.Product(barcode,name,cost,sale),photo));
            }
            int current=db.count();
            new AlertDialog.Builder(this).setTitle("确认恢复全部数据")
                    .setMessage("备份包含 "+records.size()+" 件商品。\n\n恢复将替换手机现有的 "+current+
                            " 件商品及照片。此操作不可撤销，确定继续吗？")
                    .setNegativeButton("取消",null)
                    .setPositiveButton("确认恢复",(dialog,which)->restore(records)).show();
        } catch(Exception e) { Toast.makeText(this,"备份文件无效或损坏，原商品未修改",Toast.LENGTH_LONG).show(); }
    }

    private void restore(List<ProductDatabase.Record> records) {
        try {
            db.replaceAll(records);
            refreshCount();
            new AlertDialog.Builder(this).setTitle("恢复完成")
                    .setMessage("已恢复 "+records.size()+" 件商品及对应照片。")
                    .setPositiveButton("确定",null).show();
        } catch(Exception e) { Toast.makeText(this,"恢复失败，原有数据已保留",Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onDestroy() { if(db!=null) db.close(); super.onDestroy(); }
}
