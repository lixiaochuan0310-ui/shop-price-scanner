package com.localpricescan.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.View;

/** 保存启动下一级页面前的可见画面，仅在内存中用于交互式返回预览。 */
final class BackPreview {
    private static Bitmap next;
    private BackPreview() {}

    static void capture(Activity parent) {
        View content = parent.findViewById(android.R.id.content);
        if (content == null || content.getWidth() < 1 || content.getHeight() < 1) {
            next = null;
            return;
        }
        try {
            int width = Math.min(content.getWidth(), 720);
            float ratio = width / (float)content.getWidth();
            int height = Math.max(1,Math.round(content.getHeight() * ratio));
            Bitmap screenshot = Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(screenshot);
            canvas.scale(ratio,ratio);
            content.draw(canvas);
            next = screenshot;
        } catch (OutOfMemoryError | RuntimeException error) {
            // 屏幕截取失败不会妨碍导航：返回时至少显示原有背景图。
            next = null;
        }
    }

    static Bitmap take() {
        Bitmap preview = next;
        next = null;
        return preview;
    }

    static void clearPending() { next = null; }
}
