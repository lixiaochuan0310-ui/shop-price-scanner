package com.localpricescan.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 在线图库仅在用户主动打开时查询，下载照片后转为本地 JPEG，商品数据库与离线扫码不受影响。 */
public final class OnlinePhotoSearchActivity extends SwipeBackActivity {
    private static final String[] API_SOURCES = {
            "https://world.openfoodfacts.org", "https://world.openproductsfacts.org"
    };
    private static final String[] SOURCE_TITLES = {"Open Food Facts", "Open Products Facts"};
    private static final String USER_AGENT = "ShopPriceScanner/2.0.1 (Android; https://github.com/lixiaochuan0310-ui/shop-price-scanner)";
    private static final int MAX_JSON_BYTES = 1_500_000;
    private static final int MAX_IMAGE_BYTES = 5_000_000;
    private final ExecutorService worker = Executors.newFixedThreadPool(2);
    private final ExecutorService thumbnails = Executors.newFixedThreadPool(2);
    private final Handler ui = new Handler(Looper.getMainLooper());
    private EditText searchInput;
    private TextView status;
    private ProgressBar progress;
    private LinearLayout results;
    private Button barcodeButton, nameButton;
    private String barcode;
    private int sequence = 0;
    private boolean selecting = false;

    private static final class Candidate {
        final String name, barcode, imageUrl, source;
        Candidate(String name, String barcode, String imageUrl, String source) {
            this.name = name; this.barcode = barcode; this.imageUrl = imageUrl; this.source = source;
        }
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppUi.apply(this);
        setContentView(R.layout.activity_online_photo_search);
        barcode = getIntent().getStringExtra("barcode");
        if (barcode == null) barcode = "";
        searchInput = findViewById(R.id.onlineSearchName);
        status = findViewById(R.id.onlineStatus);
        progress = findViewById(R.id.onlineProgress);
        results = findViewById(R.id.onlineResults);
        barcodeButton = findViewById(R.id.onlineBarcodeButton);
        nameButton = findViewById(R.id.onlineNameButton);
        findViewById(R.id.onlineBack).setOnClickListener(v -> onBackPressed());
        searchInput.setText(getIntent().getStringExtra("name") == null ? "" : getIntent().getStringExtra("name"));
        barcodeButton.setOnClickListener(v -> queryBarcode());
        nameButton.setOnClickListener(v -> queryName());
        if (barcode.trim().isEmpty()) {
            barcodeButton.setEnabled(false);
            status.setText("条码为空。请输入商品名称后搜索。\n首次查找需要联网，已保存照片可离线显示。");
        } else {
            queryBarcode();
        }
    }

    private void queryBarcode() {
        if (barcode.trim().isEmpty()) return;
        final int seq = start("正在按条形码查找商品包装照片…");
        worker.execute(() -> {
            List<Candidate> found = new ArrayList<>();
            boolean anyResponse = false;
            try {
                for (int i = 0; i < API_SOURCES.length; i++) {
                    String key = BarcodeKey.scanned(barcode);
                    for (String code : new String[]{key, BarcodeKey.equivalentUpcEan(key)}) {
                        if (code == null || code.isEmpty()) continue;
                        try {
                            String endpoint = API_SOURCES[i] + "/api/v2/product/" +
                                    URLEncoder.encode(code, "UTF-8") + ".json?fields=code,product_name,image_front_url,image_url";
                            JSONObject data = new JSONObject(downloadJson(endpoint));
                            anyResponse = true;
                            if (data.optInt("status", 0) == 1) {
                                Candidate product = candidate(data.optJSONObject("product"), SOURCE_TITLES[i]);
                                if (product != null && !containsImage(found, product.imageUrl)) found.add(product);
                            }
                        } catch (Exception ignored) { /* One source may be unavailable. */ }
                    }
                }
                final boolean reachable = anyResponse;
                ui.post(() -> display(seq, found, reachable,
                        "没有找到对应条码的包装照片。可按商品名称搜索，或使用手机拍照／相册。"));
            } catch (Exception e) {
                ui.post(() -> display(seq, found, false, "图库查询失败，请检查网络后重试。"));
            }
        });
    }

    private void queryName() {
        final String words = searchInput.getText().toString().trim();
        if (words.isEmpty()) { searchInput.setError("请输入商品名称"); return; }
        final int seq = start("正在按商品名称搜索照片…");
        worker.execute(() -> {
            List<Candidate> found = new ArrayList<>();
            boolean anyResponse = false;
            for (int i = 0; i < API_SOURCES.length; i++) {
                try {
                    String endpoint = API_SOURCES[i] + "/cgi/search.pl?search_terms=" +
                            URLEncoder.encode(words, "UTF-8") +
                            "&search_simple=1&action=process&json=1&page_size=12&fields=code,product_name,image_front_url,image_url";
                    JSONObject data = new JSONObject(downloadJson(endpoint));
                    anyResponse = true;
                    JSONArray products = data.optJSONArray("products");
                    if (products == null) continue;
                    for (int j = 0; j < products.length() && found.size() < 12; j++) {
                        Candidate candidate = candidate(products.optJSONObject(j), SOURCE_TITLES[i]);
                        if (candidate != null && !containsImage(found, candidate.imageUrl)) found.add(candidate);
                    }
                } catch (Exception ignored) { /* Continue with another service. */ }
            }
            final boolean reachable = anyResponse;
            ui.post(() -> display(seq, found, reachable,
                    "没有找到包含照片的商品。可以换个名称搜索，或自己拍照／选相册。"));
        });
    }

    private int start(String message) {
        int seq = ++sequence;
        selecting = false;
        progress.setVisibility(View.VISIBLE);
        barcodeButton.setEnabled(false);
        nameButton.setEnabled(false);
        status.setText(message);
        results.removeAllViews();
        return seq;
    }

    private void display(int seq, List<Candidate> found, boolean reachable, String emptyMessage) {
        if (isFinishing() || seq != sequence) return;
        progress.setVisibility(View.GONE);
        barcodeButton.setEnabled(!barcode.trim().isEmpty());
        nameButton.setEnabled(true);
        if (found.isEmpty()) {
            status.setText(reachable ? emptyMessage : "无法连接在线商品图库。请检查网络或稍后重试；离线扫码查价不受影响。");
            return;
        }
        status.setText("找到 " + found.size() + " 张候选包装图，请确认名称和包装后选择。\n来源：Open Food Facts / Open Products Facts；照片可能由社区用户上传。");
        for (Candidate product : found) makeRow(seq, product);
    }

    private void makeRow(int seq, Candidate product) {
        final int p = (int) (getResources().getDisplayMetrics().density * 10);
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(p, p, p, p);
        item.setBackgroundResource(R.drawable.bg_card);
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowParams.bottomMargin = p;
        results.addView(item, rowParams);
        ImageView preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setMinimumHeight((int)(getResources().getDisplayMetrics().density * 125));
        item.addView(preview, new LinearLayout.LayoutParams(-1,
                (int)(getResources().getDisplayMetrics().density * 170)));
        TextView title = new TextView(this);
        title.setText((product.name.isEmpty() ? "未命名商品" : product.name) + "\n" + product.barcode + " · " + product.source);
        title.setTextSize(15);
        title.setTextColor(0xff204e32);
        title.setPadding(0, p / 2, 0, p / 2);
        item.addView(title);
        Button choose = new Button(this);
        choose.setAllCaps(false);
        choose.setText("使用这张照片");
        choose.setBackgroundResource(R.drawable.bg_secondary);
        choose.setTextColor(0xff17683f);
        item.addView(choose, new LinearLayout.LayoutParams(-1, (int)(getResources().getDisplayMetrics().density * 48)));
        choose.setOnClickListener(v -> select(product));
        thumbnails.execute(() -> {
            try {
                byte[] image = downloadImage(product.imageUrl);
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(image, 0, image.length, options);
                options.inSampleSize = 1;
                while (options.outWidth / options.inSampleSize > 720 || options.outHeight / options.inSampleSize > 720)
                    options.inSampleSize *= 2;
                Bitmap bitmap = BitmapFactory.decodeByteArray(image, 0, image.length, options);
                if (bitmap != null) ui.post(() -> {
                    if (!isFinishing() && seq == sequence) preview.setImageBitmap(bitmap);
                    else bitmap.recycle();
                });
            } catch (Exception ignored) { /* A failed preview should not block the other candidates. */ }
        });
    }

    private void select(Candidate product) {
        if (selecting) return;
        selecting = true;
        final int seq = ++sequence;
        progress.setVisibility(View.VISIBLE);
        barcodeButton.setEnabled(false);
        nameButton.setEnabled(false);
        status.setText("正在下载并保存选中的商品照片…");
        worker.execute(() -> {
            try {
                byte[] image = downloadImage(product.imageUrl);
                File file = File.createTempFile("catalogue_photo_", ".jpg", getCacheDir());
                try (FileOutputStream out = new FileOutputStream(file)) { out.write(image); }
                byte[] jpeg = PhotoUtils.readJpeg(this, Uri.fromFile(file));
                if (!file.delete()) file.deleteOnExit();
                File result = File.createTempFile("catalogue_selected_", ".jpg", getCacheDir());
                try (FileOutputStream out = new FileOutputStream(result)) { out.write(jpeg); }
                Uri resultUri = FileProvider.getUriForFile(this,
                        getPackageName() + ".fileprovider", result);
                ui.post(() -> {
                    if (isFinishing() || seq != sequence) return;
                    Intent value = new Intent();
                    value.setData(resultUri);
                    value.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    setResult(Activity.RESULT_OK, value);
                    finish();
                });
            } catch (Exception e) {
                ui.post(() -> {
                    if (isFinishing() || seq != sequence) return;
                    progress.setVisibility(View.GONE);
                    selecting = false;
                    barcodeButton.setEnabled(!barcode.trim().isEmpty());
                    nameButton.setEnabled(true);
                    status.setText("这张照片下载失败，请检查网络或尝试其他照片。");
                    Toast.makeText(this, "下载失败，可换一张重试", Toast.LENGTH_SHORT).show();
                });
            }
        });
    }

    private static boolean containsImage(List<Candidate> list, String imageUrl) {
        for (Candidate c : list) if (c.imageUrl.equals(imageUrl)) return true;
        return false;
    }

    private static Candidate candidate(JSONObject item, String source) {
        if (item == null) return null;
        String photo = item.optString("image_front_url", "");
        if (photo.isEmpty()) photo = item.optString("image_url", "");
        if (!isAllowedPhoto(photo)) return null;
        return new Candidate(item.optString("product_name", ""), item.optString("code", ""), photo, source);
    }

    private static boolean isAllowedPhoto(String address) {
        try {
            URL url = new URL(address);
            String host = url.getHost().toLowerCase(Locale.ROOT);
            return "https".equals(url.getProtocol()) && (
                    host.equals("images.openfoodfacts.org") || host.equals("images.openproductsfacts.org") ||
                    host.equals("images.openbeautyfacts.org") || host.equals("images.openpetfoodfacts.org"));
        } catch (Exception e) { return false; }
    }

    private static byte[] readRemote(String address, int limit, boolean image) throws Exception {
        URL url = new URL(address);
        if (!"https".equals(url.getProtocol())) throw new IllegalArgumentException("非 HTTPS 地址");
        if (image && !isAllowedPhoto(address)) throw new IllegalArgumentException("不受信任的图片地址");
        if (!image && !ArraysHost.api(url.getHost())) throw new IllegalArgumentException("不受信任的图库接口");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setInstanceFollowRedirects(false);
        conn.setConnectTimeout(7000);
        conn.setReadTimeout(12000);
        conn.setRequestProperty("User-Agent", USER_AGENT);
        conn.setRequestProperty("Accept", image ? "image/jpeg,image/png,image/webp,*/*" : "application/json");
        try {
            if (conn.getResponseCode() != 200) throw new IllegalStateException("图库服务返回 " + conn.getResponseCode());
            String type = conn.getContentType();
            if (image && type != null && !type.toLowerCase(Locale.ROOT).startsWith("image/"))
                throw new IllegalStateException("非图片内容");
            try (InputStream input = conn.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192]; int count;
                while ((count = input.read(buffer)) != -1) {
                    if (out.size() + count > limit) throw new IllegalStateException("响应文件过大");
                    out.write(buffer, 0, count);
                }
                return out.toByteArray();
            }
        } finally { conn.disconnect(); }
    }

    private static String downloadJson(String url) throws Exception {
        return new String(readRemote(url, MAX_JSON_BYTES, false), java.nio.charset.StandardCharsets.UTF_8);
    }

    private static byte[] downloadImage(String url) throws Exception {
        return readRemote(url, MAX_IMAGE_BYTES, true);
    }

    private static final class ArraysHost {
        static boolean api(String host) {
            return "world.openfoodfacts.org".equalsIgnoreCase(host) ||
                    "world.openproductsfacts.org".equalsIgnoreCase(host);
        }
    }

    @Override protected void onDestroy() {
        ++sequence;
        worker.shutdownNow();
        thumbnails.shutdownNow();
        super.onDestroy();
    }
}
