# 商品查价 — 安卓纯离线 APP 源码（V1.0）

## 使用流程
1. 打开 APP，自动启动相机扫码（第一次需允许相机权限）。
2. 如果条形码尚未收录，显示「发现新商品」，只需输入商品名称、进价、售价，然后点击「保存商品」。
3. 如果条形码已经收录，直接显示商品名称、进价、售价。
4. 点击「继续扫码」即可扫描下一件商品。

**商品数据来自用户自己首次录入**，并非联网查商品名称或价格。条码本身不含进价、售价。

## 技术结构
- Android 原生 Java / Android SDK 24+（Android 7.0 起）
- ZXing Android Embedded 4.3.0（相机识别常见 EAN/UPC、CODE_128 等一维条码；扫描逻辑在手机本地）
- SQLite 本机数据库，价格存储为整数分以避免小数舍入
- 不声明 INTERNET 权限，不连接服务器、不上传商品信息、不要求登录
- 数据保存于 APP 私有空间：关闭 APP 后保留；**卸载 APP 或清除应用数据会删除全部商品记录**

## 构建方法
电脑安装 Android Studio（自带 JDK 17），在 Android Studio 中打开此工程根目录；项目首次同步需联网下载 Android Gradle Plugin、ZXing 与 SDK；随后选择 `Build > Build APK(s)` 生成 `app/build/outputs/apk/debug/app-debug.apk`。

如 Android Studio 提示找不到 Gradle Wrapper，本项目不含 wrapper 可执行文件；可在 Android Studio 的 Gradle 设置中指定可用的本地 Gradle 8.9，或在命令行已有 Gradle 8.9 时执行 `gradle wrapper --gradle-version 8.9` 生成标准 wrapper 后重启项目同步。

**注意：本交付为完整 Android Studio 源码项目，不是已编译 APK。当前环境缺少 Android SDK/Gradle，未能进行实际编译及实体机扫码验收。**

## 本版本范围
仅限扫码、首次录入三项信息、再次扫码查询三项信息；未加入收银、库存、会员、网络同步、数据导出等功能。本版本也没有现有商品价格修改界面（该功能不在当前确认范围内）。
