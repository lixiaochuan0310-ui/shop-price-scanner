package com.localpricescan.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/** 商品数据仅保存在当前手机的 SQLite 数据库。 */
final class ProductDatabase extends SQLiteOpenHelper {
    private static final String DATABASE = "offline_products.db";
    private static final int VERSION = 1;

    ProductDatabase(Context context) {
        super(context, DATABASE, null, VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE products (" +
                "barcode TEXT PRIMARY KEY NOT NULL, " +
                "name TEXT NOT NULL, " +
                "purchase_cents INTEGER NOT NULL CHECK(purchase_cents >= 0), " +
                "sale_cents INTEGER NOT NULL CHECK(sale_cents >= 0))");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 预留未来升级；不得删除现有商品数据。
    }

    Product get(String barcode) {
        try (Cursor cursor = getReadableDatabase().query(
                "products", new String[]{"name", "purchase_cents", "sale_cents"},
                "barcode = ?", new String[]{barcode}, null, null, null)) {
            if (!cursor.moveToFirst()) return null;
            return new Product(barcode, cursor.getString(0), cursor.getLong(1), cursor.getLong(2));
        }
    }

    void insert(Product product) {
        ContentValues values = new ContentValues();
        values.put("barcode", product.barcode);
        values.put("name", product.name);
        values.put("purchase_cents", product.purchaseCents);
        values.put("sale_cents", product.saleCents);
        // 不覆盖已有商品；保证一次条码对应一条明确的商品记录。
        getWritableDatabase().insertOrThrow("products", null, values);
    }

    static final class Product {
        final String barcode;
        final String name;
        final long purchaseCents;
        final long saleCents;

        Product(String barcode, String name, long purchaseCents, long saleCents) {
            this.barcode = barcode;
            this.name = name;
            this.purchaseCents = purchaseCents;
            this.saleCents = saleCents;
        }
    }
}
