package com.localpricescan.app;

import android.app.Activity;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

/** 从屏幕左侧往右滑返回：页面跟随手指，短距离回弹；上下滚动不受影响。 */
public abstract class SwipeBackActivity extends Activity {
    private float startX, startY;
    private boolean tracking, dragging;
    private View page;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setBackgroundDrawableResource(android.R.color.white);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    private boolean insideEditText(View v, float rawX, float rawY) {
        if (v == null || v.getVisibility() != View.VISIBLE) return false;
        if (v instanceof EditText) {
            Rect r = new Rect();
            return v.getGlobalVisibleRect(r) && r.contains((int)rawX, (int)rawY);
        }
        if (v instanceof ViewGroup) {
            ViewGroup group = (ViewGroup)v;
            for (int i = 0; i < group.getChildCount(); i++) {
                if (insideEditText(group.getChildAt(i),rawX,rawY)) return true;
            }
        }
        return false;
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            page = findViewById(android.R.id.content);
            startX = event.getX();
            startY = event.getY();
            dragging = false;
            // 左侧起滑，避免误触拍照、输入框和页面内其他操作。
            tracking = page != null && startX <= dp(90) &&
                    !insideEditText(page,event.getRawX(),event.getRawY());
            return super.dispatchTouchEvent(event);
        }
        if (event.getPointerCount() > 1) {
            if (dragging) restorePage();
            dragging = false;
            tracking = false;
            return super.dispatchTouchEvent(event);
        }
        if (action == MotionEvent.ACTION_MOVE && tracking) {
            float dx = event.getX() - startX;
            float dy = event.getY() - startY;
            if (!dragging && Math.abs(dy) > dp(18) && Math.abs(dy) > Math.abs(dx)) {
                tracking = false;
            } else {
                if (!dragging && dx > dp(14) && dx > Math.abs(dy) * 1.4f) {
                    dragging = true;
                    // 取消原控件点击/长按，防止滑动返回误触商品操作。
                    MotionEvent cancel = MotionEvent.obtain(event);
                    cancel.setAction(MotionEvent.ACTION_CANCEL);
                    super.dispatchTouchEvent(cancel);
                    cancel.recycle();
                }
                if (dragging) {
                    page.setTranslationX(Math.max(0f,dx));
                    return true;
                }
            }
        }
        if (action == MotionEvent.ACTION_UP && dragging) {
            float distance = event.getX() - startX;
            boolean goBack = distance > Math.max(dp(92),page.getWidth() * 0.23f);
            dragging = false;
            tracking = false;
            if (goBack) {
                // Immediately trigger navigation: waiting for a full reset animation makes
                // the screen visibly pause/rebound before it actually returns.
                page.animate().cancel();
                page.setTranslationX(0f); // Also keeps unsaved-change dialogs centered.
                if (!isFinishing() && !isDestroyed()) onBackPressed();
            } else {
                restorePage();
            }
            return true;
        }
        if (action == MotionEvent.ACTION_CANCEL && dragging) {
            restorePage();
            dragging = false;
            tracking = false;
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            tracking = false;
        }
        return super.dispatchTouchEvent(event);
    }

    @Override public void finish() {
        super.finish();
        // Do not stack a default exit animation on top of the swipe gesture.
        overridePendingTransition(0, 0);
    }

    private void restorePage() {
        if (page != null) page.animate().translationX(0f).setDuration(90).start();
    }
}
