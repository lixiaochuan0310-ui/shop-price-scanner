package com.localpricescan.app;

import android.view.MotionEvent;
import android.view.View;
import com.journeyapps.barcodescanner.CaptureActivity;

/** 扫码画面保持纵向，并支持从左向右滑动取消扫码返回。 */
public final class PortraitCaptureActivity extends CaptureActivity {
    private float startX, startY;
    private boolean tracking, dragging;
    private View content;

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            content = findViewById(android.R.id.content);
            startX = event.getX();
            startY = event.getY();
            dragging = false;
            tracking = content != null && startX <= dp(90);
            return super.dispatchTouchEvent(event);
        }
        if (event.getPointerCount() > 1) {
            if (dragging) restore();
            dragging = false;
            tracking = false;
            return super.dispatchTouchEvent(event);
        }
        if (action == MotionEvent.ACTION_MOVE && tracking) {
            float dx = event.getX() - startX;
            float dy = event.getY() - startY;
            if (!dragging && Math.abs(dy) > dp(18) && Math.abs(dy) > Math.abs(dx)) {
                tracking = false;
            } else {
                if (!dragging && dx > dp(14) && dx > Math.abs(dy) * 1.4f) {
                    dragging = true;
                    MotionEvent cancel = MotionEvent.obtain(event);
                    cancel.setAction(MotionEvent.ACTION_CANCEL);
                    super.dispatchTouchEvent(cancel);
                    cancel.recycle();
                }
                if (dragging) {
                    content.setTranslationX(Math.max(0f,dx));
                    return true;
                }
            }
        }
        if (action == MotionEvent.ACTION_UP && dragging) {
            float distance = event.getX() - startX;
            boolean goBack = distance > Math.max(dp(92),content.getWidth() * 0.23f);
            dragging = false;
            tracking = false;
            if (goBack) {
                content.animate().cancel();
                content.setTranslationX(0f);
                if (!isFinishing() && !isDestroyed()) onBackPressed();
            } else {
                restore();
            }
            return true;
        }
        if (action == MotionEvent.ACTION_CANCEL && dragging) {
            restore();
            dragging = false;
            tracking = false;
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) tracking = false;
        return super.dispatchTouchEvent(event);
    }

    @Override public void finish() {
        super.finish();
        overridePendingTransition(0, 0);
    }

    private void restore() {
        if (content != null) content.animate().translationX(0f).setDuration(90).start();
    }
}
