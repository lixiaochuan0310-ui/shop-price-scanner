package com.localpricescan.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.View;
import android.view.Gravity;
import android.widget.LinearLayout;

/** Native, resolution-independent homepage materials. No screenshot or mock data is used as UI. */
final class HomeArt {
    private HomeArt(){}
    static int d(Context c,float n){return StoreUi.d(c,n);}
    static int mix(int a,int b,float f){return Color.rgb((int)(Color.red(a)*(1-f)+Color.red(b)*f),(int)(Color.green(a)*(1-f)+Color.green(b)*f),(int)(Color.blue(a)*(1-f)+Color.blue(b)*f));}
    static Drawable card(Context c,int top,int bottom,int radius,boolean gloss){return new Art(c,top,bottom,radius,gloss,0);}
    static Drawable page(Context c){return new Art(c,0xfff4fbf8,0xffe6f5f2,0,false,1);}
    static Drawable header(Context c){return new Art(c,0xff166c72,0xff55b9b0,0,false,2);}
    static final class Art extends Drawable {
        final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);final Context c;final int top,bottom,radius,mode;final boolean gloss;
        Art(Context c,int top,int bottom,int radius,boolean gloss,int mode){this.c=c;this.top=top;this.bottom=bottom;this.radius=radius;this.gloss=gloss;this.mode=mode;}
        @Override public void draw(Canvas canvas){
            Rect b=getBounds();float w=b.width(),h=b.height();if(w<=0||h<=0)return;
            canvas.save();canvas.translate(b.left,b.top);p.setStyle(Paint.Style.FILL);
            if(mode!=0){
                p.setShader(new LinearGradient(0,0,mode==2?w:0,h,top,bottom,Shader.TileMode.CLAMP));canvas.drawRect(0,0,w,h,p);p.setShader(null);
                if(mode==1){
                    wave(canvas,w,h,0.91f,0xffccece2,false);wave(canvas,w,h,0.95f,0xffacdeda,true);wave(canvas,w,h,0.98f,0xff85cfcb,false);
                }else{
                    wave(canvas,w,h,0.76f,0x33ffffff,false);wave(canvas,w,h,0.89f,0x50e7fff6,true);
                }
            }else{
                float r=d(c,radius),edge=d(c,1),base=d(c,3);
                p.setColor(mix(bottom,0xff3d7778,0.20f));canvas.drawRoundRect(0,base,w,h,r,r,p);
                RectF rect=new RectF(0,0,w,h-base);
                p.setShader(new LinearGradient(0,0,w*0.35f,h,top,bottom,Shader.TileMode.CLAMP));canvas.drawRoundRect(rect,r,r,p);p.setShader(null);
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(edge);p.setColor(0xafffffff);
                canvas.drawRoundRect(edge,edge,w-edge,h-base-edge,r-edge,r-edge,p);p.setStyle(Paint.Style.FILL);
                if(gloss){
                    canvas.save();Path clip=new Path();clip.addRoundRect(rect,r,r,Path.Direction.CW);canvas.clipPath(clip);
                    p.setShader(new LinearGradient(0,0,0,h*.48f,0x46ffffff,0x00ffffff,Shader.TileMode.CLAMP));canvas.drawRect(0,0,w,h*.48f,p);p.setShader(null);
                    p.setShader(new RadialGradient(w*.18f,h*.12f,Math.max(1,w*.27f),0x90ffffff,0x00ffffff,Shader.TileMode.CLAMP));canvas.drawOval(w*.035f,h*.025f,w*.42f,h*.24f,p);p.setShader(null);canvas.restore();
                }
            }
            canvas.restore();
        }
        private void wave(Canvas canvas,float w,float h,float f,int color,boolean reverse){
            Path path=new Path();float y=h*f;float a=Math.min(h*.10f,w*.09f);path.moveTo(0,y);
            if(reverse)path.cubicTo(w*.35f,y-a,w*.60f,y+a,w,y-a*.5f);else path.cubicTo(w*.38f,y+a,w*.68f,y-a,w,y-a*.4f);
            path.lineTo(w,h);path.lineTo(0,h);path.close();p.setColor(color);canvas.drawPath(path,p);
        }
        @Override public void setAlpha(int a){p.setAlpha(a);invalidateSelf();}
        @Override public void setColorFilter(ColorFilter f){p.setColorFilter(f);invalidateSelf();}
        @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
        @Override public void getOutline(Outline outline){Rect b=getBounds();if(mode==0)outline.setRoundRect(b,d(c,radius));else outline.setRect(b);}
    }
    static void raised(View v,int top,int bottom,int radius){
        Context c=v.getContext();v.setBackground(card(c,top,bottom,radius,true));v.setElevation(d(c,4));
    }
    /** Android pressed state drives a real scale/elevation response; click semantics remain native. */
    static final class PressCard extends LinearLayout {
        private boolean ready;
        PressCard(Context c,int top,int bottom,int radius){
            super(c);setOrientation(VERTICAL);setGravity(Gravity.CENTER);setClickable(true);setFocusable(true);
            raised(this,top,bottom,radius);setSoundEffectsEnabled(true);
            GradientDrawable mask=new GradientDrawable();mask.setColor(Color.WHITE);mask.setCornerRadius(d(c,radius));
            setForeground(new RippleDrawable(ColorStateList.valueOf(0x34256b70),null,mask));ready=true;
        }
        @Override protected void drawableStateChanged(){super.drawableStateChanged();if(!ready)return;
            boolean down=isPressed()&&isEnabled();animate().cancel();animate().scaleX(down?.94f:1f).scaleY(down?.94f:1f).translationZ(down?-d(getContext(),3):0).setDuration(down?75:140).start();
        }
        @Override protected void onDetachedFromWindow(){animate().cancel();setScaleX(1);setScaleY(1);setTranslationZ(0);super.onDetachedFromWindow();}
    }
    /** Layered icon strokes/fills provide small raised highlights without bitmap stretching. */
    static final class Icon extends View {
        final Drawable shape;final int color;
        Icon(Context c,int res,int color){super(c);shape=c.getDrawable(res).mutate();this.color=color;setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);int w=getWidth(),h=getHeight();int pad=d(getContext(),2);int off=d(getContext(),1);
            shape.setBounds(pad,pad,w-pad,h-pad);canvas.save();canvas.translate(0,off*1.7f);shape.setTint(mix(color,0xff124052,.32f));shape.draw(canvas);canvas.restore();
            canvas.save();canvas.translate(0,-off*.65f);shape.setTint(mix(color,Color.WHITE,.44f));shape.draw(canvas);canvas.restore();
            shape.setTint(color);shape.draw(canvas);
        }
    }
}
