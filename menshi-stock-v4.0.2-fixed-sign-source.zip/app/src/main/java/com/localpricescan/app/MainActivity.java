package com.localpricescan.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

/** 概念图首页：真实库存统计、固定比例立体八宫格、三个辅助入口。 */
public final class MainActivity extends Activity {
    private static final int NEW_ITEM=311;
    private ProductDatabase db;
    private TextView productCount,stockQuantity,stockValue;
    private String pendingBarcode;
    private boolean scanning;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);AppUi.apply(this);db=new ProductDatabase(this);
        getWindow().setBackgroundDrawableResource(R.drawable.bg_app_surface);
        float density=getResources().getDisplayMetrics().density;
        int widthDp=(int)(getResources().getDisplayMetrics().widthPixels/density);
        int heightDp=(int)(getResources().getDisplayMetrics().heightPixels/density);
        boolean compactHome=heightDp<680;
        int margin=12, gap=7;
        int tileWidth=Math.max(48,(widthDp-2*margin-8-3*gap)/4);
        int tileHeight=Math.min(compactHome?98:118,Math.round(tileWidth*1.22f));
        LinearLayout root=StoreUi.column(this);root.setBackground(HomeArt.page(this));
        root.setClipChildren(false);root.setClipToPadding(false);setContentView(root);
        LinearLayout header=StoreUi.row(this);header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(14),dp(10),dp(12),dp(18));header.setBackground(HomeArt.header(this));
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.ic_store_brand_header);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setContentDescription("门市进销存品牌标志");
        LinearLayout.LayoutParams logoLp=StoreUi.lp(dp(58),dp(58));logoLp.rightMargin=dp(9);header.addView(logo,logoLp);
        LinearLayout nameGroup=StoreUi.column(this);
        LinearLayout titleRow=StoreUi.row(this);
        TextView brand=StoreUi.text(this,"门市进销存",widthDp<350?19:22,true);brand.setTextColor(0xffffffff);brand.setSingleLine(true);
        titleRow.addView(brand);TextView version=StoreUi.text(this,"",10,true);version.setTextColor(0xfff0ffff);
        try{version.setText("V"+getPackageManager().getPackageInfo(getPackageName(),0).versionName);}catch(PackageManager.NameNotFoundException ignored){}
        LinearLayout.LayoutParams verLp=StoreUi.lp(-2,-2);verLp.leftMargin=dp(5);titleRow.addView(version,verLp);nameGroup.addView(titleRow);
        TextView sub=StoreUi.text(this,"商品 · 入库 · 销售 · 库存 · 报表",widthDp<350?9:11,false);sub.setTextColor(0xfff0fffa);sub.setSingleLine(true);nameGroup.addView(sub);
        header.addView(nameGroup,new LinearLayout.LayoutParams(0,-2,1));
        android.widget.ImageButton settings=new android.widget.ImageButton(this);settings.setImageResource(R.drawable.ic_home_gear);
        android.graphics.drawable.GradientDrawable gearMask=StoreUi.round(0xffffffff,18,this);
        settings.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x45ffffff),null,gearMask));settings.setScaleType(ImageView.ScaleType.CENTER_INSIDE);settings.setPadding(dp(5),dp(5),dp(5),dp(5));
        settings.setContentDescription("设置");header.addView(settings,StoreUi.lp(dp(36),dp(44)));settings.setOnClickListener(v->{
            android.widget.PopupMenu menu=new android.widget.PopupMenu(this,settings);
            menu.getMenu().add(0,1,0,"操作日志");menu.getMenu().add(0,2,1,"备份恢复");
            menu.setOnMenuItemClickListener(item->{if(item.getItemId()==1){AuditTrail.record(this,"功能入口","操作日志","首页设置");activity(StoreAuditActivity.class,null);return true;}if(item.getItemId()==2){AuditTrail.record(this,"功能入口","备份恢复","首页设置");activity(StoreBackupActivity.class,null);return true;}return false;});menu.show();
        });
        root.addView(header,StoreUi.lp(-1,dp(compactHome?98:120)));
        LinearLayout body=StoreUi.column(this);body.setPadding(dp(margin),dp(compactHome?6:10),dp(margin),0);body.setClipChildren(false);body.setClipToPadding(false);
        root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout stats=StoreUi.row(this);stats.setClipChildren(false);stats.setClipToPadding(false);
        productCount=stat(stats,"商品总数","—","种",0xff6ac2a2,0xff248f67,0xffffffff,false);
        stockQuantity=stat(stats,"库存总量","—","",0xff7ac3e0,0xff287db1,0xffffffff,false);
        stockValue=stat(stats,"库存金额","—","",0xffffce84,0xffe8993d,0xffffffff,true);
        body.addView(stats,StoreUi.lp(-1,dp(compactHome?68:78)));
        StoreUi.gap(body,compactHome?12:20);flexGap(body,1f);

        LinearLayout gridCard=StoreUi.column(this);gridCard.setClipChildren(false);gridCard.setClipToPadding(false);
        gridCard.setPadding(dp(4),dp(8),dp(4),dp(8));gridCard.setBackground(StoreUi.round(0x90ffffff,19,this));
        body.addView(gridCard,StoreUi.lp(-1,-2));
        String[] names={"扫码查价","商品管理","商品入库","商品销售","内部领用","库存查询","统计报表","业务流水"};
        int[] icons={R.drawable.ic_home_scan,R.drawable.ic_home_layers,R.drawable.ic_home_in,R.drawable.ic_home_sale,
                R.drawable.ic_home_person,R.drawable.ic_home_stock,R.drawable.ic_home_reports,R.drawable.ic_home_records};
        int[][] colors={{0xfff0faff,0xffcce8f8},{0xfffff9e9,0xffffe4b9},
                {0xffeffcf4,0xffc6ead7},{0xfffaf2ff,0xffe1c9f2},
                {0xfffff5e5,0xffffdfb4},{0xfff0faff,0xffcbe5f8},
                {0xfffaf1ff,0xffe0cff5},{0xfff0fbfa,0xffc9e9e8}};
        int[] iconColors={0xff1591a1,0xffe49a2e,0xff239a70,0xff9262c7,0xffe39a37,0xff238bc2,0xff9663c3,0xff24989d};
        for(int rowIndex=0;rowIndex<2;rowIndex++){
            LinearLayout tileRow=StoreUi.row(this);tileRow.setClipChildren(false);tileRow.setClipToPadding(false);
            if(rowIndex>0)StoreUi.gap(gridCard,compactHome?12:16);
            gridCard.addView(tileRow,StoreUi.lp(-1,dp(tileHeight)));
            for(int col=0;col<4;col++){
                final int index=rowIndex*4+col;
                HomeArt.PressCard tile=new HomeArt.PressCard(this,colors[index][0],colors[index][1],16);
                int iconSize=Math.max(28,Math.min(45,Math.round(tileWidth*.54f)));
                tile.addView(new HomeArt.Icon(this,icons[index],iconColors[index]),StoreUi.lp(dp(iconSize),dp(iconSize)));
                StoreUi.gap(tile,6);
                TextView label=StoreUi.text(this,names[index],widthDp<350?12:13,true);label.setTextColor(0xff17333c);label.setGravity(Gravity.CENTER);
                label.setSingleLine(true);label.setIncludeFontPadding(false);tile.addView(label);
                LinearLayout.LayoutParams tileLp=new LinearLayout.LayoutParams(0,-1,1);
                if(col<3)tileLp.rightMargin=dp(gap);
                tileRow.addView(tile,tileLp);tile.setContentDescription(names[index]);tile.setOnClickListener(v->open(index));
            }
        }
        StoreUi.gap(body,compactHome?16:24);flexGap(body,.65f);
        LinearLayout foot=StoreUi.row(this);foot.setClipChildren(false);foot.setClipToPadding(false);
        footer(foot,"其他出库",R.drawable.ic_home_truck,0xff259b77,false,v->activity(StoreDocumentActivity.class,"OTHER"));
        footer(foot,"库存盘点",R.drawable.ic_home_count,0xffdc942f,false,v->activity(StoreCountActivity.class,null));
        footer(foot,"备份恢复",R.drawable.ic_home_database,0xff8e62c2,true,v->activity(StoreBackupActivity.class,null));
        body.addView(foot,StoreUi.lp(-1,dp(compactHome?46:52)));StoreUi.gap(body,compactHome?22:38);flexGap(body,1.35f);
        if(state!=null)pendingBarcode=state.getString("pendingBarcode");
    }
    private int dp(float n){return StoreUi.d(this,n);}
    private void flexGap(LinearLayout parent,float weight){View gap=new View(this);parent.addView(gap,new LinearLayout.LayoutParams(1,0,weight));}
    private TextView stat(LinearLayout row,String caption,String number,String unit,int top,int bottom,int fg,boolean last){
        LinearLayout card=StoreUi.column(this);card.setPadding(dp(4),dp(4),dp(4),dp(4));
        card.setGravity(Gravity.CENTER);HomeArt.raised(card,top,bottom,14);
        TextView title=StoreUi.text(this,caption,12,true);title.setTextColor(fg);title.setGravity(Gravity.CENTER);title.setSingleLine(true);card.addView(title,StoreUi.lp(-1,-2));
        TextView value=StoreUi.text(this,number+unit,21,true);value.setTextColor(fg);value.setGravity(Gravity.CENTER);value.setSingleLine(true);
        androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(value,10,22,1,android.util.TypedValue.COMPLEX_UNIT_SP);card.addView(value,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);if(!last)p.rightMargin=dp(7);row.addView(card,p);
        return value;
    }
    private void footer(LinearLayout row,String label,int res,int color,boolean last,View.OnClickListener listener){
        HomeArt.PressCard b=new HomeArt.PressCard(this,0xfffcffff,0xffe5f1ef,13);b.setOrientation(LinearLayout.HORIZONTAL);
        b.addView(new HomeArt.Icon(this,res,color),StoreUi.lp(dp(23),dp(23)));
        TextView text=StoreUi.text(this,label,12,true);text.setTextColor(0xff18333b);text.setSingleLine(true);text.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp=StoreUi.lp(-2,-2);tp.leftMargin=dp(3);b.addView(text,tp);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);if(!last)p.rightMargin=dp(7);
        row.addView(b,p);b.setContentDescription(label);b.setOnClickListener(v->{AuditTrail.record(this,"功能入口",label,"首页底部");listener.onClick(v);});
    }
    private void activity(Class<?> screen,String kind){Intent i=new Intent(this,screen);if(kind!=null)i.putExtra("kind",kind);BackPreview.capture(this);startActivity(i);}
    private void open(int index){
        AuditTrail.record(this,"功能入口",new String[]{"扫码查价","商品管理","商品入库","商品销售",
                "内部领用","库存查询","统计报表","业务流水"}[index],"首页八宫格");
        switch(index){
            case 0:startScanner();break;
            case 1:activity(ProductListActivity.class,null);break;
            case 2:activity(StoreDocumentActivity.class,"IN");break;
            case 3:activity(StoreDocumentActivity.class,"SALE");break;
            case 4:activity(StoreDocumentActivity.class,"ISSUE");break;
            case 5:activity(StoreStockActivity.class,null);break;
            case 6:activity(StoreReportsActivity.class,null);break;
            case 7:activity(StoreRecordsActivity.class,null);break;
        }
    }
    @Override protected void onResume(){
        super.onResume();scanning=false;
        try{AuditTrail.record(this,"打开页面","首页","查看门市数据概览");}catch(Exception ignored){}
        if(db!=null && productCount!=null){
            try{
                int n=db.count();long totalQty=0;
                java.math.BigDecimal stockCents=java.math.BigDecimal.ZERO;
                for(InventoryStore.StockRow row:new InventoryStore(db).stocks()){
                    if(row.current<=0)continue;
                    totalQty=Math.addExact(totalQty,row.current);
                    ProductDatabase.Product p=db.get(row.barcode);
                    if(p!=null)stockCents=stockCents.add(java.math.BigDecimal.valueOf(p.purchaseCents)
                            .multiply(java.math.BigDecimal.valueOf(row.current))
                            .divide(java.math.BigDecimal.valueOf(1000),0,java.math.RoundingMode.HALF_UP));
                }
                productCount.setText(n+"种");stockQuantity.setText(InventoryStore.qty(totalQty));
                stockValue.setText(Money.show(stockCents.longValueExact()));
            }catch(Exception e){productCount.setText("—");stockQuantity.setText("—");stockValue.setText("—");}
        }
    }
    private void startScanner(){
        if(scanning)return;scanning=true;IntentIntegrator i=new IntentIntegrator(this);
        i.setCaptureActivity(PortraitCaptureActivity.class);i.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES);
        i.setPrompt("将商品条形码放入扫描框");i.setBeepEnabled(false);i.setOrientationLocked(true);
        try{i.initiateScan();}catch(RuntimeException e){scanning=false;Toast.makeText(this,"扫码无法启动，请检查相机权限",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        if(request==NEW_ITEM){super.onActivityResult(request,result,data);String code=pendingBarcode;pendingBarcode=null;
            if(result==RESULT_OK&&code!=null&&db.get(code)!=null)detail(code);return;}
        IntentResult scan=IntentIntegrator.parseActivityResult(request,result,data);
        if(scan==null){super.onActivityResult(request,result,data);return;}scanning=false;
        String code=BarcodeKey.scanned(scan.getContents());if(code.isEmpty())return;
        AuditTrail.record(this,"扫码查价",code,"已扫描条形码并查询本地商品库");
        try{ProductDatabase.Product p=db.get(code);
            if(p!=null){Toast.makeText(this,"该商品已登记，正在显示已有商品",Toast.LENGTH_SHORT).show();detail(p.barcode);}
            else{pendingBarcode=code;Intent i=new Intent(this,ProductEditorActivity.class);i.putExtra("barcode",code);startActivityForResult(i,NEW_ITEM);}
        }catch(SQLiteException e){Toast.makeText(this,"商品查询失败",Toast.LENGTH_LONG).show();}
    }
    private void detail(String code){Intent i=new Intent(this,ProductDetailActivity.class);i.putExtra("barcode",code);
        i.putExtra("scanResult",true);BackPreview.capture(this);startActivity(i);}
    @Override protected void onSaveInstanceState(Bundle state){super.onSaveInstanceState(state);state.putString("pendingBarcode",pendingBarcode);}
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
