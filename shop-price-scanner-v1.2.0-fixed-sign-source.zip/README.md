# 商品查价 V1.2.0 — 安卓离线版 / 自然风 UI 整改

## 本版整改范围（依据已确认的需求）

- 首页保留「扫码查询」「商品列表」「备份与恢复」三个入口，采用淡绿树叶自然风图片背景、米白卡片和绿/橙/紫的按钮，按钮有按下态和波纹反馈。
- 首次扫到新条码，进入新商品页面，可填写商品名称、进价和售价；照片**非必填**，可用相机拍照或从相册选择。
- 已录商品再次扫描，显示商品照片（若无照片显示文字占位）、名称、条码、进价和售价。仍然只在按下扫码按钮后启动扫描器。
- 商品列表支持按名称或条码实时搜索，显示照片缩略图、商品名称、条码、进价、售价；没有照片使用占位图。
- 商品列表单击只进入详情页，长按商品出现「编辑商品 / 删除商品」，删除有二次确认；详情卡片也支持长按操作。
- 编辑商品可修改名称、进价、售价，并可拍照、相册选择、更换或删除照片。
- 备份与恢复页面视觉统一。导出 JSON 包含全部商品资料和照片（照片以 Base64 编码），支持恢复 V1 旧备份和 V2 带照片备份。
- 全部数据留在手机本地 SQLite；没有 `INTERNET` 权限。

## 兼容与固定签名

- 原包名 `com.localpricescan.app`；`versionCode=5`，`versionName=1.2.0`。
- 原 SQLite 文件 `offline_products.db` 继续使用，保留 `products` 表；数据库从 V1 升至 V2 **仅增加** `product_images` 表，旧商品不会被清空。
- 保留 `signing/release-keystore.p12.enc`，并沿用 `SHOP_SIGNING_PASSWORD`。签名证书 SHA-256 应为 `EC:12:10:E1:E8:7C:E2:06:3F:3C:AA:5E:B2:4D:BB:05:B1:41:C2:04:33:AE:8D:F8:21:F0:CE:FD:31:05:7F:3F`。
- 从已安装的 V1.1.2 固定签名版升级，可在签名与设备兼容的条件下覆盖安装并保留商品；不要在正式使用时卸载或清除数据。
- **不要**将私有签名备份 ZIP 或明文密码上传到公开仓库。

## 构建

- 构建依赖：Java 17、Gradle 8.9、Android SDK 35、Android Gradle Plugin 8.7.3。
- `signing/release-keystore.p12.enc` 为加密私钥，源码不含私钥明文和密码。
- `.github/workflows/build-release.yml` 提供更新后的 GitHub Actions 正式版构建流程；外层 GitHub 仓库应使用该工作流，才会从新版本 ZIP 构建正式签名 APK。
- 在外层 GitHub 仓库上传 `shop-price-scanner-v1.2.0-fixed-sign-source.zip`；需要将仓库根目录的 `.github/workflows/build-release.yml` 更新为此包中同名文件。工作流根据 `*-fixed-sign-source.zip` 版本号自动选择最新源码包，便于后续更新。

## 使用限制与数据安全

- 商品照片压缩后保存在本地 SQLite BLOB 表；单张照片限约 1.2MB，APP 内拍照或选相册后自动压缩 JPEG。
- 备份文件采用 JSON V2，保留原有约 50MB 上限；当商品照片较多超出此大小，APP 会明确提示备份失败，**不会**宣称成功。不能把仅存在手机中的照片视为已有备份。
- 任何恢复操作先校验文件，再弹出替换确认；写入商品与照片均使用单个 SQLite 事务，失败回滚。
- 本环境没有 Android SDK，已做 XML/资源引用静态核查和纯 Java 条码金额测试。**尚未进行 Android Gradle 构建或真实手机运行验收**，需通过上传仓库触发 GitHub Actions 编译后再安装测试。
