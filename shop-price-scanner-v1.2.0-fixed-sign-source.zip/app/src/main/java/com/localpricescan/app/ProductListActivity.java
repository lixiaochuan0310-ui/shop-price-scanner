package com.localpricescan.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 单击看详情；长按才提供编辑、删除；支持名称和条码实时搜索。 */
public final class ProductListActivity extends Activity {
    private ProductDatabase db;
    private final List<ProductDatabase.Product> all = new ArrayList<>();
    private final List<ProductDatabase.Product> visible = new ArrayList<>();
    private BaseAdapter adapter;
    private TextView countView;
    private EditText search;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppUi.apply(this);
        setContentView(R.layout.activity_product_list);
        db = new ProductDatabase(this);
        findViewById(R.id.listBackButton).setOnClickListener(v -> finish());
        countView = findViewById(R.id.productCountText);
        search = findViewById(R.id.productSearch);
        ListView list = findViewById(R.id.productList);
        list.setEmptyView(findViewById(R.id.emptyProducts));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return visible.size(); }
            @Override public Object getItem(int index) { return visible.get(index); }
            @Override public long getItemId(int index) { return index; }
            @Override public View getView(int index, View reused, ViewGroup parent) {
                View row = reused == null ? LayoutInflater.from(ProductListActivity.this)
                        .inflate(R.layout.row_product,parent,false) : reused;
                ProductDatabase.Product p = visible.get(index);
                ((TextView)row.findViewById(R.id.rowName)).setText(p.name);
                ((TextView)row.findViewById(R.id.rowBarcode)).setText(p.barcode);
                ((TextView)row.findViewById(R.id.rowPrices)).setText(
                        "进价 " + Money.show(p.purchaseCents) + "   ·   售价 " + Money.show(p.saleCents));
                PhotoUtils.show(db.photo(p.barcode),
                        (ImageView)row.findViewById(R.id.rowImage),
                        (TextView)row.findViewById(R.id.rowNoPhoto));
                return row;
            }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent,view,position,id) -> {
            ProductDatabase.Product p = visible.get(position);
            Intent intent = new Intent(this,ProductDetailActivity.class);
            intent.putExtra("barcode",p.barcode);
            startActivity(intent);
        });
        list.setOnItemLongClickListener((parent,view,position,id) -> {
            ProductDatabase.Product p = visible.get(position);
            ProductActions.menu(this,db,p,this::refresh);
            return true;
        });
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count) { filter(); }
            @Override public void afterTextChanged(Editable e) {}
        });
    }

    @Override protected void onResume() { super.onResume(); if(db != null) refresh(); }

    private void refresh() {
        try { all.clear();all.addAll(db.all());filter(); }
        catch (SQLiteException e) { Toast.makeText(this,"读取商品列表失败",Toast.LENGTH_LONG).show(); }
    }

    private void filter() {
        String q = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        visible.clear();
        for (ProductDatabase.Product p : all) {
            if (q.isEmpty() || p.name.toLowerCase(Locale.ROOT).contains(q) || p.barcode.contains(q)) visible.add(p);
        }
        countView.setText(q.isEmpty() ? "共 " + all.size() + " 件商品 · 长按可编辑或删除" :
                "找到 " + visible.size() + " 件商品");
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    @Override protected void onDestroy() { if(db != null) db.close(); super.onDestroy(); }
}
