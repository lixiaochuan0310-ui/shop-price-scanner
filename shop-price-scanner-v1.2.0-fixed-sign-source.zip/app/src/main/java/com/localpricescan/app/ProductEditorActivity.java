package com.localpricescan.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/** 首次新增和修改共用编辑页，商品照片可拍照、选相册、删除或留空。 */
public final class ProductEditorActivity extends Activity {
    private static final int CAPTURE = 410, CHOOSE = 411, CAMERA_PERMISSION = 412;
    private ProductDatabase db;
    private String barcode;
    private boolean editing;
    private Uri captureUri;
    private byte[] imageBytes;
    private EditText nameInput, purchaseInput, saleInput;
    private ImageView imagePreview;
    private TextView noPhoto;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppUi.apply(this);
        setContentView(R.layout.activity_product_editor);
        db = new ProductDatabase(this);
        barcode = getIntent().getStringExtra("barcode");
        editing = getIntent().getBooleanExtra("edit",false);
        if (barcode == null || barcode.trim().isEmpty()) { finish(); return; }
        if (state != null) {
            String uri = state.getString("captureUri");
            if (uri != null) captureUri = Uri.parse(uri);
        }
        ((TextView) findViewById(R.id.editorTitle)).setText(editing ? "编辑商品" : "录入新商品");
        ((TextView) findViewById(R.id.editorBarcode)).setText("条形码  " + barcode);
        nameInput = findViewById(R.id.editorName);
        purchaseInput = findViewById(R.id.editorPurchase);
        saleInput = findViewById(R.id.editorSale);
        imagePreview = findViewById(R.id.editorPhoto);
        noPhoto = findViewById(R.id.editorNoPhoto);
        findViewById(R.id.editorBack).setOnClickListener(v -> finish());
        findViewById(R.id.editorCamera).setOnClickListener(v -> capture());
        findViewById(R.id.editorGallery).setOnClickListener(v -> choose());
        findViewById(R.id.editorRemovePhoto).setOnClickListener(v -> {
            imageBytes = null; updatePreview();
        });
        findViewById(R.id.editorSave).setOnClickListener(v -> save());
        if (editing) {
            ProductDatabase.Product p = db.get(barcode);
            if (p == null) { Toast.makeText(this,"商品不存在",Toast.LENGTH_LONG).show(); finish(); return; }
            barcode = p.barcode;
            nameInput.setText(p.name);
            purchaseInput.setText(Money.input(p.purchaseCents));
            saleInput.setText(Money.input(p.saleCents));
            imageBytes = db.photo(barcode);
        }
        if (state != null) {
            nameInput.setText(state.getString("name",nameInput.getText().toString()));
            purchaseInput.setText(state.getString("cost",purchaseInput.getText().toString()));
            saleInput.setText(state.getString("sale",saleInput.getText().toString()));
            // 系统回收进程后恢复已保存图片，照片重新选择即可，无需强制上传。
        }
        updatePreview();
    }

    private void updatePreview() {
        PhotoUtils.show(imageBytes,imagePreview,noPhoto);
        findViewById(R.id.editorRemovePhoto).setVisibility(imageBytes == null ? View.GONE : View.VISIBLE);
    }

    private void capture() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION);
            return;
        }
        try {
            captureUri = PhotoUtils.newCaptureUri(this);
            startActivityForResult(PhotoUtils.photoIntent(captureUri),CAPTURE);
        } catch (Exception e) { Toast.makeText(this,"无法启动拍照",Toast.LENGTH_LONG).show(); }
    }

    @Override public void onRequestPermissionsResult(int request, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(request,perms,grants);
        if (request == CAMERA_PERMISSION && grants.length > 0 &&
                grants[0] == PackageManager.PERMISSION_GRANTED) capture();
        else if (request == CAMERA_PERMISSION) Toast.makeText(this,"需要相机权限才能拍照",Toast.LENGTH_SHORT).show();
    }

    private void choose() {
        try { startActivityForResult(PhotoUtils.galleryIntent(),CHOOSE); }
        catch (Exception e) { Toast.makeText(this,"无法打开相册",Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if (result != RESULT_OK) return;
        Uri selected = request == CAPTURE ? captureUri :
                (request == CHOOSE && data != null ? data.getData() : null);
        if (selected == null) return;
        try {
            imageBytes = PhotoUtils.readJpeg(this,selected);
            updatePreview();
        } catch (Exception e) { Toast.makeText(this,"照片读取失败，请重试",Toast.LENGTH_LONG).show(); }
    }

    private void save() {
        String name = nameInput.getText().toString().trim();
        Long cost = Money.parseCents(purchaseInput.getText().toString());
        Long sale = Money.parseCents(saleInput.getText().toString());
        if (name.isEmpty()) { nameInput.setError("请输入名称"); nameInput.requestFocus(); return; }
        if (cost == null) { purchaseInput.setError("请输入有效进价，最多两位小数"); purchaseInput.requestFocus(); return; }
        if (sale == null) { saleInput.setError("请输入有效售价，最多两位小数"); saleInput.requestFocus(); return; }
        try {
            ProductDatabase.Product p = new ProductDatabase.Product(barcode,name,cost,sale);
            if (editing) {
                if (!db.update(p,imageBytes)) { Toast.makeText(this,"原商品不存在",Toast.LENGTH_LONG).show();return; }
            } else {
                if (db.get(barcode) != null) {
                    new AlertDialog.Builder(this).setTitle("该商品已存在")
                            .setMessage("此条形码已经有商品，请返回查看或编辑已有商品。")
                            .setPositiveButton("知道了",null).show();
                    return;
                }
                db.insert(p,imageBytes);
            }
            setResult(RESULT_OK); finish();
        } catch (SQLiteConstraintException dup) { Toast.makeText(this,"条码已存在",Toast.LENGTH_LONG).show(); }
          catch (Exception e) { Toast.makeText(this,"保存失败，原商品数据未修改",Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("captureUri",captureUri == null ? null : captureUri.toString());
        if (nameInput != null) {
            out.putString("name",nameInput.getText().toString());
            out.putString("cost",purchaseInput.getText().toString());
            out.putString("sale",saleInput.getText().toString());
        }
    }

    @Override protected void onDestroy() { if (db != null) db.close(); super.onDestroy(); }
}
