package com.localpricescan.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

/** 首页扫码必须由点击触发；已有商品显示照片和价格，新商品进入选填照片的录入页。 */
public final class MainActivity extends Activity {
    private static final int EDIT_REQUEST = 308;
    private ProductDatabase database;
    private View initialCard, resultCard;
    private TextView resultBarcode, resultName, resultPurchase, resultSale, resultNoPhoto, productCount;
    private ImageView resultPhoto;
    private String lastBarcode;
    private boolean scannerLaunching;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppUi.apply(this);
        setContentView(R.layout.activity_main);
        database = new ProductDatabase(this);
        initialCard = findViewById(R.id.initialCard);
        resultCard = findViewById(R.id.resultCard);
        resultBarcode = findViewById(R.id.resultBarcode);
        resultName = findViewById(R.id.resultName);
        resultPurchase = findViewById(R.id.resultPurchase);
        resultSale = findViewById(R.id.resultSale);
        resultNoPhoto = findViewById(R.id.resultNoPhoto);
        resultPhoto = findViewById(R.id.resultPhoto);
        productCount = findViewById(R.id.homeProductCount);

        findViewById(R.id.scanButton).setOnClickListener(v -> launchScanner());
        findViewById(R.id.scanAgainButton).setOnClickListener(v -> launchScanner());
        findViewById(R.id.editProductButton).setOnClickListener(v -> editCurrent());
        findViewById(R.id.productListButton).setOnClickListener(v ->
                startActivity(new Intent(this, ProductListActivity.class)));
        findViewById(R.id.backupButton).setOnClickListener(v ->
                startActivity(new Intent(this, BackupActivity.class)));
        lastBarcode = state == null ? null : state.getString("barcode");
        displayLastOrInitial();
    }

    @Override protected void onResume() {
        super.onResume();
        if (database != null) {
            try { productCount.setText("已录入 " + database.count() + " 件商品"); }
            catch (SQLiteException e) { productCount.setText("商品数量读取失败"); }
        }
    }

    private void displayLastOrInitial() {
        ProductDatabase.Product p = lastBarcode == null ? null : database.get(lastBarcode);
        if (p == null) {
            initialCard.setVisibility(View.VISIBLE);
            resultCard.setVisibility(View.GONE);
        } else showProduct(p);
    }

    private void launchScanner() {
        if (scannerLaunching || isFinishing() || isDestroyed()) return;
        scannerLaunching = true;
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setCaptureActivity(PortraitCaptureActivity.class);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES);
        integrator.setPrompt("将商品条形码放入扫描框");
        integrator.setBeepEnabled(false);
        integrator.setBarcodeImageEnabled(false);
        integrator.setOrientationLocked(true);
        try { integrator.initiateScan(); }
        catch (RuntimeException e) {
            scannerLaunching = false;
            Toast.makeText(this, "无法启动扫码，请检查相机权限", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        if (request == EDIT_REQUEST) {
            super.onActivityResult(request, result, data);
            displayLastOrInitial();
            return;
        }
        IntentResult scan = IntentIntegrator.parseActivityResult(request, result, data);
        if (scan == null) { super.onActivityResult(request, result, data); return; }
        scannerLaunching = false;
        String barcode = BarcodeKey.scanned(scan.getContents());
        if (barcode.isEmpty()) return;
        lastBarcode = barcode;
        try {
            ProductDatabase.Product p = database.get(barcode);
            if (p != null) showProduct(p);
            else {
                Intent intent = new Intent(this, ProductEditorActivity.class);
                intent.putExtra("barcode", barcode);
                startActivityForResult(intent, EDIT_REQUEST);
            }
        } catch (SQLiteException e) { Toast.makeText(this, "查询商品失败", Toast.LENGTH_LONG).show(); }
    }

    private void showProduct(ProductDatabase.Product p) {
        lastBarcode = p.barcode;
        resultName.setText(p.name);
        resultBarcode.setText("条形码  " + p.barcode);
        resultPurchase.setText(Money.show(p.purchaseCents));
        resultSale.setText(Money.show(p.saleCents));
        PhotoUtils.show(database.photo(p.barcode), resultPhoto, resultNoPhoto);
        initialCard.setVisibility(View.GONE);
        resultCard.setVisibility(View.VISIBLE);
    }

    private void editCurrent() {
        if (lastBarcode == null) return;
        ProductDatabase.Product p = database.get(lastBarcode);
        if (p == null) return;
        Intent intent = new Intent(this, ProductEditorActivity.class);
        intent.putExtra("barcode", p.barcode);
        intent.putExtra("edit", true);
        startActivityForResult(intent, EDIT_REQUEST);
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("barcode",lastBarcode);
    }

    @Override protected void onDestroy() {
        if (database != null) database.close();
        super.onDestroy();
    }
}
