# V4.0.3 UI 概念图对应清单

确认的十屏概念图：`confirmed-10-screens.png`。原图内商品、价格、时间均为展示示意，正式软件仅使用实际数据库内容。

| 概念图 | 正式页面 | 本版布局对应 |
|--|--|--|
| ①首页 | MainActivity | 青绿标题区、三项真实库存统计、4×2按宽度确定高度的立体八宫格、紧凑区间、底部波浪自适应剩余空间、彩色浮雕图标、原生按压/回弹反馈、三个带图标的底部入口、青绿色波浪；业务流水在八宫格，库存盘点底部 |
| ②商品列表 | ProductListActivity + activity_product_list.xml | 搜索、商品分类可横滑筛选、照片+名称+价格+库存紧凑卡片，长按操作 |
| ③商品详情 | ProductDetailActivity + activity_product_detail.xml | 大图按比例显示、分类条码信息、并列售价与库存、进价隐显 |
| ④商品入库 | StoreDocumentActivity(kind=IN) | 日期/供货商、可多商品入库、总金额/保存 |
| ⑤商品销售 | StoreDocumentActivity(kind=SALE) | 日期/客户、可多商品销售、金额和实收/保存 |
| ⑥库存查询 | StoreStockActivity | 搜索及照片、库存、售价紧凑列表，点进真实操作 |
| ⑦统计报表 | StoreReportsActivity | 依次选择日月年、数据范围、Excel/Word，预览导出 |
| ⑧报表预览 | StoreReportPreviewActivity | 实际数据横向可滚动表格、分页、返回与导出 |
| ⑨业务流水 | StoreRecordsActivity + StoreAuditActivity | 按业务类别和文字筛选、单据查看/删除、独立操作日志 |
| ⑩备份恢复 | StoreBackupActivity | 白色独立卡片、备份和恢复区分，操作日志随备份保留 |

**其他重要页面**：商品编辑、联网图库搜索、库存盘点、单位设置、退货/退库保留业务逻辑，复用统一淡青绿业务组件。

**真实性说明**：没有 Android 模拟器，本表为源码实现对应，不是逐像素对照通过证明。最终须用签名 APK 实机与图对比。
