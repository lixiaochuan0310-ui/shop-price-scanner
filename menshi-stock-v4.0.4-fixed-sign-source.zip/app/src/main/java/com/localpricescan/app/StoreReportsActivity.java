package com.localpricescan.app;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import java.util.Calendar;
import java.util.Locale;

/** 统计报表：按概念图依次选日期、数据类型和 Word/Excel；数据实际预览、导出均基于同一筛选条件。 */
public final class StoreReportsActivity extends SwipeBackActivity {
    private ProductDatabase db;
    private RadioGroup periodGroup,categoryGroup,formatGroup;
    private TextView dateText;
    private String selectedDate;
    private int periodIndex=1;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);db=new ProductDatabase(this);
        LinearLayout root=StoreUi.content(this,"统计报表");setContentView(root);
        LinearLayout body=StoreUi.padded(this,StoreUi.scroll(this,root));
        String today=InventoryStore.dateToday();selectedDate=today;

        LinearLayout filter=StoreUi.card(this);StoreUi.addCard(body,filter);
        section(filter,"1. 选择统计时间");
        periodGroup=choice(new String[]{"按日","按月","按年"},true,1);
        filter.addView(periodGroup);StoreUi.gap(filter,7);
        dateText=StoreUi.button(this,"▦   "+today.substring(0,7)+"   ▾",0xffeff7f5,StoreUi.INK);
        dateText.setTextSize(15);filter.addView(dateText);dateText.setOnClickListener(v->pickDate());
        periodGroup.setOnCheckedChangeListener((g,id)->{
            int index=g.indexOfChild(g.findViewById(id));if(index<0)return;
            periodIndex=index;showDate();
        });

        StoreUi.gap(filter,17);
        section(filter,"2. 选择导出内容");
        categoryGroup=choice(new String[]{"全部业务数据（入库、销售、领用、退货等）","销售数据",
                "库存数据（含期初、期末及变动）","内部领用数据"},false,0);
        filter.addView(categoryGroup);

        StoreUi.gap(filter,17);
        section(filter,"3. 选择文件格式");
        formatGroup=choice(new String[]{"Excel 表格（.xlsx）","Word 文档（.docx）"},false,0);
        filter.addView(formatGroup);StoreUi.gap(filter,14);
        LinearLayout actions=StoreUi.row(this);
        TextView preview=StoreUi.button(this,"◉  预览报表",0xffedf7f4,StoreUi.GREEN);
        TextView export=StoreUi.button(this,"⬇  导出报表",StoreUi.GREEN,0xffffffff);
        actions.addView(preview,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(0,-2,1);ep.leftMargin=StoreUi.d(this,9);
        actions.addView(export,ep);filter.addView(actions);
        preview.setOnClickListener(v->openPreview(false));export.setOnClickListener(v->openPreview(true));
        TextView note=StoreUi.text(this,"可先预览真实记录。导出的 Word 自动换行分页，Excel 保留完整字段和数值。",12,false);
        note.setTextColor(StoreUi.MUTED);StoreUi.gap(filter,9);filter.addView(note);

        showDate();
    }
    private void section(LinearLayout parent,String title){
        TextView heading=StoreUi.text(this,title,16,true);heading.setTextColor(StoreUi.INK);parent.addView(heading);StoreUi.gap(parent,9);
    }
    private RadioGroup choice(String[] labels,boolean horizontal,int initial){
        RadioGroup group=new RadioGroup(this);group.setOrientation(horizontal?RadioGroup.HORIZONTAL:RadioGroup.VERTICAL);
        for(int i=0;i<labels.length;i++){
            RadioButton r=new RadioButton(this);r.setId(android.view.View.generateViewId());r.setText(labels[i]);r.setTextColor(StoreUi.INK);
            r.setTextSize(horizontal?14:14);r.setButtonTintList(android.content.res.ColorStateList.valueOf(StoreUi.GREEN));
            r.setPadding(StoreUi.d(this,1),StoreUi.d(this,3),StoreUi.d(this,1),StoreUi.d(this,3));
            group.addView(r,horizontal?new RadioGroup.LayoutParams(0,-2,1):new RadioGroup.LayoutParams(-1,-2));
            if(i==initial)r.setChecked(true);
        }return group;
    }
    private void miniSummary(LinearLayout parent,String title,long[] values){
        LinearLayout row=StoreUi.column(this);row.setPadding(StoreUi.d(this,12),StoreUi.d(this,10),StoreUi.d(this,12),StoreUi.d(this,11));
        row.setBackground(StoreUi.round(0xfff0f8f5,12,this));
        TextView h=StoreUi.text(this,title+"  ·  "+values[0]+" 单",13,true);row.addView(h);StoreUi.gap(row,5);
        TextView amt=StoreUi.text(this,"销售总额  "+Money.show(values[1])+"     实收  "+Money.show(values[2]),14,true);
        amt.setTextColor(StoreUi.GREEN);row.addView(amt);parent.addView(row);
    }
    private int selection(RadioGroup group){
        int id=group.getCheckedRadioButtonId();if(id<0)return 0;
        int index=group.indexOfChild(group.findViewById(id));return Math.max(0,index);
    }
    private void showDate(){
        if(dateText==null)return;
        int n=periodIndex==0?10:periodIndex==1?7:4;
        dateText.setText("▦   "+selectedDate.substring(0,n)+"   ▾");
    }
    private void pickDate(){
        Calendar c=Calendar.getInstance();
        new DatePickerDialog(this,(view,y,m,d)->{
            selectedDate=String.format(Locale.ROOT,"%04d-%02d-%02d",y,m+1,d);
            showDate();
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }
    private void openPreview(boolean exportImmediately){
        String[] times={"day","month","year"}, kinds={"all","sales","stock","issue"};
        int p=selection(periodGroup),k=selection(categoryGroup);
        String date=selectedDate.substring(0,p==0?10:p==1?7:4);
        try{
            StoreReportData data=new StoreReportData(db,times[p],kinds[k],date);
            AuditTrail.record(this,exportImmediately?"申请导出报表":"预览报表",data.description(),
                    "格式："+(selection(formatGroup)==0?"Excel":"Word"));
            Intent intent=new Intent(this,StoreReportPreviewActivity.class);
            intent.putExtra("period",times[p]);intent.putExtra("category",kinds[k]);intent.putExtra("term",data.term);
            intent.putExtra("export_format",selection(formatGroup)==0?"xlsx":"docx");
            intent.putExtra("export_immediately",exportImmediately);
            BackPreview.capture(this);startActivity(intent);
        }catch(Exception e){new android.app.AlertDialog.Builder(this).setTitle("统计条件不正确")
                .setMessage(e.getMessage()).setPositiveButton("确定",null).show();}
    }
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
