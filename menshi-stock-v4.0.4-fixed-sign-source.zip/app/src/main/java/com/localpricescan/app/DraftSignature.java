package com.localpricescan.app;

import android.widget.EditText;
import android.widget.Spinner;

/** UI-only unsaved-form tracking, no changes to inventory or database. */
final class DraftSignature {
    private DraftSignature() {}
    static String of(Object... fields) {
        StringBuilder b=new StringBuilder();
        for(Object field:fields) {
            String value="";
            if(field instanceof EditText)value=((EditText)field).getText().toString();
            else if(field instanceof Spinner)value=Integer.toString(((Spinner)field).getSelectedItemPosition());
            else if(field!=null)value=String.valueOf(field);
            b.append(value.length()).append(':').append(value);
        }
        return b.toString();
    }
}
