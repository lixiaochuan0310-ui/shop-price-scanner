package com.localpricescan.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.HashSet;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;
import java.util.Locale;

/** 单击看详情；长按才提供编辑、删除；支持名称和条码实时搜索。 */
public final class ProductListActivity extends SwipeBackActivity {
    private ProductDatabase db;
    private final List<ProductDatabase.Product> all = new ArrayList<>();
    private final List<ProductDatabase.Product> visible = new ArrayList<>();
    private BaseAdapter adapter;
    // 每次打开商品列表默认隐藏；仅本次列表页面内记住用户展开的商品。
    private final Set<String> revealedCostBarcodes = new HashSet<>();
    private final Map<String,String> stockLabels = new HashMap<>();
    private TextView countView;
    private EditText search;
    private String selectedCategory="全部";
    private final String[] categories={"全部","设备","线材","辅材","其他"};
    private android.widget.LinearLayout categoryTabs;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppUi.apply(this);
        setContentView(R.layout.activity_product_list);
        db = new ProductDatabase(this);
        findViewById(R.id.listBackButton).setOnClickListener(v -> onBackPressed());
        countView = findViewById(R.id.productCountText);
        findViewById(R.id.productCreate).setOnClickListener(v -> createItem());
        search = findViewById(R.id.productSearch);
        categoryTabs=findViewById(R.id.categoryTabs);
        renderCategoryTabs();
        ListView list = findViewById(R.id.productList);
        list.setEmptyView(findViewById(R.id.emptyProducts));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return visible.size(); }
            @Override public Object getItem(int index) { return visible.get(index); }
            @Override public long getItemId(int index) { return index; }
            @Override public View getView(int index, View reused, ViewGroup parent) {
                View row = reused == null ? LayoutInflater.from(ProductListActivity.this)
                        .inflate(R.layout.row_product,parent,false) : reused;
                ProductDatabase.Product p = visible.get(index);
                ((TextView)row.findViewById(R.id.rowName)).setText(p.name);
                ((TextView)row.findViewById(R.id.rowBarcode)).setText(p.barcode);
                ((TextView)row.findViewById(R.id.rowStock)).setText(
                        stockLabels.getOrDefault(p.barcode,"库存：—"));
                ((TextView)row.findViewById(R.id.rowSale)).setText(
                        "售价 " + Money.show(p.saleCents));
                updateRowCost(row, p);
                // 商品卡片自身处理单击/长按。V2.0.7 新增可点击眼睛后，
                // ListView 的 onItemClick/onItemLongClick 会被子控件抢占而失效。
                // 直接绑定在每次复用的卡片上，避免依赖 ListView 的项目事件分发。
                row.setOnClickListener(v -> {
                    AuditTrail.record(ProductListActivity.this,"查看商品",p.barcode,p.name);
                    Intent intent = new Intent(ProductListActivity.this, ProductDetailActivity.class);
                    intent.putExtra("barcode", p.barcode);
                    BackPreview.capture(ProductListActivity.this);
                    startActivity(intent);
                });
                row.setOnLongClickListener(v -> {
                    ProductActions.menu(ProductListActivity.this, db, p, ProductListActivity.this::refresh);
                    return true;
                });
                // 眼睛只负责本商品进价的展开/收起，不触发卡片的单击和长按。
                ImageButton eye = row.findViewById(R.id.rowCostToggle);
                eye.setOnClickListener(v -> {
                    if (!revealedCostBarcodes.add(p.barcode)) revealedCostBarcodes.remove(p.barcode);
                    updateRowCost(row, p);
                    AuditTrail.record(ProductListActivity.this,
                            revealedCostBarcodes.contains(p.barcode)?"显示进价":"隐藏进价",p.barcode,p.name);
                });
                PhotoUtils.show(db.photo(p.barcode),
                        (ImageView)row.findViewById(R.id.rowImage),
                        (TextView)row.findViewById(R.id.rowNoPhoto));
                return row;
            }
        };
        list.setAdapter(adapter);
        search.setOnEditorActionListener((v,action,event)->{
            AuditTrail.record(this,"搜索商品",StoreUi.value(search),"商品列表关键词查询");return false;
        });
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count) { filter(); }
            @Override public void afterTextChanged(Editable e) {}
        });
    }

    private void renderCategoryTabs(){
        categoryTabs.removeAllViews();
        for(String cat:categories){
            boolean active=cat.equals(selectedCategory);
            TextView tab=StoreUi.button(this,cat,active?StoreUi.GREEN:0xffffffff,
                    active?0xffffffff:StoreUi.INK);
            tab.setTextSize(13);tab.setPadding(StoreUi.d(this,14),StoreUi.d(this,8),
                    StoreUi.d(this,14),StoreUi.d(this,8));
            android.widget.LinearLayout.LayoutParams p=new android.widget.LinearLayout.LayoutParams(-2,-2);
            p.rightMargin=StoreUi.d(this,8);categoryTabs.addView(tab,p);
            tab.setOnClickListener(v->{selectedCategory=cat;renderCategoryTabs();filter();
                AuditTrail.record(this,"筛选商品分类",cat,"商品列表分类切换");});
        }
    }
    private void createItem() {
        EditText input=new EditText(this);
        input.setSingleLine(true);input.setHint("输入商品条码");
        AlertDialog prompt=new AlertDialog.Builder(this).setTitle("录入新商品")
                .setView(input).setNegativeButton("取消",null)
                .setPositiveButton("下一步",(dialog,which)->{
                    String code=input.getText().toString().trim();
                    if(code.isEmpty()){
                        Toast.makeText(this,"商品条码不能为空",Toast.LENGTH_SHORT).show();return;
                    }
                    ProductDatabase.Product old=db.get(code);
                    if(old!=null){
                        Toast.makeText(this,"该商品已存在，可以长按编辑",Toast.LENGTH_LONG).show();return;
                    }
                    Intent i=new Intent(this,ProductEditorActivity.class);
                    i.putExtra("barcode",code);BackPreview.capture(this);startActivity(i);
                }).create();
        prompt.show();KeyboardGuard.forDialog(prompt);
    }

    private void updateRowCost(View row, ProductDatabase.Product p) {
        boolean revealed = revealedCostBarcodes.contains(p.barcode);
        TextView amount = row.findViewById(R.id.rowCostValue);
        ImageButton eye = row.findViewById(R.id.rowCostToggle);
        // 不在隐藏状态写出金额，避免旧的复用卡片意外显示上一件商品的进价。
        amount.setText(revealed ? Money.show(p.purchaseCents) : "");
        amount.setVisibility(revealed ? View.VISIBLE : View.GONE);
        eye.setImageResource(revealed ? R.drawable.ic_eye_open : R.drawable.ic_eye_closed);
        eye.setContentDescription(revealed ? "隐藏" + p.name + "的进价" : "显示" + p.name + "的进价");
    }

    @Override protected void onResume() { super.onResume(); if(db != null) refresh(); }

    private void refresh() {
        try {
            all.clear();all.addAll(db.all());stockLabels.clear();
            for(InventoryStore.StockRow stock:new InventoryStore(db).stocks()) {
                stockLabels.put(stock.barcode,"库存："+InventoryStore.qty(stock.current)+" "+stock.unit);
            }
            filter();
        }
        catch (SQLiteException e) { Toast.makeText(this,"读取商品列表失败",Toast.LENGTH_LONG).show(); }
    }

    private void filter() {
        String q = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        visible.clear();
        for (ProductDatabase.Product p : all) {
            if (("全部".equals(selectedCategory)||selectedCategory.equals(p.category)) &&
                    (q.isEmpty() || p.name.toLowerCase(Locale.ROOT).contains(q) || p.barcode.contains(q))) visible.add(p);
        }
        countView.setText(q.isEmpty() ? "共 " + all.size() + " 件商品 · 长按可编辑或删除" :
                "找到 " + visible.size() + " 件商品");
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    @Override protected void onDestroy() { if(db != null) db.close(); super.onDestroy(); }
}
