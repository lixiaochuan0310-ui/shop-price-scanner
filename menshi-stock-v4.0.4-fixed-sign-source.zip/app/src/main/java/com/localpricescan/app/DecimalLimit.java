package com.localpricescan.app;

import android.text.InputFilter;
import android.text.Spanned;

/** Prevent overly long fractional input while allowing the user to type and delete freely. */
final class DecimalLimit implements InputFilter {
    private final int places;
    DecimalLimit(int places) { this.places=places; }
    @Override public CharSequence filter(CharSequence source,int start,int end,
                                          Spanned dest,int dstart,int dend) {
        String candidate=dest.subSequence(0,dstart).toString()+
                source.subSequence(start,end)+dest.subSequence(dend,dest.length());
        if(candidate.matches("[0-9]{0,9}(?:\\.[0-9]{0,"+places+"})?"))return null;
        return "";
    }
}
