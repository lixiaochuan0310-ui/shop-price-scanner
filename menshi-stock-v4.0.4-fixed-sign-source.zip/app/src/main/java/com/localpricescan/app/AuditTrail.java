package com.localpricescan.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Single-user, offline, append-only business operation ledger. No delete/clear UI. */
final class AuditTrail {
    private AuditTrail() {}
    static void createSchema(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS operation_logs ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT NOT NULL UNIQUE,"+
                "created_ms INTEGER NOT NULL, action TEXT NOT NULL, target TEXT NOT NULL,"+
                "details TEXT NOT NULL DEFAULT '', before_json TEXT NOT NULL DEFAULT '',"+
                "after_json TEXT NOT NULL DEFAULT '', result TEXT NOT NULL DEFAULT '成功')");
        db.execSQL("CREATE INDEX IF NOT EXISTS operation_logs_time ON operation_logs(created_ms DESC)");
    }
    static void write(SQLiteDatabase db,String action,String target,String details,String before,String after,String result) {
        ContentValues v=new ContentValues();
        v.put("uuid", UUID.randomUUID().toString());v.put("created_ms",System.currentTimeMillis());
        v.put("action",safe(action));v.put("target",safe(target));v.put("details",safe(details));
        v.put("before_json",safe(before));v.put("after_json",safe(after));v.put("result",safe(result));
        db.insertOrThrow("operation_logs",null,v);
    }
    static void write(SQLiteDatabase db,String action,String target,String details) {
        write(db,action,target,details,"","","成功");
    }
    static void record(Context context,String action,String target,String details) {
        ProductDatabase helper=new ProductDatabase(context.getApplicationContext());
        try {write(helper.getWritableDatabase(),action,target,details);}finally {helper.close();}
    }
    static void failure(Context context,String action,String target,String details) {
        ProductDatabase helper=new ProductDatabase(context.getApplicationContext());
        try {write(helper.getWritableDatabase(),action,target,details,"","","失败");}
        finally {helper.close();}
    }
    static String safe(String s){return s==null?"":s;}
    static final class Entry {
        final long time;
        final String action,target,details,before,after,result;
        Entry(long time,String action,String target,String details,String before,String after,String result){
            this.time=time;this.action=action;this.target=target;this.details=details;
            this.before=before;this.after=after;this.result=result;
        }
    }
    static List<Entry> latest(SQLiteDatabase db,String query,int limit,int offset){
        List<Entry> results=new ArrayList<>();
        String q="%"+(query==null?"":query.trim())+"%";
        try(Cursor c=db.rawQuery("SELECT created_ms,action,target,details,before_json,after_json,result "+
                "FROM operation_logs WHERE (action LIKE ? OR target LIKE ? OR details LIKE ?) "+
                "ORDER BY created_ms DESC,id DESC LIMIT ? OFFSET ?",
                new String[]{q,q,q,Integer.toString(limit),Integer.toString(offset)})) {
            while(c.moveToNext())results.add(new Entry(c.getLong(0),c.getString(1),c.getString(2),
                    c.getString(3),c.getString(4),c.getString(5),c.getString(6)));
        }
        return results;
    }
}
