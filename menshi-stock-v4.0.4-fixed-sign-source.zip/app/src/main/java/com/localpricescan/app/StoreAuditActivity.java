package com.localpricescan.app;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Read-only local operation log. Business operations remain traceable after deletion. */
public final class StoreAuditActivity extends SwipeBackActivity {
    private ProductDatabase db;
    private LinearLayout entries;
    private EditText search;
    private TextView pageLabel;
    private int page=0;
    private static final int PAGE_SIZE=40;
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);db=new ProductDatabase(this);
        LinearLayout root=StoreUi.content(this,"操作日志");setContentView(root);
        LinearLayout body=StoreUi.padded(this,StoreUi.scroll(this,root));
        LinearLayout filters=StoreUi.card(this);StoreUi.addCard(body,filters);
        filters.addView(StoreUi.text(this,"本机全部业务操作留痕 · 不提供清空日志功能",14,true));
        StoreUi.gap(filters,9);
        search=StoreUi.input(this,"搜索操作、商品、单据或关键字","",1);filters.addView(search);
        StoreUi.gap(filters,8);
        LinearLayout nav=StoreUi.row(this);
        TextView previous=StoreUi.button(this,"上一页",0xffe4f3ec,StoreUi.GREEN);
        TextView next=StoreUi.button(this,"下一页",0xffe4f3ec,StoreUi.GREEN);
        nav.addView(previous,new LinearLayout.LayoutParams(0,-2,1));
        pageLabel=StoreUi.text(this,"第 1 页",13,false);pageLabel.setGravity(android.view.Gravity.CENTER);
        nav.addView(pageLabel,new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(next,new LinearLayout.LayoutParams(0,-2,1));filters.addView(nav);
        previous.setOnClickListener(v->{if(page>0){page--;reload();}});
        next.setOnClickListener(v->{page++;reload();});
        entries=StoreUi.column(this);body.addView(entries);
        search.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){page=0;reload();}
            @Override public void afterTextChanged(Editable e){}
        });
        reload();
    }
    private void reload(){
        if(entries==null)return;
        List<AuditTrail.Entry> records=AuditTrail.latest(db.getReadableDatabase(),StoreUi.value(search),PAGE_SIZE,page*PAGE_SIZE);
        if(records.isEmpty()&&page>0){page--;records=AuditTrail.latest(db.getReadableDatabase(),StoreUi.value(search),PAGE_SIZE,page*PAGE_SIZE);}
        pageLabel.setText("第 "+(page+1)+" 页");entries.removeAllViews();
        if(records.isEmpty()){entries.addView(StoreUi.text(this,"暂无符合条件的操作记录。",14,false));return;}
        for(AuditTrail.Entry item:records){
            String time=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.CHINA).format(new Date(item.time));
            LinearLayout card=StoreUi.card(this);StoreUi.addCard(entries,card);
            card.addView(StoreUi.text(this,item.action+"  ·  "+item.result,16,true));
            StoreUi.gap(card,5);
            TextView desc=StoreUi.text(this,time+"\n"+item.target+"\n"+item.details,13,false);
            desc.setTextColor(StoreUi.MUTED);card.addView(desc);
            card.setOnClickListener(v->new AlertDialog.Builder(this).setTitle(item.action)
                    .setMessage("操作时间："+time+"\n对象："+item.target+
                            "\n结果："+item.result+"\n内容："+item.details+
                            (item.before.isEmpty()?"":"\n\n操作前快照："+item.before)+
                            (item.after.isEmpty()?"":"\n\n操作后快照："+item.after))
                    .setPositiveButton("关闭",null).show());
        }
    }
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
