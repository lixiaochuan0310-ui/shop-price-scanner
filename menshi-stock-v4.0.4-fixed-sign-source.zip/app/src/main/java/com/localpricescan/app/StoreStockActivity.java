package com.localpricescan.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;
import java.util.Locale;

/** 商品当前库存、累计入库、售出和领用的实际记录展示。 */
public final class StoreStockActivity extends SwipeBackActivity {
    private ProductDatabase db;
    private InventoryStore store;
    private LinearLayout list;
    private EditText filter;
    private TextView count;
    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);db=new ProductDatabase(this);store=new InventoryStore(db);
        LinearLayout root=StoreUi.content(this,"库存查询");setContentView(root);
        LinearLayout body=StoreUi.padded(this,StoreUi.scroll(this,root));
        LinearLayout searchCard=StoreUi.card(this);StoreUi.addCard(body,searchCard);
        filter=StoreUi.input(this,"按商品名称或条码搜索","",1);searchCard.addView(filter);
        StoreUi.gap(searchCard,8);
        count=StoreUi.text(this,"",13,false);count.setTextColor(StoreUi.MUTED);searchCard.addView(count);
        StoreUi.gap(body,3);list=StoreUi.column(this);body.addView(list);
        String preset=getIntent().getStringExtra("barcode");
        if(preset!=null)filter.setText(preset);
        filter.setOnEditorActionListener((v,action,event)->{
            AuditTrail.record(this,"查询库存",StoreUi.value(filter),"库存关键词查询");return false;
        });
        filter.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){refresh();}
            @Override public void afterTextChanged(Editable e){}
        });
        TextView set=StoreUi.button(this,"商品单位与期初库存：点击下方商品进行设置",0xffe4f2e9,StoreUi.GREEN);
        set.setTextSize(13);body.addView(set);set.setOnClickListener(v->ToastHint());
    }
    private void ToastHint() {
        new AlertDialog.Builder(this).setMessage("点击任意商品，可设置基础单位、整箱换算和期初库存，也可以直接登记入库、销售或盘点。")
                .setPositiveButton("知道了",null).show();
    }
    private void go(Class<?> target,String barcode,String kind) {
        Intent i=new Intent(this,target);i.putExtra("barcode",barcode);
        if(kind!=null)i.putExtra("kind",kind);
        BackPreview.capture(this);startActivity(i);
    }
    private void choose(InventoryStore.StockRow s) {
        String[] opts={"登记入库","登记销售","登记内部领用","库存盘点","设置单位/期初库存","查看该商品流水"};
        new AlertDialog.Builder(this).setTitle(s.name).setItems(opts,(d,n)->{
            switch(n) {
                case 0:go(StoreDocumentActivity.class,s.barcode,"IN");break;
                case 1:go(StoreDocumentActivity.class,s.barcode,"SALE");break;
                case 2:go(StoreDocumentActivity.class,s.barcode,"ISSUE");break;
                case 3:go(StoreCountActivity.class,s.barcode,null);break;
                case 4:go(StoreSettingsActivity.class,s.barcode,null);break;
                case 5:go(StoreRecordsActivity.class,s.barcode,null);break;
            }
        }).show();
    }
    @Override protected void onResume(){super.onResume();if(list!=null)refresh();}
    private void refresh() {
        List<InventoryStore.StockRow> all=store.stocks();
        String q=StoreUi.value(filter).toLowerCase(Locale.ROOT);list.removeAllViews();int shown=0;
        for(InventoryStore.StockRow p:all) {
            if(!q.isEmpty()&&!p.name.toLowerCase(Locale.ROOT).contains(q)&&!p.barcode.contains(q))continue;
            shown++;
            LinearLayout card=StoreUi.row(this);
            card.setPadding(StoreUi.d(this,12),StoreUi.d(this,11),StoreUi.d(this,12),StoreUi.d(this,11));
            card.setBackground(StoreUi.border(0xffffffff,0xffe0ede8,this));
            android.widget.FrameLayout imageBox=new android.widget.FrameLayout(this);
            android.widget.ImageView image=new android.widget.ImageView(this);
            image.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
            imageBox.addView(image,new android.widget.FrameLayout.LayoutParams(-1,-1));
            TextView noPhoto=StoreUi.text(this,"商品",12,false);
            noPhoto.setGravity(android.view.Gravity.CENTER);
            imageBox.addView(noPhoto,new android.widget.FrameLayout.LayoutParams(-1,-1));
            card.addView(imageBox,StoreUi.lp(StoreUi.d(this,62),StoreUi.d(this,66)));
            PhotoUtils.show(db.photo(p.barcode),image,noPhoto);
            LinearLayout info=StoreUi.column(this);
            info.setPadding(StoreUi.d(this,10),0,0,0);
            card.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            info.addView(StoreUi.text(this,p.name,16,true));
            TextView code=StoreUi.text(this,p.barcode,12,false);code.setTextColor(StoreUi.MUTED);info.addView(code);
            StoreUi.gap(info,5);
            TextView qty=StoreUi.text(this,"库存："+InventoryStore.qty(p.current)+" "+p.unit,14,true);
            qty.setTextColor(p.current<=0?0xffad5a55:StoreUi.GREEN);info.addView(qty);
            TextView tip=StoreUi.text(this,"点击查看操作 ›",12,false);tip.setTextColor(StoreUi.MUTED);
            info.addView(tip);
            ProductDatabase.Product details=db.get(p.barcode);
            if(details!=null){TextView price=StoreUi.text(this,Money.show(details.saleCents),15,true);
                price.setTextColor(0xffca5143);card.addView(price);}
            StoreUi.addCard(list,card);card.setOnClickListener(v->choose(p));
        }
        count.setText("共 "+all.size()+" 种商品，当前显示 "+shown+" 种");
        if(shown==0){TextView empty=StoreUi.text(this,"没有符合条件的商品。请先在商品管理录入，或通过扫码添加。",15,false);
            list.addView(empty);}
    }
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
