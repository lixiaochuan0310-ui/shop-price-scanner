package com.localpricescan.app;

/** The confirmed portrait design, scaled to the usable window (not the full physical display). */
final class HomeLayout {
    final int margin,columnGap;
    final int tileWidth,tileHeight,headerHeight,statsHeight,footerHeight;
    final int topGap,statsGap,rowGap,footerGap,gridPadding,logoSize,labelHeight;
    HomeLayout(int width,int height) {
        margin=Math.max(5,Math.round(width*.022f));
        columnGap=Math.max(3,Math.round(width*.012f));
        gridPadding=Math.max(3,Math.round(width*.017f));
        tileWidth=Math.max(1,(width-2*margin-2*gridPadding-3*columnGap)/4);
        // Match the visual reference's vertical distribution. Cap the effective design height
        // on exceptionally tall displays; use the remaining area only for the decorative footer.
        int designHeight=Math.min(Math.max(1,height),Math.round(width*2.17f));
        headerHeight=Math.max(1,Math.round(designHeight*.145f));
        statsHeight=Math.max(1,Math.round(designHeight*.208f));
        footerHeight=Math.max(1,Math.round(designHeight*.093f));
        topGap=0;
        statsGap=Math.max(1,Math.round(designHeight*.015f));
        rowGap=Math.max(1,Math.round(designHeight*.015f));
        footerGap=Math.max(1,Math.round(designHeight*.027f));
        int target=Math.round(designHeight*.179f);
        int fixed=headerHeight+statsHeight+footerHeight+topGap+statsGap+rowGap+footerGap+2*gridPadding;
        tileHeight=Math.max(1,Math.min(target,(height-fixed-Math.max(1,Math.round(designHeight*.08f)))/2));
        logoSize=Math.max(1,Math.min(Math.round(width*.159f),Math.round(headerHeight*.70f)));
        labelHeight=Math.max(1,Math.round(tileHeight*.19f));
    }
    int contentHeight(){return headerHeight+topGap+statsHeight+statsGap+2*gridPadding+2*tileHeight+rowGap+footerGap+footerHeight;}
}
