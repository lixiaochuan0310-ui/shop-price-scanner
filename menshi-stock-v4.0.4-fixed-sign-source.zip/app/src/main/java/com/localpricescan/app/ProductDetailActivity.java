package com.localpricescan.app;

import android.app.Activity;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.widget.TextView;

/** 商品详情只负责展示；长按信息卡片才弹编辑/删除菜单。 */
public final class ProductDetailActivity extends SwipeBackActivity {
    private ProductDatabase db;
    private String barcode;
    private boolean scanResult;
    private boolean purchasePriceVisible;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppUi.apply(this);
        setContentView(R.layout.activity_product_detail);
        barcode = getIntent().getStringExtra("barcode");
        if (barcode == null) { finish(); return; }
        db = new ProductDatabase(this);
        findViewById(R.id.detailBack).setOnClickListener(v -> onBackPressed());
        scanResult = getIntent().getBooleanExtra("scanResult", false);
        // 扫码结果默认只显示闭眼按钮，不在屏幕上显示进价金额。
        // 从商品列表查看详情仍保持原来的进价展示方式。
        updatePurchasePriceVisibility();
        if (scanResult) {
            findViewById(R.id.detailCostToggle).setOnClickListener(v -> {
                purchasePriceVisible = !purchasePriceVisible;
                updatePurchasePriceVisibility();
                AuditTrail.record(this,purchasePriceVisible?"显示进价":"隐藏进价",barcode,"商品详情");
            });
        }
        View card = findViewById(R.id.detailCard);
        if (scanResult) {
            card.setLongClickable(false);
            findViewById(R.id.detailLongPressHint).setVisibility(View.GONE);
        } else {
            card.setOnLongClickListener(v -> {
                ProductDatabase.Product p = db.get(barcode);
                if (p != null) ProductActions.menu(this,db,p,this::load);
                return true;
            });
        }
    }
    private void updatePurchasePriceVisibility() {
        TextView cost = findViewById(R.id.detailCost);
        ImageButton eye = findViewById(R.id.detailCostToggle);
        if (!scanResult) {
            cost.setVisibility(View.VISIBLE);
            eye.setVisibility(View.GONE);
            return;
        }
        cost.setVisibility(purchasePriceVisible ? View.VISIBLE : View.GONE);
        eye.setVisibility(View.VISIBLE);
        eye.setImageResource(purchasePriceVisible ? R.drawable.ic_eye_open : R.drawable.ic_eye_closed);
        eye.setContentDescription(purchasePriceVisible ? "隐藏进价" : "显示进价");
    }
    @Override protected void onResume() { super.onResume(); if(db != null) load(); }
    private void load() {
        try {
            ProductDatabase.Product p = db.get(barcode);
            if (p == null) { finish(); return; }
            ((TextView)findViewById(R.id.detailName)).setText(p.name);
            ((TextView)findViewById(R.id.detailBarcode)).setText("条码："+p.barcode);
            ((TextView)findViewById(R.id.detailCategory)).setText("分类："+p.category+
                    "     单位："+new InventoryStore(db).settings(p.barcode).base);
            ((TextView)findViewById(R.id.detailCost)).setText(Money.show(p.purchaseCents));
            ((TextView)findViewById(R.id.detailSale)).setText(Money.show(p.saleCents));
            String stockLabel="0 件";
            for(InventoryStore.StockRow stock:new InventoryStore(db).stocks()) {
                if(stock.barcode.equals(p.barcode)) {
                    stockLabel=InventoryStore.qty(stock.current)+" "+stock.unit;
                    break;
                }
            }
            ((TextView)findViewById(R.id.detailStock)).setText(stockLabel);
            PhotoUtils.show(db.photo(p.barcode),
                    (ImageView)findViewById(R.id.detailImage),
                    (TextView)findViewById(R.id.detailNoPhoto));
        } catch (SQLiteException ignored) { /* 原记录未更改 */ }
    }
    @Override protected void onDestroy() { if(db != null) db.close(); super.onDestroy(); }
}
