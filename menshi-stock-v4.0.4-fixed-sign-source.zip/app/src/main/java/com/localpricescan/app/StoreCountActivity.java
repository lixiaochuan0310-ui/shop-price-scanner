package com.localpricescan.app;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** 按商品录入实盘数量，自动计算盘盈/盘亏，不计入销售。 */
public final class StoreCountActivity extends SwipeBackActivity {
    private ProductDatabase db;private InventoryStore store;
    private final List<ProductDatabase.Product> products=new ArrayList<>();
    private Spinner item,unit;private EditText actual,note,date;
    private TextView before,saveButton;
    private boolean confirming,submitting,saved;
    private String cleanDraft="";
    private String selectedBarcode="";
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);db=new ProductDatabase(this);store=new InventoryStore(db);
        products.addAll(db.all());
        LinearLayout root=StoreUi.content(this,"库存盘点");setContentView(root);
        LinearLayout body=StoreUi.padded(this,StoreUi.scroll(this,root));
        LinearLayout card=StoreUi.card(this);StoreUi.addCard(body,card);
        StoreUi.label(card,"选择盘点商品");
        item=new Spinner(this);
        ArrayList<String> labels=new ArrayList<>();for(ProductDatabase.Product p:products)labels.add(p.name+" · "+p.barcode);
        item.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels));card.addView(item);
        StoreUi.gap(card,12);
        StoreUi.label(card,"盘点日期");
        date=StoreUi.input(this,"日期",InventoryStore.dateToday(),1);date.setFocusable(false);
        date.setOnClickListener(v->{Calendar c=Calendar.getInstance();
            new DatePickerDialog(this,(dv,y,m,d)->date.setText(String.format(Locale.ROOT,"%04d-%02d-%02d",y,m+1,d)),
                    c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();});
        card.addView(date);StoreUi.gap(card,14);
        before=StoreUi.text(this,"",18,true);card.addView(before);StoreUi.gap(card,9);
        StoreUi.label(card,"实际清点数量（可选择箱或基础单位）");
        actual=StoreUi.decimal(this,"实际数量","");card.addView(actual);StoreUi.gap(card,8);
        unit=new Spinner(this);card.addView(unit);StoreUi.gap(card,12);
        StoreUi.label(card,"盘点备注（选填）");note=StoreUi.input(this,"例如：货架实际清点","",1);
        card.addView(note);
        saveButton=StoreUi.button(this,"确认盘点并更新库存",StoreUi.GREEN,0xffffffff);
        StoreUi.gap(body,7);body.addView(saveButton);saveButton.setOnClickListener(v->confirm());
        item.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> a,android.view.View v,int position,long id){updateItem();}
            @Override public void onNothingSelected(android.widget.AdapterView<?> a){}
        });
        String preset=getIntent().getStringExtra("barcode");
        if(preset!=null)for(int i=0;i<products.size();i++)if(preset.equals(products.get(i).barcode))item.setSelection(i);
        if(!products.isEmpty())updateItem();
        if(state!=null){
            int selected=state.getInt("draftItem",item.getSelectedItemPosition());
            if(selected>=0&&selected<products.size()){item.setSelection(selected);updateItem();}
            date.setText(state.getString("draftDate",StoreUi.value(date)));
            note.setText(state.getString("draftNote",""));
            int selectedUnit=state.getInt("draftUnit",0);
            if(selectedUnit>=0&&selectedUnit<unit.getCount())unit.setSelection(selectedUnit);
            actual.setText(state.getString("draftActual",""));
        }
        cleanDraft=state==null?signature():state.getString("cleanDraft",signature());
    }
    private String signature(){return DraftSignature.of(item,date,actual,unit,note);}
    private boolean dirty(){return !saved&&!cleanDraft.equals(signature());}
    @Override protected boolean blockSwipeExitForUnsavedChanges(){return dirty();}
    @Override public void onBackPressed(){
        if(!dirty()){super.onBackPressed();return;}
        new AlertDialog.Builder(this).setTitle("放弃未保存的盘点？")
                .setMessage("实际库存和盘点备注尚未保存。")
                .setNegativeButton("继续填写",null)
                .setPositiveButton("放弃",(d,w)->StoreCountActivity.super.onBackPressed()).show();
    }
    @Override protected void onSaveInstanceState(Bundle s){
        super.onSaveInstanceState(s);s.putString("cleanDraft",cleanDraft);
        s.putInt("draftItem",item.getSelectedItemPosition());s.putInt("draftUnit",unit.getSelectedItemPosition());
        s.putString("draftDate",StoreUi.value(date));s.putString("draftActual",actual.getText().toString());
        s.putString("draftNote",note.getText().toString());
    }
    private void updateItem(){
        int pos=item.getSelectedItemPosition();if(pos<0||pos>=products.size())return;
        String code=products.get(pos).barcode;
        InventoryStore.Settings s=store.settings(code);
        before.setText("当前系统库存："+InventoryStore.qty(store.current(code))+" "+s.base);
        List<String> opts=new ArrayList<>();opts.add(s.base);
        if(!s.pack.isEmpty()&&s.factor>1)opts.add(s.pack+"（1"+s.pack+"="+s.factor+s.base+"）");
        if(!code.equals(selectedBarcode)){
            unit.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,opts));
            actual.setText("");selectedBarcode=code;
        }
    }
    private void confirm() {
        if(confirming||submitting||saved)return;
        int pos=item.getSelectedItemPosition();if(pos<0||pos>=products.size()) {
            new AlertDialog.Builder(this).setMessage("请先录入商品").setPositiveButton("确定",null).show();return;
        }
        ProductDatabase.Product p=products.get(pos);
        Long q=InventoryStore.parseQty(StoreUi.value(actual));
        if(q==null){actual.setError("请输入有效的实际数量");return;}
        InventoryStore.Settings setting=store.settings(p.barcode);
        long base;
        try{base=Math.multiplyExact(q,unit.getSelectedItemPosition()==1?setting.factor:1);}
        catch(ArithmeticException e){actual.setError("数量过大");return;}
        long previous=store.current(p.barcode);long diff=base-previous;
        confirming=true;
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("确认盘点调整")
                .setMessage(p.name+"\n系统库存："+InventoryStore.qty(previous)+" "+setting.base+
                        "\n实际库存："+InventoryStore.qty(base)+" "+setting.base+
                        "\n差异："+(diff>0?"+":"")+InventoryStore.qty(diff)+" "+setting.base+
                        "\n\n确认后将保留一条盘点流水。")
                .setNegativeButton("返回",null)
                .setPositiveButton("确认",(d,w)->{
                    if(submitting||saved)return;
                    submitting=true;saveButton.setEnabled(false);
                    try{store.count(p.barcode,StoreUi.value(date),base,StoreUi.value(note));
                        saved=true;
                        new AlertDialog.Builder(this).setTitle("盘点成功")
                                .setMessage("库存已按实际数量调整并记录流水。")
                                .setPositiveButton("确定",(d2,w2)->finish()).show();
                    }catch(Exception e){submitting=false;saveButton.setEnabled(true);
                        AuditTrail.failure(this,"盘点失败",p.barcode,e.getMessage());
                        new AlertDialog.Builder(this).setTitle("盘点失败")
                            .setMessage(e.getMessage()).setPositiveButton("确定",null).show();}
                }).create();
        dialog.setOnDismissListener(d->confirming=false);dialog.show();
    }
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
