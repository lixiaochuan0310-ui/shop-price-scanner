package com.localpricescan.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Every destructive operation requires typing the exact phrase 确认删除. */
final class DeleteConfirm {
    interface Action { void run() throws Exception; }
    private DeleteConfirm() {}
    static void show(Activity activity,String title,String impact,String target,Action action,Runnable refreshed) {
        show(activity,title,impact,target,action,refreshed,"删除成功，库存已重新核算");
    }
    static void show(Activity activity,String title,String impact,String target,Action action,
                     Runnable refreshed,String successText) {
        LinearLayout layout=StoreUi.column(activity);
        int pad=StoreUi.d(activity,20);layout.setPadding(pad,pad,pad,pad/2);
        TextView message=StoreUi.text(activity,impact+"\n\n删除不可在页面内撤销，操作日志会保留删除前的业务资料。\n请在下方准确输入：确认删除",15,false);
        layout.addView(message);StoreUi.gap(layout,12);
        EditText answer=StoreUi.input(activity,"输入：确认删除","",android.text.InputType.TYPE_CLASS_TEXT);
        layout.addView(answer);
        AlertDialog dialog=new AlertDialog.Builder(activity).setTitle(title).setView(layout)
                .setNegativeButton("取消",(d,w)->AuditTrail.record(activity,"取消删除",target,"用户取消了删除确认"))
                .setPositiveButton("执行删除",null).create();
        dialog.setOnShowListener(unused->{
            android.widget.Button ok=dialog.getButton(AlertDialog.BUTTON_POSITIVE);
            ok.setEnabled(false);
            answer.addTextChangedListener(new TextWatcher(){
                @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
                @Override public void onTextChanged(CharSequence s,int start,int before,int count){ok.setEnabled("确认删除".contentEquals(s));}
                @Override public void afterTextChanged(Editable e){}
            });
            ok.setOnClickListener(v->{
                if(!"确认删除".equals(answer.getText().toString())){answer.setError("必须输入完整的确认删除四个字");return;}
                ok.setEnabled(false);
                try{
                    action.run();dialog.dismiss();
                    android.widget.Toast.makeText(activity,successText,android.widget.Toast.LENGTH_LONG).show();
                    if(refreshed!=null)refreshed.run();
                }catch(Exception e){
                    ok.setEnabled(true);
                    String reason=e.getMessage()==null?"未知错误":e.getMessage();
                    AuditTrail.failure(activity,"删除失败",target,reason);
                    new AlertDialog.Builder(activity).setTitle("删除未执行")
                            .setMessage(reason+"\n原有数据已保留。")
                            .setPositiveButton("知道了",null).show();
                }
            });
        });
        dialog.show();KeyboardGuard.forDialog(dialog);
    }
}
