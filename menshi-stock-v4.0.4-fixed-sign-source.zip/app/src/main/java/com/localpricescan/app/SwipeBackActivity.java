package com.localpricescan.app;

import android.app.Activity;
import android.content.Intent;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.HorizontalScrollView;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

/** 左缘右滑：当前页逐渐模糊淡出，上一页从模糊逐渐变清晰。 */
public abstract class SwipeBackActivity extends Activity {
    private float startX, startY;
    private boolean tracking, dragging;
    private SwipeBackEffect backEffect;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Bitmap behind = BackPreview.take();
        backEffect = new SwipeBackEffect(this,behind);
        getWindow().setBackgroundDrawableResource(R.drawable.bg_app_surface);
    }

    @Override protected void onResume(){
        super.onResume();
        try{AuditTrail.record(this,"打开页面",getClass().getSimpleName(),"用户进入或返回此功能页面");}
        catch(Exception ignored){}
    }

    @Override protected void onPostCreate(Bundle state) {
        super.onPostCreate(state);
        backEffect.install();
        KeyboardGuard.install(this);
    }

    // Inherit navigation preview automatically: many stock/report pages use startActivity
    // directly, rather than the explicit BackPreview.capture calls of the original scanner.
    @Override public void startActivity(Intent intent) {
        BackPreview.capture(this);
        super.startActivity(intent);
    }

    @Override public void startActivityForResult(Intent intent, int requestCode) {
        BackPreview.capture(this);
        super.startActivityForResult(intent, requestCode);
    }

    @Override public void startActivityForResult(Intent intent, int requestCode, Bundle options) {
        BackPreview.capture(this);
        super.startActivityForResult(intent, requestCode, options);
    }

    private float dp(float amount) {
        return amount * getResources().getDisplayMetrics().density;
    }

    private boolean insideEditText(View view, float x, float y) {
        if (view == null || view.getVisibility() != View.VISIBLE) return false;
        if (view instanceof EditText) {
            Rect rect = new Rect();
            return view.getGlobalVisibleRect(rect) && rect.contains((int)x,(int)y);
        }
        if (view instanceof ViewGroup) {
            ViewGroup group = (ViewGroup)view;
            for (int i=0; i<group.getChildCount(); i++) {
                if (insideEditText(group.getChildAt(i),x,y)) return true;
            }
        }
        return false;
    }

    /** 网页或横向内容优先处理自己的左右滑动，不触发返回。 */
    protected boolean shouldIgnoreSwipeBack(MotionEvent downEvent) {
        return insideHorizontalContent(findViewById(android.R.id.content),
                downEvent.getRawX(), downEvent.getRawY());
    }

    private boolean insideHorizontalContent(View view, float x, float y) {
        if (view == null || view.getVisibility() != View.VISIBLE) return false;
        if (view instanceof WebView || view instanceof HorizontalScrollView) {
            Rect r = new Rect();
            if (view.getGlobalVisibleRect(r) && r.contains((int)x,(int)y)) return true;
        }
        if (view instanceof ViewGroup) {
            ViewGroup g=(ViewGroup)view;
            for (int i=0;i<g.getChildCount();i++)
                if (insideHorizontalContent(g.getChildAt(i),x,y)) return true;
        }
        return false;
    }

    /** 编辑页有未保存更改时，先恢复页面并弹出放弃修改提示。 */
    protected boolean blockSwipeExitForUnsavedChanges() { return false; }

    @Override public boolean dispatchTouchEvent(MotionEvent event) {
        if (backEffect != null && backEffect.isFinishing()) return true;
        int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            View content = findViewById(android.R.id.content);
            startX = event.getX();
            startY = event.getY();
            dragging = false;
            tracking = content != null && startX <= dp(90) &&
                    !insideEditText(content,event.getRawX(),event.getRawY()) &&
                    !shouldIgnoreSwipeBack(event);
            return super.dispatchTouchEvent(event);
        }
        if (event.getPointerCount() > 1) {
            if (dragging) backEffect.restore(false);
            dragging = false;
            tracking = false;
            return super.dispatchTouchEvent(event);
        }
        if (action == MotionEvent.ACTION_MOVE && tracking) {
            float dx = event.getX() - startX;
            float dy = event.getY() - startY;
            if (!dragging && Math.abs(dy) > dp(18) && Math.abs(dy) > Math.abs(dx)) {
                tracking = false;
            } else {
                if (!dragging && dx > dp(14) && dx > Math.abs(dy) * 1.4f) {
                    dragging = true;
                    MotionEvent cancel = MotionEvent.obtain(event);
                    cancel.setAction(MotionEvent.ACTION_CANCEL);
                    super.dispatchTouchEvent(cancel);
                    cancel.recycle();
                }
                if (dragging) {
                    backEffect.drag(dx);
                    return true;
                }
            }
        }
        if (action == MotionEvent.ACTION_UP && dragging) {
            float distance = event.getX() - startX;
            View content = findViewById(android.R.id.content);
            boolean goBack = content != null &&
                    distance > Math.max(dp(92),content.getWidth() * .23f);
            dragging = false;
            tracking = false;
            if (!goBack) backEffect.restore(false);
            else if (blockSwipeExitForUnsavedChanges()) {
                backEffect.restore(true);
                onBackPressed();
            } else {
                backEffect.dismiss(() -> {
                    if (!isFinishing() && !isDestroyed()) onBackPressed();
                });
            }
            return true;
        }
        if (action == MotionEvent.ACTION_CANCEL && dragging) {
            backEffect.restore(false);
            dragging = false;
            tracking = false;
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) tracking = false;
        return super.dispatchTouchEvent(event);
    }

    @Override public void finish() {
        super.finish();
        overridePendingTransition(0,0);
    }
}
