package com.localpricescan.app;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 商品数量单位和期初库存；有流水后锁定基础单位及换算比以免重解释历史。 */
public final class StoreSettingsActivity extends SwipeBackActivity {
    private ProductDatabase db;private InventoryStore store;
    private String barcode;private EditText base,pack,factor,opening;
    private boolean saving,saved;private String cleanDraft="";
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);barcode=getIntent().getStringExtra("barcode");
        db=new ProductDatabase(this);store=new InventoryStore(db);
        ProductDatabase.Product p=db.get(barcode);
        if(p==null){finish();return;}
        InventoryStore.Settings s=store.settings(barcode);
        LinearLayout root=StoreUi.content(this,"库存单位与期初数量");setContentView(root);
        LinearLayout body=StoreUi.padded(this,StoreUi.scroll(this,root));
        LinearLayout card=StoreUi.card(this);StoreUi.addCard(body,card);
        TextView name=StoreUi.text(this,p.name,19,true);card.addView(name);StoreUi.gap(card,12);
        StoreUi.label(card,"基础单位：例如 台、件、米、瓶");
        base=StoreUi.input(this,"基础单位",s.base,1);card.addView(base);StoreUi.gap(card,12);
        StoreUi.label(card,"包装单位（可选）：例如 箱、卷、包");
        pack=StoreUi.input(this,"包装单位",s.pack,1);card.addView(pack);StoreUi.gap(card,12);
        StoreUi.label(card,"1 包装单位 = 多少基础单位（正整数）");
        factor=StoreUi.input(this,"例如 24",Long.toString(s.factor),2);card.addView(factor);StoreUi.gap(card,12);
        StoreUi.label(card,"期初库存：按基础单位填写，可填 1.5");
        opening=StoreUi.decimal(this,"期初库存",InventoryStore.qty(s.opening));card.addView(opening);
        StoreUi.gap(card,8);
        TextView note=StoreUi.text(this,"例：基础单位为瓶，包装单位为箱，换算24；入库2箱自动增加48瓶。",13,false);
        note.setTextColor(StoreUi.MUTED);card.addView(note);
        if(store.hasLedger(barcode)) {
            base.setEnabled(false);pack.setEnabled(false);factor.setEnabled(false);
            TextView locked=StoreUi.text(this,"已有出入库或盘点记录。为防止历史单位混乱，基础单位与换算比例已锁定；若已有盘点记录，期初库存也不能直接修改。",13,false);
            locked.setTextColor(0xffac6950);StoreUi.gap(card,9);card.addView(locked);
        }
        TextView save=StoreUi.button(this,"保存库存设置",StoreUi.GREEN,0xffffffff);
        body.addView(save);save.setOnClickListener(v->save());
        if(state!=null){
            base.setText(state.getString("draftBase",base.getText().toString()));
            pack.setText(state.getString("draftPack",pack.getText().toString()));
            factor.setText(state.getString("draftFactor",factor.getText().toString()));
            opening.setText(state.getString("draftOpening",opening.getText().toString()));
        }
        cleanDraft=state==null?signature():state.getString("cleanDraft",signature());
    }
    private String signature(){return DraftSignature.of(base,pack,factor,opening);}
    private boolean dirty(){return !saved&&!cleanDraft.equals(signature());}
    @Override protected boolean blockSwipeExitForUnsavedChanges(){return dirty();}
    @Override public void onBackPressed(){
        if(!dirty()){super.onBackPressed();return;}
        new AlertDialog.Builder(this).setTitle("放弃库存设置的修改？")
                .setMessage("修改尚未保存。")
                .setNegativeButton("继续填写",null)
                .setPositiveButton("放弃",(d,w)->StoreSettingsActivity.super.onBackPressed()).show();
    }
    @Override protected void onSaveInstanceState(Bundle b){
        super.onSaveInstanceState(b);b.putString("cleanDraft",cleanDraft);
        b.putString("draftBase",base.getText().toString());b.putString("draftPack",pack.getText().toString());
        b.putString("draftFactor",factor.getText().toString());b.putString("draftOpening",opening.getText().toString());
    }
    private void save() {
        if(saving||saved)return;
        saving=true;
        try {
            Long qty=InventoryStore.parseQty(StoreUi.value(opening));
            if(qty==null)throw new IllegalArgumentException("期初库存必须是有效的非负数，最多三位小数");
            long ratio=Long.parseLong(StoreUi.value(factor));
            if(store.hasLedger(barcode)) {
                InventoryStore.Settings old=store.settings(barcode);
                if(!old.base.equals(StoreUi.value(base)) || !old.pack.equals(StoreUi.value(pack))||ratio!=old.factor)
                    throw new IllegalArgumentException("已有流水，不能修改单位和换算比例");
            }
            store.saveSettings(barcode,StoreUi.value(base),StoreUi.value(pack),ratio,qty);
            saved=true;
            new AlertDialog.Builder(this).setTitle("保存成功").setMessage("库存设置已保存。")
                    .setPositiveButton("确定",(d,w)->finish()).show();
        }catch(Exception e){saving=false;
            AuditTrail.failure(this,"库存设置失败",barcode,e.getMessage());
            new AlertDialog.Builder(this).setTitle("无法保存")
                .setMessage(e.getMessage()==null?"请检查填写内容":e.getMessage())
                .setPositiveButton("确定",null).show();}
    }
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
