package com.localpricescan.app;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.View;
import android.view.Gravity;
import android.widget.LinearLayout;

/** Native, resolution-independent homepage materials. No screenshot or mock data is used as UI. */
final class HomeArt {
    private HomeArt(){}
    static int d(Context c,float n){return StoreUi.d(c,n);}
    static int mix(int a,int b,float f){return Color.rgb((int)(Color.red(a)*(1-f)+Color.red(b)*f),(int)(Color.green(a)*(1-f)+Color.green(b)*f),(int)(Color.blue(a)*(1-f)+Color.blue(b)*f));}
    static Drawable card(Context c,int top,int bottom,int radius,boolean gloss){return new Art(c,top,bottom,radius,gloss,0);}
    static Drawable page(Context c){return new Art(c,0xffd9f5f2,0xffc9eeea,0,false,1);}
    static Drawable header(Context c){return new Art(c,0xff126c72,0xff39a79e,0,false,2);}
    static void setPageWaveStart(View view,float start){
        Drawable bg=view.getBackground();
        if(bg instanceof Art){Art art=(Art)bg;if(art.mode==1 && Math.abs(art.waveStart-start)>.001f){art.waveStart=start;art.invalidateSelf();}}
    }
    static final class Art extends Drawable {
        final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);final Context c;final int top,bottom,radius,mode;final boolean gloss;float waveStart=.81f;
        Art(Context c,int top,int bottom,int radius,boolean gloss,int mode){this.c=c;this.top=top;this.bottom=bottom;this.radius=radius;this.gloss=gloss;this.mode=mode;}
        @Override public void draw(Canvas canvas){
            Rect b=getBounds();float w=b.width(),h=b.height();if(w<=0||h<=0)return;
            canvas.save();canvas.translate(b.left,b.top);p.setStyle(Paint.Style.FILL);p.setColor(Color.WHITE);
            if(mode!=0){
                p.setShader(new LinearGradient(0,0,mode==2?w:0,h,top,bottom,Shader.TileMode.CLAMP));canvas.drawRect(0,0,w,h,p);p.setShader(null);
                if(mode==1){
                    float remain=1-waveStart;
                    wave(canvas,w,h,waveStart,0xffccece2,false);
                    wave(canvas,w,h,waveStart+remain*.40f,0xffacdeda,true);
                    wave(canvas,w,h,waveStart+remain*.72f,0xff85cfcb,false);
                }else{
                    wave(canvas,w,h,0.76f,0x33ffffff,false);wave(canvas,w,h,0.89f,0x50e7fff6,true);
                }
            }else{
                float r=d(c,radius),edge=d(c,1),base=d(c,3);
                p.setColor(mix(bottom,0xff3d7778,0.20f));canvas.drawRoundRect(0,base,w,h,r,r,p);
                RectF rect=new RectF(0,0,w,h-base);
                p.setShader(new LinearGradient(0,0,w*0.35f,h,top,bottom,Shader.TileMode.CLAMP));canvas.drawRoundRect(rect,r,r,p);p.setShader(null);
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(edge);p.setColor(0xafffffff);
                canvas.drawRoundRect(edge,edge,w-edge,h-base-edge,r-edge,r-edge,p);p.setStyle(Paint.Style.FILL);
                if(gloss){
                    canvas.save();Path clip=new Path();clip.addRoundRect(rect,r,r,Path.Direction.CW);canvas.clipPath(clip);
                    p.setColor(Color.WHITE);p.setShader(new LinearGradient(0,0,0,h*.48f,0x46ffffff,0x00ffffff,Shader.TileMode.CLAMP));canvas.drawRect(0,0,w,h*.48f,p);p.setShader(null);
                    p.setColor(Color.WHITE);p.setShader(new RadialGradient(w*.18f,h*.12f,Math.max(1,w*.27f),0x90ffffff,0x00ffffff,Shader.TileMode.CLAMP));canvas.drawOval(w*.035f,h*.025f,w*.42f,h*.24f,p);p.setShader(null);canvas.restore();
                }
            }
            canvas.restore();
        }
        private void wave(Canvas canvas,float w,float h,float f,int color,boolean reverse){
            Path path=new Path();float y=h*f;float a=Math.min(Math.min(h*.10f,w*.09f),(h-y)*.40f);path.moveTo(0,y);
            if(reverse)path.cubicTo(w*.35f,y-a,w*.60f,y+a,w,y-a*.5f);else path.cubicTo(w*.38f,y+a,w*.68f,y-a,w,y-a*.4f);
            path.lineTo(w,h);path.lineTo(0,h);path.close();p.setColor(color);canvas.drawPath(path,p);
        }
        @Override public void setAlpha(int a){p.setAlpha(a);invalidateSelf();}
        @Override public void setColorFilter(ColorFilter f){p.setColorFilter(f);invalidateSelf();}
        @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
        @Override public void getOutline(Outline outline){Rect b=getBounds();if(mode==0)outline.setRoundRect(b,d(c,radius));else outline.setRect(b);}
    }
    /** Individual concept artwork, with all labels removed. Only the empty middle band
     * stretches on taller displays; the illustration and beveled edge keep their proportions. */
    static Drawable skin(Context c,int res,float split,int radius){return new Skin(c,res,split,radius);}
    private static final class Skin extends Drawable {
        final Bitmap bitmap;final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        final float split;final int radius;
        Skin(Context c,int res,float split,int radius){bitmap=BitmapFactory.decodeResource(c.getResources(),res);this.split=split;this.radius=d(c,radius);}
        @Override public void draw(Canvas canvas){
            Rect b=getBounds();if(b.isEmpty()||bitmap==null)return;
            int bw=bitmap.getWidth(),bh=bitmap.getHeight();float w=b.width(),h=b.height();
            if(split<=0){canvas.drawBitmap(bitmap,null,b,paint);return;}
            int a=Math.round(bh*split),z=Math.round(bh*.93f);
            float top=Math.min(h*split,(w/bw)*a*1.13f),tail=Math.min(h*.07f,(w/bw)*(bh-z)*1.13f);
            // A shared pixel at each band boundary prevents hairline gaps from filtering.
            canvas.drawBitmap(bitmap,new Rect(0,0,bw,a),new RectF(b.left,b.top,b.right,b.top+top),paint);
            canvas.drawBitmap(bitmap,new Rect(0,a,bw,z),new RectF(b.left,b.top+top,b.right,b.bottom-tail),paint);
            canvas.drawBitmap(bitmap,new Rect(0,z,bw,bh),new RectF(b.left,b.bottom-tail,b.right,b.bottom),paint);
        }
        @Override public void setAlpha(int alpha){paint.setAlpha(alpha);invalidateSelf();}
        @Override public void setColorFilter(ColorFilter filter){paint.setColorFilter(filter);invalidateSelf();}
        @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
        @Override public void getOutline(Outline outline){outline.setRoundRect(getBounds(),radius);}
    }
    static void raised(View v,int top,int bottom,int radius){
        Context c=v.getContext();v.setBackground(card(c,top,bottom,radius,true));v.setElevation(d(c,4));
    }
    /** Android pressed state drives a real scale/elevation response; click semantics remain native. */
    static final class PressCard extends LinearLayout {
        private boolean ready;
        PressCard(Context c,int top,int bottom,int radius){
            super(c);setOrientation(VERTICAL);setGravity(Gravity.CENTER);setClickable(true);setFocusable(true);
            raised(this,top,bottom,radius);setSoundEffectsEnabled(true);
            GradientDrawable mask=new GradientDrawable();mask.setColor(Color.WHITE);mask.setCornerRadius(d(c,radius));
            setForeground(new RippleDrawable(ColorStateList.valueOf(0x34256b70),null,mask));ready=true;
        }
        @Override protected void drawableStateChanged(){super.drawableStateChanged();if(!ready)return;
            boolean down=isPressed()&&isEnabled();animate().cancel();animate().scaleX(down?.94f:1f).scaleY(down?.94f:1f).translationZ(down?-d(getContext(),3):0).setDuration(down?75:140).start();
        }
        @Override protected void onDetachedFromWindow(){animate().cancel();setScaleX(1);setScaleY(1);setTranslationZ(0);super.onDetachedFromWindow();}
    }
    /** Layered icon strokes/fills provide small raised highlights without bitmap stretching. */
    static final class Icon extends View {
        final Drawable shape;final int color;
        Icon(Context c,int res,int color){super(c);shape=c.getDrawable(res).mutate();this.color=color;setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);int w=getWidth(),h=getHeight();int pad=d(getContext(),2);int off=d(getContext(),1);
            shape.setBounds(pad,pad,w-pad,h-pad);canvas.save();canvas.translate(0,off*1.7f);shape.setTint(mix(color,0xff124052,.32f));shape.draw(canvas);canvas.restore();
            canvas.save();canvas.translate(0,-off*.65f);shape.setTint(mix(color,Color.WHITE,.44f));shape.draw(canvas);canvas.restore();
            shape.setTint(color);shape.draw(canvas);
        }
    }
}
