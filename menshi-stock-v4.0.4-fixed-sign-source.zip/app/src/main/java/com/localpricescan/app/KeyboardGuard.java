package com.localpricescan.app;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;

/** Make focused fields visible after the IME changes the available viewport.
 * The existing ScrollView handles normal business forms; this only requests scrolling
 * when the focused field would otherwise end up under the on-screen keyboard.
 */
final class KeyboardGuard {
    private KeyboardGuard() {}
    static void install(Activity activity) {
        activity.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE |
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        final View decor = activity.getWindow().getDecorView();
        decor.getViewTreeObserver().addOnGlobalFocusChangeListener((old, now) -> {
            if (now instanceof EditText) {
                ensureVisible(now);
                now.postDelayed(() -> ensureVisible(now), 230);
            }
        });
        final int[] lastBottom = {-1};
        decor.getViewTreeObserver().addOnGlobalLayoutListener(() -> {
            Rect visible = new Rect();
            decor.getWindowVisibleDisplayFrame(visible);
            int usableBottom=Math.min(visible.bottom,decor.getHeight());
            if (Math.abs(usableBottom-lastBottom[0]) < StoreUi.d(activity,12)) return;
            lastBottom[0] = usableBottom;
            View focused=activity.getCurrentFocus();
            if (focused instanceof EditText) ensureVisible(focused);
        });
    }
    static void ensureVisible(View view) {
        if (view == null || !view.isAttachedToWindow()) return;
        view.post(() -> {
            if (!view.isAttachedToWindow() || !view.isFocused()) return;
            int margin = StoreUi.d(view.getContext(),20);
            view.requestRectangleOnScreen(new Rect(0,-margin,view.getWidth(),
                    view.getHeight()+margin),true);
        });
    }
    static void forDialog(Dialog dialog) {
        if (dialog == null || dialog.getWindow() == null) return;
        Window w=dialog.getWindow();
        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE |
                WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        View content = w.getDecorView();
        content.getViewTreeObserver().addOnGlobalFocusChangeListener((old,now)-> {
            if (now instanceof EditText) {
                ensureVisible(now);
                now.postDelayed(()->ensureVisible(now),250);
            }
        });
    }
}
