package com.localpricescan.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** 商品列表：点击可编辑或删除；删除需二次确认。 */
public final class ProductListActivity extends Activity {
    private ProductDatabase database;
    private final List<ProductDatabase.Product> products = new ArrayList<>();
    private BaseAdapter adapter;
    private TextView countView;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_product_list);
        database = new ProductDatabase(this);
        findViewById(R.id.listBackButton).setOnClickListener(v -> finish());
        countView = findViewById(R.id.productCountText);
        ListView list = findViewById(R.id.productList);
        list.setEmptyView(findViewById(R.id.emptyProducts));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return products.size(); }
            @Override public Object getItem(int position) { return products.get(position); }
            @Override public long getItemId(int position) { return position; }
            @Override public View getView(int position, View reused, ViewGroup parent) {
                View row = reused == null ? LayoutInflater.from(ProductListActivity.this)
                        .inflate(R.layout.row_product, parent, false) : reused;
                ProductDatabase.Product product = products.get(position);
                ((TextView) row.findViewById(R.id.rowName)).setText(product.name);
                ((TextView) row.findViewById(R.id.rowBarcode)).setText("条形码  " + product.barcode);
                ((TextView) row.findViewById(R.id.rowPrices)).setText(
                        "进价 " + Money.show(product.purchaseCents) + "     售价 " + Money.show(product.saleCents));
                return row;
            }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            ProductDatabase.Product product = products.get(position);
            new AlertDialog.Builder(this)
                    .setTitle(product.name)
                    .setItems(new String[]{"编辑商品", "删除商品"}, (dialog, selected) -> {
                        if (selected == 0) {
                            EditProductDialog.open(this, database, product, this::refresh);
                        } else if (selected == 1) {
                            confirmDelete(product);
                        }
                    })
                    .setNegativeButton("取消", null)
                    .show();
        });
        refresh();
    }

    private void confirmDelete(ProductDatabase.Product product) {
        new AlertDialog.Builder(this)
                .setTitle("确认删除商品")
                .setMessage("商品：" + product.name + "\n条形码：" + product.barcode +
                        "\n\n删除后，该条码下次扫描需要重新录入。确定删除吗？")
                .setNegativeButton("取消", null)
                .setPositiveButton("确认删除", (dialog, which) -> {
                    try {
                        if (database.delete(product.barcode)) {
                            refresh();
                            Toast.makeText(this, "已删除商品", Toast.LENGTH_SHORT).show();
                        } else {
                            refresh();
                            Toast.makeText(this, "商品已不存在，未删除其他数据", Toast.LENGTH_LONG).show();
                        }
                    } catch (SQLiteException error) {
                        Toast.makeText(this, "删除失败，商品数据未修改", Toast.LENGTH_LONG).show();
                    }
                })
                .show();
    }

    private void refresh() {
        try {
            products.clear();
            products.addAll(database.all());
            countView.setText("共 " + products.size() + " 件已录入商品 · 点击可编辑或删除");
            adapter.notifyDataSetChanged();
        } catch (SQLiteException error) {
            Toast.makeText(this, "商品列表读取失败", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onDestroy() {
        if (database != null) database.close();
        super.onDestroy();
    }
}
