package com.localpricescan.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;

/** 使用 Android 系统文件选择器导出/导入 JSON，无网络、无存储权限需求。 */
public final class BackupActivity extends Activity {
    private static final int SAVE_REQUEST = 201;
    private static final int OPEN_REQUEST = 202;
    private static final int MAX_BACKUP_BYTES = 50 * 1024 * 1024;
    private static final int MAX_PRODUCTS = 200_000;
    private ProductDatabase database;
    private TextView countView;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_backup);
        database = new ProductDatabase(this);
        countView = findViewById(R.id.backupCount);
        findViewById(R.id.backupBackButton).setOnClickListener(v -> finish());
        findViewById(R.id.exportButton).setOnClickListener(v -> exportWithPicker());
        findViewById(R.id.importButton).setOnClickListener(v -> importWithPicker());
        refreshCount();
    }

    private void refreshCount() {
        try {
            countView.setText("当前手机共有 " + database.count() + " 件商品");
        } catch (SQLiteException error) {
            countView.setText("商品数量读取失败");
        }
    }

    private void exportWithPicker() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "商品查价备份_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.CHINA).format(new Date()) + ".json");
        startActivityForResult(intent, SAVE_REQUEST);
    }

    private void importWithPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, OPEN_REQUEST);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == SAVE_REQUEST) exportTo(uri);
        else if (requestCode == OPEN_REQUEST) importFrom(uri);
    }

    private void exportTo(Uri uri) {
        try {
            List<ProductDatabase.Product> products = database.all();
            JSONObject root = new JSONObject();
            root.put("format", "local_price_scanner_backup");
            root.put("version", 1);
            JSONArray items = new JSONArray();
            for (ProductDatabase.Product p : products) {
                JSONObject item = new JSONObject();
                item.put("barcode", p.barcode);
                item.put("name", p.name);
                item.put("purchase_cents", p.purchaseCents);
                item.put("sale_cents", p.saleCents);
                items.put(item);
            }
            root.put("products", items);
            byte[] bytes = root.toString(2).getBytes(StandardCharsets.UTF_8);
            if (bytes.length > MAX_BACKUP_BYTES) {
                Toast.makeText(this, "备份超过文件大小限制，导出失败", Toast.LENGTH_LONG).show();
                return;
            }
            try (OutputStream output = getContentResolver().openOutputStream(uri, "wt")) {
                if (output == null) throw new IllegalStateException("无法写入文件");
                output.write(bytes);
                output.flush();
            }
            new AlertDialog.Builder(this).setTitle("备份完成")
                    .setMessage("已导出 " + products.size() + " 件商品。换手机时将这个 JSON 文件传到新手机，再在新手机中选择「恢复数据」。")
                    .setPositiveButton("知道了", null).show();
        } catch (Exception error) {
            Toast.makeText(this, "备份失败：请重新选择保存位置", Toast.LENGTH_LONG).show();
        }
    }

    private void importFrom(Uri uri) {
        try {
            byte[] bytes;
            try (InputStream input = getContentResolver().openInputStream(uri)) {
                if (input == null) throw new IllegalStateException("无法打开备份文件");
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                byte[] buffer = new byte[16_384];
                int read;
                while ((read = input.read(buffer)) != -1) {
                    if (output.size() + read > MAX_BACKUP_BYTES) {
                        throw new IllegalArgumentException("备份文件过大");
                    }
                    output.write(buffer, 0, read);
                }
                bytes = output.toByteArray();
            }
            JSONObject root = new JSONObject(new String(bytes, StandardCharsets.UTF_8));
            if (!"local_price_scanner_backup".equals(root.optString("format")) ||
                    root.optInt("version", -1) != 1) {
                throw new IllegalArgumentException("不是本软件支持的备份文件");
            }
            JSONArray array = root.getJSONArray("products");
            if (array.length() > MAX_PRODUCTS) throw new IllegalArgumentException("商品数量超过限制");
            HashSet<String> seen = new HashSet<>();
            List<ProductDatabase.Product> imported = new ArrayList<>(array.length());
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                String barcode = item.getString("barcode");
                String name = item.getString("name").trim();
                long purchase = item.getLong("purchase_cents");
                long sale = item.getLong("sale_cents");
                if (barcode.isEmpty() || barcode.length() > 200 || name.isEmpty() ||
                        name.length() > 500 || purchase < 0 || sale < 0 ||
                        purchase > 99999999900L || sale > 99999999900L ||
                        !seen.add(barcode)) {
                    throw new IllegalArgumentException("备份数据有误或包含重复条码");
                }
                imported.add(new ProductDatabase.Product(barcode, name, purchase, sale));
            }
            int current = database.count();
            new AlertDialog.Builder(this)
                    .setTitle("确认恢复商品数据")
                    .setMessage("备份中有 " + imported.size() + " 件商品。\n\n恢复后将【替换】这台手机当前的 " +
                            current + " 件商品，原有商品及价格会被覆盖。\n\n确定要继续吗？")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("确认恢复", (dialog, which) -> restore(imported))
                    .show();
        } catch (Exception error) {
            Toast.makeText(this, "无法恢复：备份文件无效或损坏，原数据未修改", Toast.LENGTH_LONG).show();
        }
    }

    private void restore(List<ProductDatabase.Product> imported) {
        try {
            database.replaceAll(imported);
            refreshCount();
            new AlertDialog.Builder(this).setTitle("恢复完成")
                    .setMessage("已恢复 " + imported.size() + " 件商品，可以返回首页扫码查询。")
                    .setPositiveButton("确定", null).show();
        } catch (Exception error) {
            Toast.makeText(this, "恢复失败，原商品数据已保留", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onDestroy() {
        if (database != null) database.close();
        super.onDestroy();
    }
}
