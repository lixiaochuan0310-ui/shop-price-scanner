package com.localpricescan.app;

/**
 * Treat the two standard representations of one UPC-A symbol as equivalent:
 * a 12-digit UPC-A and a 13-digit EAN-13 with a leading 0.
 * Other barcode formats remain exact keys; different products must never be merged.
 */
final class BarcodeKey {
    private BarcodeKey() {}

    static String scanned(String raw) {
        return raw == null ? "" : raw.trim();
    }

    static String equivalentUpcEan(String code) {
        if (code == null) return null;
        if (code.length() == 12 && validCheckDigit(code)) return "0" + code;
        if (code.length() == 13 && code.charAt(0) == '0' && validCheckDigit(code)) {
            return code.substring(1);
        }
        return null;
    }

    /** Verify the GS1 modulo-10 check digit before permitting format equivalence. */
    private static boolean validCheckDigit(String code) {
        int length = code.length();
        if (length != 12 && length != 13) return false;
        int sum = 0;
        int weight = 3;
        for (int i = length - 2; i >= 0; i--) {
            char c = code.charAt(i);
            if (c < '0' || c > '9') return false;
            sum += (c - '0') * weight;
            weight = weight == 3 ? 1 : 3;
        }
        char check = code.charAt(length - 1);
        return check >= '0' && check <= '9' && (10 - (sum % 10)) % 10 == check - '0';
    }
}
