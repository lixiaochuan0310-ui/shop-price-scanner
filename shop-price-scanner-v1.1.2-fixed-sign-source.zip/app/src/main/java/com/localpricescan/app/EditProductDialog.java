package com.localpricescan.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** 从扫码结果或商品列表进入的同一个修改窗口。 */
final class EditProductDialog {
    private EditProductDialog() {}

    private static int dp(Activity activity, int value) {
        return Math.round(value * activity.getResources().getDisplayMetrics().density);
    }

    private static EditText field(Activity activity, String label, String text, boolean decimal,
                                  LinearLayout parent) {
        TextView title = new TextView(activity);
        title.setText(label);
        title.setTextColor(Color.rgb(65, 87, 117));
        title.setTextSize(14);
        LinearLayout.LayoutParams titleParams = new LinearLayout.LayoutParams(-1, -2);
        titleParams.topMargin = dp(activity, 14);
        parent.addView(title, titleParams);

        EditText edit = new EditText(activity);
        edit.setSingleLine(true);
        edit.setTextSize(16);
        edit.setText(text);
        edit.setSelectAllOnFocus(true);
        edit.setInputType(decimal ? 8194 : 4097);
        parent.addView(edit, new LinearLayout.LayoutParams(-1, dp(activity, 52)));
        return edit;
    }

    static void open(Activity activity, ProductDatabase database,
                     ProductDatabase.Product product, Runnable onSaved) {
        LinearLayout form = new LinearLayout(activity);
        form.setOrientation(LinearLayout.VERTICAL);
        form.setPadding(dp(activity, 22), dp(activity, 6), dp(activity, 22), dp(activity, 10));
        TextView barcode = new TextView(activity);
        barcode.setText("条形码：" + product.barcode);
        barcode.setTextColor(Color.rgb(107, 124, 150));
        barcode.setTextSize(12);
        form.addView(barcode, new LinearLayout.LayoutParams(-1, -2));
        EditText name = field(activity, "商品名称", product.name, false, form);
        EditText purchase = field(activity, "进价（元）", Money.input(product.purchaseCents), true, form);
        EditText sale = field(activity, "售价（元）", Money.input(product.saleCents), true, form);

        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("修改商品")
                .setView(form)
                .setNegativeButton("取消", null)
                .setPositiveButton("保存修改", null)
                .create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                .setOnClickListener(button -> {
                    String nameText = name.getText().toString().trim();
                    Long purchaseValue = Money.parseCents(purchase.getText().toString());
                    Long saleValue = Money.parseCents(sale.getText().toString());
                    if (nameText.isEmpty()) {
                        name.setError("请输入商品名称");
                        name.requestFocus();
                        return;
                    }
                    if (purchaseValue == null) {
                        purchase.setError("请输入有效进价，最多两位小数");
                        purchase.requestFocus();
                        return;
                    }
                    if (saleValue == null) {
                        sale.setError("请输入有效售价，最多两位小数");
                        sale.requestFocus();
                        return;
                    }
                    try {
                        ProductDatabase.Product updated = new ProductDatabase.Product(
                                product.barcode, nameText, purchaseValue, saleValue);
                        if (!database.update(updated)) {
                            Toast.makeText(activity, "没有找到原商品，修改未保存", Toast.LENGTH_LONG).show();
                            return;
                        }
                        dialog.dismiss();
                        onSaved.run();
                        Toast.makeText(activity, "修改已保存", Toast.LENGTH_SHORT).show();
                    } catch (SQLiteException e) {
                        Toast.makeText(activity, "修改失败，原价格未变", Toast.LENGTH_LONG).show();
                    }
                }));
        dialog.show();
    }
}
