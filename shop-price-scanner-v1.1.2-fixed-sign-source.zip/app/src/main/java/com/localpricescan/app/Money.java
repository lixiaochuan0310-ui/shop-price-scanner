package com.localpricescan.app;

import java.math.BigDecimal;

final class Money {
    private Money() {}

    static Long parseCents(String raw) {
        if (raw == null) return null;
        String text = raw.trim().replace('，', '.').replace(',', '.');
        if (!text.matches("(?:0|[1-9][0-9]{0,8})(?:\\.[0-9]{1,2})?")) return null;
        try {
            return new BigDecimal(text).movePointRight(2).longValueExact();
        } catch (ArithmeticException error) {
            return null;
        }
    }

    static String show(long cents) {
        return "¥" + BigDecimal.valueOf(cents, 2).toPlainString();
    }

    static String input(long cents) {
        return BigDecimal.valueOf(cents, 2).toPlainString();
    }
}
