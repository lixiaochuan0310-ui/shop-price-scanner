package com.localpricescan.app;

import com.journeyapps.barcodescanner.CaptureActivity;

/** 保持扫描画面纵向。 */
public final class PortraitCaptureActivity extends CaptureActivity { }
