package com.localpricescan.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.MotionEvent;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** 免费图片搜索：必应移动图片网页 + 夸克公开图片结果（无付费接口）。 */
public final class OnlinePhotoSearchActivity extends SwipeBackActivity {
    private static final int GALLERY_REQUEST = 601;
    private static final int MAX_REMOTE_BYTES = 8_000_000;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private EditText queryInput;
    private TextView status;
    private WebView web;
    private Button bingButton, quarkButton;
    private final Map<String,String> quarkOriginals = new HashMap<>();
    private int searchRequestId = 0;
    private String searchWords = "";
    private String currentSearchUrl = "";
    private int engine = 0; // 0 必应，1 夸克
    private boolean selecting = false;
    private boolean pageFailed = false;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppUi.apply(this);
        setContentView(R.layout.activity_online_photo_search);
        String name = getIntent().getStringExtra("name");
        queryInput = findViewById(R.id.onlineSearchName);
        status = findViewById(R.id.onlineStatus);
        web = findViewById(R.id.onlineWeb);
        bingButton = findViewById(R.id.onlineBing);
        quarkButton = findViewById(R.id.onlineQuark);
        findViewById(R.id.onlineBack).setOnClickListener(v -> onBackPressed());
        findViewById(R.id.onlineNameButton).setOnClickListener(v -> nameSearch());
        findViewById(R.id.onlineBrowser).setOnClickListener(v -> openBrowser());
        findViewById(R.id.onlineAlbum).setOnClickListener(v -> selectFromAlbum());
        bingButton.setOnClickListener(v -> switchEngine(0));
        quarkButton.setOnClickListener(v -> switchEngine(1));
        queryInput.setSingleLine(true);
        queryInput.setOnEditorActionListener((v, actionId, event) -> { nameSearch(); return true; });
        queryInput.setText(name == null || name.trim().isEmpty() ? "" : name.trim());

        WebSettings webSettings = web.getSettings();
        webSettings.setJavaScriptEnabled(true); // 公开图片搜索网页依赖 JavaScript。
        // 以手机浏览器访问，而不是请求 PC 图片搜索页面；网页实际布局仍由网站决定。
        String mobileAgent = webSettings.getUserAgentString()
                .replace("; wv", "").replace("Version/4.0 ", "");
        webSettings.setUserAgentString(mobileAgent);
        webSettings.setDomStorageEnabled(true);
        webSettings.setLoadsImagesAutomatically(true);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(false);
        webSettings.setSupportMultipleWindows(false);
        webSettings.setAllowFileAccess(false);
        webSettings.setAllowContentAccess(false);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        // 适配移动屏幕：宽网页先整体缩放到可见区域，放大后可横向平移。
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setSupportZoom(true);
        webSettings.setBuiltInZoomControls(true);
        webSettings.setDisplayZoomControls(false);
        web.setInitialScale(0);
        web.setHorizontalScrollBarEnabled(true);
        web.setVerticalScrollBarEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                pageFailed = false;
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    pageFailed = true;
                    showStatus("图片搜索网页暂时无法打开。可以换一个搜索网站，或点击「在浏览器打开」。");
                }
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (engine == 0 && !selecting && !pageFailed && url != null && !url.isEmpty() && !url.equals("about:blank")) {
                    status.setVisibility(View.GONE);
                }
            }
        });
        web.setOnLongClickListener(v -> {
            WebView.HitTestResult hit = web.getHitTestResult();
            if (hit == null) return false;
            int type = hit.getType();
            if (type != WebView.HitTestResult.IMAGE_TYPE &&
                    type != WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) return false;
            String imageUrl = hit.getExtra();
            if (engine == 1 && imageUrl != null && quarkOriginals.containsKey(imageUrl)) {
                imageUrl = quarkOriginals.get(imageUrl);
            }
            if (imageUrl == null || !imageUrl.startsWith("https://")) {
                showStatus("此图片无法直接下载，可在浏览器打开后保存，再从相册选择。");
                return true;
            }
            final String selectedImageUrl = imageUrl;
            new AlertDialog.Builder(this)
                    .setTitle("使用选中的商品图片？")
                    .setMessage("请先核对品牌、包装和规格。照片会复制到商品本地资料，保存商品后才能生效。")
                    .setNegativeButton("取消", null)
                    .setPositiveButton("使用这张照片", (dialog, which) -> downloadSelected(selectedImageUrl))
                    .show();
            return true;
        });
        updateEngine();
        if (name != null && !name.trim().isEmpty()) {
            runSearch(name.trim());
        }
    }

    /** 网页范围内的横向手势交给网页，不能触发左缘返回动画。 */
    @Override protected boolean shouldIgnoreSwipeBack(MotionEvent downEvent) {
        if (web == null || web.getVisibility() != View.VISIBLE) return false;
        Rect bounds = new Rect();
        return web.getGlobalVisibleRect(bounds) &&
                bounds.contains((int) downEvent.getRawX(), (int) downEvent.getRawY());
    }

    private void showStatus(String message) {
        status.setText(message);
        status.setVisibility(View.VISIBLE);
    }

    private void switchEngine(int selected) {
        engine = selected;
        updateEngine();
        String input = queryInput.getText().toString().trim();
        if (!input.isEmpty()) runSearch(input);
        else if (!searchWords.isEmpty()) runSearch(searchWords);
    }

    private void updateEngine() {
        bingButton.setAlpha(engine == 0 ? 1f : .58f);
        quarkButton.setAlpha(engine == 1 ? 1f : .58f);
    }

    private void nameSearch() {
        String value = queryInput.getText().toString().trim();
        if (value.isEmpty()) {
            queryInput.setError("请输入商品名称，例如：百事可乐 500ml");
            queryInput.requestFocus();
            return;
        }
        runSearch(value);
    }

    private void runSearch(String value) {
        if (value == null || value.trim().isEmpty()) return;
        searchWords = value.trim();
        final int requestId = ++searchRequestId;
        try {
            String query = URLEncoder.encode(searchWords + " 商品包装图", "UTF-8");
            quarkOriginals.clear();
            if (engine == 0) {
                // Bing Images uses the responsive mobile layout when requested with the phone UA.
                currentSearchUrl = "https://www.bing.com/images/search?q=" + query
                        + "&setlang=zh-Hans";
                showStatus("正在打开必应手机版图片搜索…");
                web.loadUrl(currentSearchUrl);
            } else {
                // Quark's image results are served separately from its general search page.
                // This public endpoint is not a guaranteed long-term API; handle failures explicitly.
                currentSearchUrl = "https://quark.sm.cn/s?q=" + query;
                showStatus("正在查找夸克图片…");
                web.loadDataWithBaseURL("https://quark.sm.cn/",
                        "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                        + "<body style='font-family:sans-serif;text-align:center;color:#57715e'>"
                        + "正在查找商品图片…</body></html>",
                        "text/html", "UTF-8", null);
                loadQuarkImages(query, requestId);
            }
            ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE))
                    .hideSoftInputFromWindow(queryInput.getWindowToken(), 0);
            queryInput.clearFocus();
        } catch (Exception e) {
            showStatus("无法生成搜索链接，请重新输入商品名称。");
        }
    }

    /** Render a native-width mobile image gallery from Quark image-search results. */
    private void loadQuarkImages(String query, int requestId) {
        // Capture WebView settings on its UI thread; never call WebView from worker threads.
        final String userAgent = web.getSettings().getUserAgentString();
        worker.execute(() -> {
            try {
                URL url = new URL("https://vt.sm.cn/api/pic/list?query=" + query + "&limit=24&start=0");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                String body;
                try {
                    conn.setConnectTimeout(9000);
                    conn.setReadTimeout(12000);
                    conn.setRequestProperty("User-Agent", userAgent);
                    conn.setRequestProperty("Referer", "https://quark.sm.cn/");
                    conn.setRequestProperty("Accept", "application/json,text/plain,*/*");
                    if (conn.getResponseCode() != 200) throw new IllegalStateException("图片搜索接口暂不可用");
                    try (InputStream input = conn.getInputStream();
                            ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                        byte[] buffer = new byte[8192];
                        int count;
                        while ((count = input.read(buffer)) != -1) {
                            if (output.size() + count > 2_000_000)
                                throw new IllegalStateException("搜索响应过大");
                            output.write(buffer, 0, count);
                        }
                        body = output.toString("UTF-8");
                    }
                } finally { conn.disconnect(); }
                JSONObject response = new JSONObject(body);
                JSONObject data = response.optJSONObject("data");
                JSONObject hit = data == null ? null : data.optJSONObject("hit");
                JSONObject info = hit == null ? null : hit.optJSONObject("imgInfo");
                JSONArray items = info == null ? null : info.optJSONArray("item");
                if (items == null || items.length() == 0) throw new IllegalStateException("无图片结果");
                StringBuilder html = new StringBuilder(6000);
                html.append("<!doctype html><html lang='zh-CN'><head><meta name='viewport' "
                        + "content='width=device-width,initial-scale=1,maximum-scale=5'>"
                        + "<style>*{box-sizing:border-box}body{margin:0;background:#fff;font-family:sans-serif}"
                        + ".grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;padding:8px}"
                        + ".tile{border:1px solid #e5eee5;border-radius:10px;overflow:hidden;background:white}"
                        + "img{width:100%;height:155px;object-fit:contain;display:block;background:#f7faf7}"
                        + ".title{font-size:12px;color:#3d5544;line-height:1.4;padding:6px;"
                        + "white-space:nowrap;overflow:hidden;text-overflow:ellipsis}"
                        + "</style></head><body><div class='grid'>");
                Map<String,String> originals = new HashMap<>();
                Set<String> used = new HashSet<>();
                int valid = 0;
                for (int i=0; i < items.length(); i++) {
                    JSONObject item = items.optJSONObject(i);
                    if (item == null) continue;
                    String original = secureImageUrl(item.optString("bigPicUrl", ""));
                    if (original.isEmpty()) original = secureImageUrl(item.optString("imgUrl", ""));
                    String thumbnail = secureImageUrl(item.optString("img", ""));
                    if (thumbnail.isEmpty()) thumbnail = original;
                    if (original.isEmpty() || thumbnail.isEmpty() || !used.add(original)) continue;
                    originals.put(thumbnail, original);
                    String title = escapeHtml(item.optString("title", "商品图片"));
                    html.append("<div class='tile'><img src='").append(escapeHtml(thumbnail))
                            .append("' alt='").append(title).append("' loading='lazy' />")
                            .append("<div class='title'>").append(title).append("</div></div>");
                    valid++;
                }
                if (valid == 0) throw new IllegalStateException("无可显示的图片");
                html.append("</div></body></html>");
                main.post(() -> {
                    if (isFinishing() || engine != 1 || requestId != searchRequestId) return;
                    quarkOriginals.clear();
                    quarkOriginals.putAll(originals);
                    web.loadDataWithBaseURL("https://quark.sm.cn/", html.toString(),
                            "text/html", "UTF-8", null);
                    showStatus("夸克图片结果：长按喜欢的商品照片，选择「使用这张照片」。");
                });
            } catch (Exception e) {
                main.post(() -> {
                    if (isFinishing() || engine != 1 || requestId != searchRequestId) return;
                    showStatus("夸克图片结果暂时无法获取。可点「在浏览器打开」查看夸克网页搜索，"
                            + "或切换必应图片；请不要将网页搜索当成已找到照片。");
                    web.loadUrl(currentSearchUrl);
                });
            }
        });
    }

    private static String secureImageUrl(String url) {
        if (url == null) return "";
        String trimmed = url.trim();
        if (trimmed.startsWith("https://")) return trimmed;
        if (trimmed.startsWith("//")) return "https:" + trimmed;
        if (trimmed.startsWith("http://")) return "https://" + trimmed.substring(7);
        return "";
    }

    private static String escapeHtml(String value) {
        return value.replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\"", "&quot;")
                .replace("'", "&#39;");
    }

    private void openBrowser() {
        if (currentSearchUrl.isEmpty()) {
            nameSearch();
            if (currentSearchUrl.isEmpty()) return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(currentSearchUrl)));
            showStatus("在浏览器中找到合适的包装图并保存到手机后，返回本页点「从相册选择」。");
        } catch (Exception e) {
            showStatus("未找到可打开网页的浏览器，请检查手机是否安装浏览器。");
        }
    }

    private void selectFromAlbum() {
        try { startActivityForResult(PhotoUtils.galleryIntent(), GALLERY_REQUEST); }
        catch (Exception e) { Toast.makeText(this, "无法打开相册", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == GALLERY_REQUEST && result == RESULT_OK && data != null && data.getData() != null) {
            returnPhoto(data.getData());
        }
    }

    /** 图片从网页下载后通过原有商品编辑页的照片导入逻辑压缩并保存。 */
    private void downloadSelected(String address) {
        if (selecting) return;
        selecting = true;
        showStatus("正在获取选中的照片…");
        String referer = web.getUrl();
        String agent = web.getSettings().getUserAgentString();
        worker.execute(() -> {
            try {
                byte[] bytes = downloadImage(address, referer, agent);
                File file = File.createTempFile("domestic_image_", ".img", getCacheDir());
                try (FileOutputStream output = new FileOutputStream(file)) { output.write(bytes); }
                byte[] jpeg;
                try { jpeg = PhotoUtils.readJpeg(this, Uri.fromFile(file)); }
                finally { file.delete(); }
                File converted = File.createTempFile("domestic_photo_", ".jpg", getCacheDir());
                try (FileOutputStream output = new FileOutputStream(converted)) { output.write(jpeg); }
                Uri result = FileProvider.getUriForFile(this,
                        getPackageName() + ".fileprovider", converted);
                main.post(() -> { if (!isFinishing()) returnPhoto(result); });
            } catch (Exception e) {
                main.post(() -> {
                    if (isFinishing()) return;
                    selecting = false;
                    showStatus("该网站限制了图片下载，或图片格式无法读取。可点「在浏览器打开」，保存后再从相册选择。也可长按其他图片重试。");
                });
            }
        });
    }

    private static byte[] downloadImage(String address, String referer, String agent) throws Exception {
        URL url = new URL(address);
        for (int redirect = 0; redirect < 4; redirect++) {
            if (!"https".equalsIgnoreCase(url.getProtocol()) || url.getHost().isEmpty())
                throw new IllegalArgumentException("仅允许 HTTPS 图片");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(9000);
            conn.setReadTimeout(12000);
            conn.setInstanceFollowRedirects(false);
            conn.setRequestProperty("User-Agent", agent);
            conn.setRequestProperty("Accept", "image/avif,image/webp,image/png,image/jpeg,image/*;q=0.8");
            if (referer != null && referer.startsWith("https://")) conn.setRequestProperty("Referer", referer);
            String cookies = CookieManager.getInstance().getCookie(url.toString());
            if (cookies != null && !cookies.isEmpty()) conn.setRequestProperty("Cookie", cookies);
            try {
                int code = conn.getResponseCode();
                if (code >= 300 && code < 400) {
                    String location = conn.getHeaderField("Location");
                    if (location == null || location.isEmpty()) throw new IllegalStateException("跳转缺少目标地址");
                    url = new URL(url, location);
                    continue;
                }
                if (code != 200) throw new IllegalStateException("图片获取失败 " + code);
                String contentType = conn.getContentType();
                if (contentType == null || !contentType.toLowerCase(java.util.Locale.ROOT).startsWith("image/"))
                    throw new IllegalStateException("该链接不是图片");
                long length = conn.getContentLengthLong();
                if (length > MAX_REMOTE_BYTES) throw new IllegalStateException("图片太大");
                try (InputStream input = conn.getInputStream(); ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[8192];
                    int read;
                    while ((read = input.read(buffer)) != -1) {
                        if (output.size() + read > MAX_REMOTE_BYTES) throw new IllegalStateException("图片太大");
                        output.write(buffer, 0, read);
                    }
                    byte[] result = output.toByteArray();
                    BitmapFactory.Options opts = new BitmapFactory.Options();
                    opts.inJustDecodeBounds = true;
                    BitmapFactory.decodeByteArray(result, 0, result.length, opts);
                    if (opts.outWidth <= 0 || opts.outHeight <= 0)
                        throw new IllegalStateException("无法解析图片");
                    return result;
                }
            } finally { conn.disconnect(); }
        }
        throw new IllegalStateException("图片跳转次数过多");
    }

    private void returnPhoto(Uri image) {
        Intent data = new Intent();
        data.setData(image);
        data.setClipData(ClipData.newRawUri("已选择的商品照片", image));
        data.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        setResult(Activity.RESULT_OK, data);
        finish();
    }

    @Override protected void onDestroy() {
        worker.shutdownNow();
        if (web != null) {
            web.stopLoading();
            web.setWebChromeClient(null);
            web.setWebViewClient(null);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
