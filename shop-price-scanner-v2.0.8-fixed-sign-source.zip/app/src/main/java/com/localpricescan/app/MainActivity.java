package com.localpricescan.app;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.content.pm.PackageManager;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

/** 只在点击按钮后扫码，已有商品进入独立只读详情页。 */
public final class MainActivity extends Activity {
    private static final int CREATE_PRODUCT_REQUEST = 308;
    private ProductDatabase database;
    private TextView productCount;
    private int lastHomeSizeMode = -1;
    private String pendingBarcode;
    private boolean scannerLaunching;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppUi.apply(this);
        setContentView(R.layout.activity_main);
        database = new ProductDatabase(this);
        productCount = findViewById(R.id.homeProductCount);
        TextView version = findViewById(R.id.homeVersion);
        try {
            version.setText("v" + getPackageManager().getPackageInfo(getPackageName(), 0).versionName);
        } catch (PackageManager.NameNotFoundException ignored) {
            version.setText("v2.0.2");
        }
        pressFeedback(findViewById(R.id.scanButton));
        pressFeedback(findViewById(R.id.productListButton));
        pressFeedback(findViewById(R.id.backupButton));
        findViewById(R.id.scanButton).setOnClickListener(v -> launchScanner());
        findViewById(R.id.productListButton).setOnClickListener(v -> {
            BackPreview.capture(this);
            startActivity(new Intent(this, ProductListActivity.class));
        });
        findViewById(R.id.backupButton).setOnClickListener(v -> {
            BackPreview.capture(this);
            startActivity(new Intent(this, BackupActivity.class));
        });
        // 根据可用窗口高度切换紧凑布局；卡片占满剩余空间，不出现滚动。
        LinearLayout homeRoot = findViewById(R.id.homeRoot);
        homeRoot.addOnLayoutChangeListener((view, left, top, right, bottom,
                                            oldLeft, oldTop, oldRight, oldBottom) -> {
            if (bottom > top) adjustHomeForHeight((bottom - top) / getResources().getDisplayMetrics().density);
        });
        if (state != null) pendingBarcode = state.getString("pendingBarcode");
    }

    @Override protected void onResume() {
        super.onResume();
        if (database != null) {
            try {
                productCount.setText("已录入 " + database.count() + " 件商品");
            } catch (SQLiteException e) {
                productCount.setText("商品数量读取失败");
            }
        }
    }

    private void launchScanner() {
        if (scannerLaunching || isFinishing() || isDestroyed()) return;
        scannerLaunching = true;
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setCaptureActivity(PortraitCaptureActivity.class);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES);
        integrator.setPrompt("将商品条形码放入扫描框");
        integrator.setBeepEnabled(false);
        integrator.setBarcodeImageEnabled(false);
        integrator.setOrientationLocked(true);
        BackPreview.capture(this);
        try { integrator.initiateScan(); }
        catch (RuntimeException e) {
            BackPreview.clearPending();
            scannerLaunching = false;
            Toast.makeText(this, "无法启动扫码，请检查相机权限", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        if (request == CREATE_PRODUCT_REQUEST) {
            super.onActivityResult(request, result, data);
            String barcode = pendingBarcode;
            pendingBarcode = null;
            if (result == RESULT_OK && barcode != null) {
                try {
                    ProductDatabase.Product created = database.get(barcode);
                    if (created != null) {
                        openReadOnlyDetail(created.barcode);
                    }
                } catch (SQLiteException e) {
                    Toast.makeText(this, "查询商品失败", Toast.LENGTH_LONG).show();
                }
            }
            return;
        }
        IntentResult scan = IntentIntegrator.parseActivityResult(request, result, data);
        if (scan == null) { super.onActivityResult(request, result, data); return; }
        scannerLaunching = false;
        String barcode = BarcodeKey.scanned(scan.getContents());
        if (barcode.isEmpty()) return;
        try {
            ProductDatabase.Product product = database.get(barcode);
            if (product != null) {
                openReadOnlyDetail(product.barcode);
            } else {
                pendingBarcode = barcode;
                Intent intent = new Intent(this, ProductEditorActivity.class);
                intent.putExtra("barcode", barcode);
                BackPreview.capture(this);
                startActivityForResult(intent, CREATE_PRODUCT_REQUEST);
            }
        } catch (SQLiteException e) {
            Toast.makeText(this, "查询商品失败", Toast.LENGTH_LONG).show();
        }
    }

    /** 三个首页按钮保留正常点击，仅增加轻微按下缩放反馈。 */
    private void pressFeedback(View button) {
        button.setOnTouchListener((view, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().cancel();
                    view.animate().scaleX(0.985f).scaleY(0.985f).setDuration(85).start();
                    break;
                case MotionEvent.ACTION_CANCEL:
                case MotionEvent.ACTION_UP:
                    view.animate().cancel();
                    view.animate().scaleX(1f).scaleY(1f).setDuration(110).start();
                    break;
                default: break;
            }
            return false;
        });
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void setHeightAndTopMargin(View view, int height, int marginTop) {
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) view.getLayoutParams();
        params.height = dp(height);
        params.topMargin = dp(marginTop);
        view.setLayoutParams(params);
    }

    /** 屏幕高度分档缩放固定区域，确保下方三行提示获得充分空间。 */
    private void adjustHomeForHeight(float availableDp) {
        float fontScale = getResources().getConfiguration().fontScale;
        // 系统放大字体时提前采用紧凑档，避免提示文字被遮挡。
        float usable = availableDp / Math.max(1f, fontScale);
        int mode = usable < 615f ? 2 : usable < 725f ? 1 : 0;
        if (mode == lastHomeSizeMode) return;
        lastHomeSizeMode = mode;

        boolean shortScreen = mode == 2;
        boolean medium = mode == 1;
        LinearLayout root = findViewById(R.id.homeRoot);
        root.setPadding(dp(18), dp(shortScreen ? 7 : medium ? 11 : 18),
                dp(18), dp(shortScreen ? 5 : 9));
        ((TextView) findViewById(R.id.homeIcon)).setTextSize(shortScreen ? 23 : medium ? 30 : 36);
        ((TextView) findViewById(R.id.homeTitle)).setTextSize(shortScreen ? 23 : medium ? 26 : 29);
        ((TextView) findViewById(R.id.homeSubtitle)).setTextSize(shortScreen ? 12 : medium ? 13 : 14);
        TextView secondarySubtitle = findViewById(R.id.homeSecondarySubtitle);
        secondarySubtitle.setVisibility(shortScreen ? View.GONE : View.VISIBLE);
        secondarySubtitle.setTextSize(medium ? 11 : 12);

        setHeightAndTopMargin(findViewById(R.id.scanButton), shortScreen ? 50 : medium ? 58 : 68,
                shortScreen ? 7 : medium ? 15 : 26);
        setHeightAndTopMargin(findViewById(R.id.productListButton), shortScreen ? 47 : medium ? 53 : 62,
                shortScreen ? 5 : medium ? 8 : 12);
        setHeightAndTopMargin(findViewById(R.id.backupButton), shortScreen ? 47 : medium ? 53 : 62,
                shortScreen ? 5 : medium ? 8 : 12);
        ((TextView) findViewById(R.id.scanButton)).setTextSize(shortScreen ? 17 : medium ? 18 : 20);
        ((TextView) findViewById(R.id.productListButton)).setTextSize(shortScreen ? 16 : medium ? 17 : 19);
        ((TextView) findViewById(R.id.backupButton)).setTextSize(shortScreen ? 16 : medium ? 17 : 19);

        TextView count = findViewById(R.id.homeProductCount);
        LinearLayout.LayoutParams countParams = (LinearLayout.LayoutParams) count.getLayoutParams();
        countParams.topMargin = dp(shortScreen ? 7 : medium ? 10 : 16);
        count.setLayoutParams(countParams);
        count.setPadding(dp(8), dp(shortScreen ? 7 : medium ? 9 : 12),
                dp(8), dp(shortScreen ? 7 : medium ? 9 : 12));
        count.setTextSize(shortScreen ? 12 : medium ? 13 : 14);

        LinearLayout tips = findViewById(R.id.homeTipsCard);
        LinearLayout.LayoutParams tipsParams = (LinearLayout.LayoutParams) tips.getLayoutParams();
        tipsParams.topMargin = dp(shortScreen ? 6 : medium ? 9 : 12);
        tips.setLayoutParams(tipsParams);
        tips.setPadding(dp(shortScreen ? 7 : medium ? 9 : 12),
                dp(shortScreen ? 7 : medium ? 9 : 12),
                dp(shortScreen ? 7 : medium ? 9 : 12),
                dp(shortScreen ? 7 : medium ? 9 : 12));
        TextView header = findViewById(R.id.homeTipsTitle);
        header.setTextSize(shortScreen ? 12 : medium ? 14 : 15);
        LinearLayout.LayoutParams headerParams = (LinearLayout.LayoutParams) header.getLayoutParams();
        headerParams.bottomMargin = dp(shortScreen ? 2 : medium ? 4 : 6);
        header.setLayoutParams(headerParams);

        LinearLayout grid = findViewById(R.id.homeTipsGrid);
        for (int i = 0; i < grid.getChildCount(); i++) {
            LinearLayout row = (LinearLayout) grid.getChildAt(i);
            for (int j = 0; j < row.getChildCount(); j++) {
                LinearLayout tile = (LinearLayout) row.getChildAt(j);
                tile.setPadding(dp(shortScreen ? 6 : medium ? 7 : 9),
                        dp(shortScreen ? 2 : 4), dp(shortScreen ? 6 : medium ? 7 : 9),
                        dp(shortScreen ? 2 : 4));
                ((TextView) tile.getChildAt(0)).setTextSize(shortScreen ? 11 : medium ? 12 : 13);
                TextView detail = (TextView) tile.getChildAt(1);
                detail.setTextSize(shortScreen ? 10 : 11);
                LinearLayout.LayoutParams detailParams = (LinearLayout.LayoutParams) detail.getLayoutParams();
                detailParams.topMargin = dp(shortScreen ? 1 : 3);
                detail.setLayoutParams(detailParams);
            }
        }
    }

    private void openReadOnlyDetail(String barcode) {
        Intent intent = new Intent(this, ProductDetailActivity.class);
        intent.putExtra("barcode", barcode);
        intent.putExtra("scanResult", true);
        BackPreview.capture(this);
        startActivity(intent);
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("pendingBarcode", pendingBarcode);
    }

    @Override protected void onDestroy() {
        if (database != null) database.close();
        super.onDestroy();
    }
}
