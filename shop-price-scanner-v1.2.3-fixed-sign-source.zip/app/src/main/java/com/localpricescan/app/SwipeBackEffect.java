package com.localpricescan.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Outline;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;

/** 当前页缩小飞向右下角，底层持续显示真正的上一页截图，不露白。 */
final class SwipeBackEffect {
    private final Activity activity;
    private final Bitmap previousScreen;
    private View foreground;
    private FrameLayout frame;
    private boolean finishing;
    private boolean dragging;

    SwipeBackEffect(Activity activity, Bitmap previousScreen) {
        this.activity = activity;
        this.previousScreen = previousScreen;
    }

    /** 页面初始化后立即铺好上一页画面，避免用户起滑时才创建 View 导致卡顿。 */
    void install() {
        if (foreground != null) return;
        View content = activity.findViewById(android.R.id.content);
        if (!(content instanceof FrameLayout)) return;
        frame = (FrameLayout)content;
        if (frame.getChildCount() == 0) return;
        foreground = frame.getChildAt(frame.getChildCount()-1);

        // 在当前页下方插入真正的上一页图像；无缓存时仍使用自然风背景，不露白。
        ImageView underlay = new ImageView(activity);
        underlay.setBackgroundResource(R.drawable.nature_wallpaper);
        if (previousScreen != null) {
            underlay.setImageBitmap(previousScreen);
            underlay.setScaleType(ImageView.ScaleType.FIT_XY);
        }
        frame.addView(underlay,0,new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT));
    }

    boolean begin() {
        if (finishing) return false;
        install();
        if (foreground == null) return false;
        if (dragging) return true;
        dragging = true;
        foreground.setPivotX(foreground.getWidth() / 2f);
        foreground.setPivotY(foreground.getHeight() / 2f);
        foreground.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0,0,view.getWidth(),view.getHeight(),dp(20));
            }
        });
        foreground.setClipToOutline(true);
        foreground.setElevation(dp(8));
        foreground.setLayerType(View.LAYER_TYPE_HARDWARE,null);
        return true;
    }

    private int dp(float amount) {
        return Math.round(amount * activity.getResources().getDisplayMetrics().density);
    }

    void drag(float dx) {
        if (!begin()) return;
        foreground.animate().cancel();
        float fraction = Math.min(1f,Math.max(0f,dx / Math.max(1f,frame.getWidth())));
        float scale = 1f - fraction * .33f;
        foreground.setScaleX(scale);
        foreground.setScaleY(scale);
        foreground.setTranslationX(Math.max(0f,dx) * .67f);
        foreground.setTranslationY(frame.getHeight() * .11f * fraction);
        foreground.setAlpha(1f);
    }

    void dismiss(Runnable navigateBack) {
        if (finishing) return;
        if (foreground == null || frame == null) {
            navigateBack.run();
            return;
        }
        finishing = true;
        float x = Math.max(foreground.getTranslationX(),frame.getWidth() * .47f);
        float y = frame.getHeight() * .47f;
        foreground.animate().cancel();
        foreground.animate()
                .translationX(x).translationY(y)
                .scaleX(.04f).scaleY(.04f).alpha(0f)
                .setDuration(180)
                .setInterpolator(new AccelerateInterpolator(1.15f))
                .withEndAction(navigateBack).start();
    }

    void restore(boolean immediately) {
        if (foreground == null || finishing) return;
        foreground.animate().cancel();
        if (immediately) {
            foreground.setTranslationX(0f);
            foreground.setTranslationY(0f);
            foreground.setScaleX(1f);
            foreground.setScaleY(1f);
            foreground.setAlpha(1f);
            cleanup();
        } else {
            foreground.animate().translationX(0f).translationY(0f)
                    .scaleX(1f).scaleY(1f).alpha(1f)
                    .setDuration(110)
                    .setInterpolator(new DecelerateInterpolator())
                    .withEndAction(this::cleanup).start();
        }
    }

    private void cleanup() {
        if (foreground == null) return;
        foreground.setLayerType(View.LAYER_TYPE_NONE,null);
        foreground.setElevation(0f);
        foreground.setClipToOutline(false);
        dragging = false;
    }

    boolean isFinishing() { return finishing; }
}
