package com.localpricescan.app;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

/** 只在点击按钮后扫码，已有商品进入独立只读详情页。 */
public final class MainActivity extends Activity {
    private static final int CREATE_PRODUCT_REQUEST = 308;
    private ProductDatabase database;
    private TextView productCount;
    private String pendingBarcode;
    private boolean scannerLaunching;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppUi.apply(this);
        setContentView(R.layout.activity_main);
        database = new ProductDatabase(this);
        productCount = findViewById(R.id.homeProductCount);
        findViewById(R.id.scanButton).setOnClickListener(v -> launchScanner());
        findViewById(R.id.productListButton).setOnClickListener(v -> {
            BackPreview.capture(this);
            startActivity(new Intent(this, ProductListActivity.class));
        });
        findViewById(R.id.backupButton).setOnClickListener(v -> {
            BackPreview.capture(this);
            startActivity(new Intent(this, BackupActivity.class));
        });
        if (state != null) pendingBarcode = state.getString("pendingBarcode");
    }

    @Override protected void onResume() {
        super.onResume();
        if (database != null) {
            try { productCount.setText("已录入 " + database.count() + " 件商品"); }
            catch (SQLiteException e) { productCount.setText("商品数量读取失败"); }
        }
    }

    private void launchScanner() {
        if (scannerLaunching || isFinishing() || isDestroyed()) return;
        scannerLaunching = true;
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setCaptureActivity(PortraitCaptureActivity.class);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES);
        integrator.setPrompt("将商品条形码放入扫描框");
        integrator.setBeepEnabled(false);
        integrator.setBarcodeImageEnabled(false);
        integrator.setOrientationLocked(true);
        BackPreview.capture(this);
        try { integrator.initiateScan(); }
        catch (RuntimeException e) {
            BackPreview.clearPending();
            scannerLaunching = false;
            Toast.makeText(this, "无法启动扫码，请检查相机权限", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        if (request == CREATE_PRODUCT_REQUEST) {
            super.onActivityResult(request, result, data);
            String barcode = pendingBarcode;
            pendingBarcode = null;
            if (result == RESULT_OK && barcode != null) {
                try {
                    ProductDatabase.Product created = database.get(barcode);
                    if (created != null) openReadOnlyDetail(created.barcode);
                } catch (SQLiteException e) {
                    Toast.makeText(this, "查询商品失败", Toast.LENGTH_LONG).show();
                }
            }
            return;
        }
        IntentResult scan = IntentIntegrator.parseActivityResult(request, result, data);
        if (scan == null) { super.onActivityResult(request, result, data); return; }
        scannerLaunching = false;
        String barcode = BarcodeKey.scanned(scan.getContents());
        if (barcode.isEmpty()) return;
        try {
            ProductDatabase.Product product = database.get(barcode);
            if (product != null) {
                openReadOnlyDetail(product.barcode);
            } else {
                pendingBarcode = barcode;
                Intent intent = new Intent(this, ProductEditorActivity.class);
                intent.putExtra("barcode", barcode);
                BackPreview.capture(this);
                startActivityForResult(intent, CREATE_PRODUCT_REQUEST);
            }
        } catch (SQLiteException e) {
            Toast.makeText(this, "查询商品失败", Toast.LENGTH_LONG).show();
        }
    }

    private void openReadOnlyDetail(String barcode) {
        Intent intent = new Intent(this, ProductDetailActivity.class);
        intent.putExtra("barcode", barcode);
        intent.putExtra("scanResult", true);
        BackPreview.capture(this);
        startActivity(intent);
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("pendingBarcode", pendingBarcode);
    }

    @Override protected void onDestroy() {
        if (database != null) database.close();
        super.onDestroy();
    }
}
