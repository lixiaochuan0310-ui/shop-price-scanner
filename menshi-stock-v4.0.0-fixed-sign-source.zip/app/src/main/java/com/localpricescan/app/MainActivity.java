package com.localpricescan.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteException;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

/** 概念图首页：两行统计数据、八宫格、三个辅助入口；首页不使用滚动容器。 */
public final class MainActivity extends Activity {
    private static final int NEW_ITEM=311;
    private ProductDatabase db;
    private TextView productCount,stockQuantity,stockValue;
    private String pendingBarcode;
    private boolean scanning;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);AppUi.apply(this);db=new ProductDatabase(this);
        getWindow().setBackgroundDrawableResource(R.drawable.bg_app_surface);
        int heightDp=(int)(getResources().getDisplayMetrics().heightPixels/
                getResources().getDisplayMetrics().density);
        boolean compactHome=heightDp<660;
        LinearLayout root=StoreUi.column(this);
        root.setPadding(StoreUi.d(this,12),StoreUi.d(this,compactHome?6:10),
                StoreUi.d(this,12),StoreUi.d(this,compactHome?6:10));
        root.setBackgroundColor(StoreUi.PALE);setContentView(root);

        LinearLayout header=StoreUi.row(this);header.setPadding(StoreUi.d(this,5),StoreUi.d(this,6),StoreUi.d(this,5),StoreUi.d(this,6));
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.ic_store_brand_header);
        LinearLayout.LayoutParams logoLp=StoreUi.lp(StoreUi.d(this,46),StoreUi.d(this,46));logoLp.rightMargin=StoreUi.d(this,9);
        header.addView(logo,logoLp);
        LinearLayout nameGroup=StoreUi.column(this);
        TextView brand=StoreUi.text(this,"门市进销存",23,true);brand.setTextColor(0xff245b65);nameGroup.addView(brand);
        TextView sub=StoreUi.text(this,"商品 · 入库 · 销售 · 库存 · 报表",11,false);sub.setTextColor(StoreUi.MUTED);nameGroup.addView(sub);
        header.addView(nameGroup,new LinearLayout.LayoutParams(0,-2,1));
        GradientDrawable headerBg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xff227b74,0xff4aafa6});
        headerBg.setCornerRadius(StoreUi.d(this,18));header.setBackground(headerBg);
        header.setPadding(StoreUi.d(this,11),StoreUi.d(this,12),
                StoreUi.d(this,11),StoreUi.d(this,12));
        brand.setTextColor(0xffffffff);sub.setTextColor(0xffe8faf5);
        header.setClipToOutline(true);
        TextView version=StoreUi.text(this,"V4.0.0",11,false);
        try{version.setText("V"+getPackageManager().getPackageInfo(getPackageName(),0).versionName);}catch(PackageManager.NameNotFoundException ignored){}
        version.setTextColor(0xffffffff);header.addView(version);root.addView(header);
        StoreUi.gap(root,compactHome?5:8);

        LinearLayout stats=StoreUi.row(this);
        productCount=stat(stats,"商品总数","—","种",0xff329d74,0xffffffff);
        stockQuantity=stat(stats,"库存总量","—","",0xff4f91ca,0xffffffff);
        stockValue=stat(stats,"库存金额","—","",0xffeba451,0xffffffff);
        root.addView(stats);StoreUi.gap(root,compactHome?7:12);

        LinearLayout gridCard=StoreUi.column(this);gridCard.setPadding(StoreUi.d(this,9),StoreUi.d(this,compactHome?6:12),StoreUi.d(this,9),StoreUi.d(this,4));
        gridCard.setBackground(StoreUi.round(0xffffffff,22,this));
        root.addView(gridCard,new LinearLayout.LayoutParams(-1,0,1));
        String[] names={"扫码查价","商品管理","商品入库","商品销售","内部领用","库存查询","统计报表","业务流水"};
        int[] icons={R.drawable.ic_home_scan,R.drawable.ic_home_items,R.drawable.ic_home_in,R.drawable.ic_home_sale,
                R.drawable.ic_home_issue,R.drawable.ic_home_stock,R.drawable.ic_home_reports,R.drawable.ic_home_records};
        int[][] colors={{0xffe9f5fd,0xffd1e8fa},{0xfffff3df,0xffffe8c6},
                {0xffe6f6ee,0xffccebd9},{0xfff3ecfb,0xffe2d2f2},
                {0xffffefd9,0xffffe2c3},{0xffe4f2fc,0xffd3e7f8},
                {0xfff1e9fa,0xffe2d8f5},{0xffe4f7f3,0xffd0ede6}};
        for(int rowIndex=0;rowIndex<2;rowIndex++){
            LinearLayout tileRow=StoreUi.row(this);
            LinearLayout.LayoutParams rowLp=new LinearLayout.LayoutParams(-1,0,1);
            rowLp.bottomMargin=StoreUi.d(this,compactHome?3:7);
            gridCard.addView(tileRow,rowLp);
            for(int col=0;col<4;col++){
                int index=rowIndex*4+col;
                LinearLayout tile=StoreUi.column(this);tile.setGravity(Gravity.CENTER);
                GradientDrawable background=new GradientDrawable(GradientDrawable.Orientation.TL_BR,colors[index]);
                background.setCornerRadius(StoreUi.d(this,14));tile.setBackground(background);
                ImageView icon=new ImageView(this);icon.setImageResource(icons[index]);
                icon.setContentDescription(names[index]);
                int iconSize=compactHome?25:32;
                tile.addView(icon,StoreUi.lp(StoreUi.d(this,iconSize),StoreUi.d(this,iconSize)));
                StoreUi.gap(tile,compactHome?3:6);
                TextView label=StoreUi.text(this,names[index],12,true);label.setGravity(Gravity.CENTER);
                label.setMaxLines(2);label.setIncludeFontPadding(false);tile.addView(label);
                LinearLayout.LayoutParams tileLp=new LinearLayout.LayoutParams(0,-1,1);
                if(col<3)tileLp.rightMargin=StoreUi.d(this,5);
                tileRow.addView(tile,tileLp);tile.setContentDescription(names[index]);tile.setOnClickListener(v->open(index));
            }
        }
        StoreUi.gap(root,compactHome?5:9);
        LinearLayout foot=StoreUi.row(this);
        footer(foot,"其他出库",v->activity(StoreDocumentActivity.class,"OTHER"));
        footer(foot,"库存盘点",v->activity(StoreCountActivity.class,null));
        footer(foot,"备份恢复",v->activity(StoreBackupActivity.class,null));
        root.addView(foot);if(state!=null)pendingBarcode=state.getString("pendingBarcode");
    }
    private TextView stat(LinearLayout row,String caption,String number,String unit,int background,int fg){
        LinearLayout card=StoreUi.column(this);card.setPadding(StoreUi.d(this,4),StoreUi.d(this,10),StoreUi.d(this,4),StoreUi.d(this,10));
        card.setGravity(Gravity.CENTER);card.setBackground(StoreUi.round(background,14,this));
        TextView title=StoreUi.text(this,caption,12,true);title.setTextColor(fg);card.addView(title);
        TextView value=StoreUi.text(this,number+unit,21,true);value.setTextColor(fg);card.addView(value);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.rightMargin=StoreUi.d(this,5);row.addView(card,p);
        return value;
    }
    private void footer(LinearLayout row,String label,View.OnClickListener listener){
        TextView b=StoreUi.button(this,label,0xffe7f3f2,StoreUi.GREEN);b.setTextSize(13);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.rightMargin=StoreUi.d(this,5);
        row.addView(b,p);b.setOnClickListener(listener);
    }
    private void activity(Class<?> screen,String kind){Intent i=new Intent(this,screen);if(kind!=null)i.putExtra("kind",kind);BackPreview.capture(this);startActivity(i);}
    private void open(int index){
        AuditTrail.record(this,"功能入口",new String[]{"扫码查价","商品管理","商品入库","商品销售",
                "内部领用","库存查询","统计报表","业务流水"}[index],"首页八宫格");
        switch(index){
            case 0:startScanner();break;
            case 1:activity(ProductListActivity.class,null);break;
            case 2:activity(StoreDocumentActivity.class,"IN");break;
            case 3:activity(StoreDocumentActivity.class,"SALE");break;
            case 4:activity(StoreDocumentActivity.class,"ISSUE");break;
            case 5:activity(StoreStockActivity.class,null);break;
            case 6:activity(StoreReportsActivity.class,null);break;
            case 7:activity(StoreRecordsActivity.class,null);break;
        }
    }
    @Override protected void onResume(){
        super.onResume();scanning=false;
        try{AuditTrail.record(this,"打开页面","首页","查看门市数据概览");}catch(Exception ignored){}
        if(db!=null && productCount!=null){
            try{
                int n=db.count();long totalQty=0;
                java.math.BigDecimal stockCents=java.math.BigDecimal.ZERO;
                for(InventoryStore.StockRow row:new InventoryStore(db).stocks()){
                    if(row.current<=0)continue;
                    totalQty=Math.addExact(totalQty,row.current);
                    ProductDatabase.Product p=db.get(row.barcode);
                    if(p!=null)stockCents=stockCents.add(java.math.BigDecimal.valueOf(p.purchaseCents)
                            .multiply(java.math.BigDecimal.valueOf(row.current))
                            .divide(java.math.BigDecimal.valueOf(1000),0,java.math.RoundingMode.HALF_UP));
                }
                productCount.setText(n+"种");stockQuantity.setText(InventoryStore.qty(totalQty));
                stockValue.setText(Money.show(stockCents.longValueExact()));
            }catch(Exception e){productCount.setText("—");stockQuantity.setText("—");stockValue.setText("—");}
        }
    }
    private void startScanner(){
        if(scanning)return;scanning=true;IntentIntegrator i=new IntentIntegrator(this);
        i.setCaptureActivity(PortraitCaptureActivity.class);i.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES);
        i.setPrompt("将商品条形码放入扫描框");i.setBeepEnabled(false);i.setOrientationLocked(true);
        try{i.initiateScan();}catch(RuntimeException e){scanning=false;Toast.makeText(this,"扫码无法启动，请检查相机权限",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        if(request==NEW_ITEM){super.onActivityResult(request,result,data);String code=pendingBarcode;pendingBarcode=null;
            if(result==RESULT_OK&&code!=null&&db.get(code)!=null)detail(code);return;}
        IntentResult scan=IntentIntegrator.parseActivityResult(request,result,data);
        if(scan==null){super.onActivityResult(request,result,data);return;}scanning=false;
        String code=BarcodeKey.scanned(scan.getContents());if(code.isEmpty())return;
        AuditTrail.record(this,"扫码查价",code,"已扫描条形码并查询本地商品库");
        try{ProductDatabase.Product p=db.get(code);
            if(p!=null){Toast.makeText(this,"该商品已登记，正在显示已有商品",Toast.LENGTH_SHORT).show();detail(p.barcode);}
            else{pendingBarcode=code;Intent i=new Intent(this,ProductEditorActivity.class);i.putExtra("barcode",code);startActivityForResult(i,NEW_ITEM);}
        }catch(SQLiteException e){Toast.makeText(this,"商品查询失败",Toast.LENGTH_LONG).show();}
    }
    private void detail(String code){Intent i=new Intent(this,ProductDetailActivity.class);i.putExtra("barcode",code);
        i.putExtra("scanResult",true);BackPreview.capture(this);startActivity(i);}
    @Override protected void onSaveInstanceState(Bundle state){super.onSaveInstanceState(state);state.putString("pendingBarcode",pendingBarcode);}
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
