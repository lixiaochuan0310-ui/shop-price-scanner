package com.localpricescan.app;

import android.app.Activity;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** 仅列出已录入商品；点击某条可修改名称、进价、售价。 */
public final class ProductListActivity extends Activity {
    private ProductDatabase database;
    private final List<ProductDatabase.Product> products = new ArrayList<>();
    private BaseAdapter adapter;
    private TextView countView;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_product_list);
        database = new ProductDatabase(this);
        findViewById(R.id.listBackButton).setOnClickListener(v -> finish());
        countView = findViewById(R.id.productCountText);
        ListView list = findViewById(R.id.productList);
        list.setEmptyView(findViewById(R.id.emptyProducts));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return products.size(); }
            @Override public Object getItem(int position) { return products.get(position); }
            @Override public long getItemId(int position) { return position; }
            @Override public View getView(int position, View reused, ViewGroup parent) {
                View row = reused == null ? LayoutInflater.from(ProductListActivity.this)
                        .inflate(R.layout.row_product, parent, false) : reused;
                ProductDatabase.Product product = products.get(position);
                ((TextView) row.findViewById(R.id.rowName)).setText(product.name);
                ((TextView) row.findViewById(R.id.rowBarcode)).setText("条形码  " + product.barcode);
                ((TextView) row.findViewById(R.id.rowPrices)).setText(
                        "进价 " + Money.show(product.purchaseCents) + "     售价 " + Money.show(product.saleCents));
                return row;
            }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, position, id) -> {
            ProductDatabase.Product product = products.get(position);
            EditProductDialog.open(this, database, product, this::refresh);
        });
        refresh();
    }

    private void refresh() {
        try {
            products.clear();
            products.addAll(database.all());
            countView.setText("共 " + products.size() + " 件已录入商品 · 点击可修改");
            adapter.notifyDataSetChanged();
        } catch (SQLiteException error) {
            Toast.makeText(this, "商品列表读取失败", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onDestroy() {
        if (database != null) database.close();
        super.onDestroy();
    }
}
