package com.localpricescan.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/** 保持 V1.0 的数据库文件、表和列名不变；价格均以分保存。 */
final class ProductDatabase extends SQLiteOpenHelper {
    static final String DATABASE = "offline_products.db";
    private static final int VERSION = 1;

    ProductDatabase(Context context) {
        super(context, DATABASE, null, VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE products (" +
                "barcode TEXT PRIMARY KEY NOT NULL, " +
                "name TEXT NOT NULL, " +
                "purchase_cents INTEGER NOT NULL CHECK(purchase_cents >= 0), " +
                "sale_cents INTEGER NOT NULL CHECK(sale_cents >= 0))");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 结构仍为 V1：绝不清空或重建现有商品表。
    }

    Product get(String barcode) {
        try (Cursor cursor = getReadableDatabase().query(
                "products", new String[]{"name", "purchase_cents", "sale_cents"},
                "barcode = ?", new String[]{barcode}, null, null, null)) {
            if (!cursor.moveToFirst()) return null;
            return new Product(barcode, cursor.getString(0), cursor.getLong(1), cursor.getLong(2));
        }
    }

    List<Product> all() {
        List<Product> products = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query("products",
                new String[]{"barcode", "name", "purchase_cents", "sale_cents"},
                null, null, null, null, "name COLLATE NOCASE ASC, barcode ASC")) {
            while (cursor.moveToNext()) {
                products.add(new Product(cursor.getString(0), cursor.getString(1),
                        cursor.getLong(2), cursor.getLong(3)));
            }
        }
        return products;
    }

    int count() {
        try (Cursor cursor = getReadableDatabase().rawQuery("SELECT count(*) FROM products", null)) {
            return cursor.moveToFirst() ? cursor.getInt(0) : 0;
        }
    }

    private static ContentValues values(Product product) {
        ContentValues values = new ContentValues();
        values.put("barcode", product.barcode);
        values.put("name", product.name);
        values.put("purchase_cents", product.purchaseCents);
        values.put("sale_cents", product.saleCents);
        return values;
    }

    void insert(Product product) {
        getWritableDatabase().insertOrThrow("products", null, values(product));
    }

    boolean update(Product product) {
        return getWritableDatabase().update("products", values(product),
                "barcode = ?", new String[]{product.barcode}) == 1;
    }

    /** 导入是完全替换；先在外部完整校验，再在单个事务中执行。失败回滚。 */
    void replaceAll(List<Product> products) {
        HashSet<String> seen = new HashSet<>();
        for (Product product : products) {
            if (product.barcode.isEmpty() || product.name.trim().isEmpty() ||
                    product.purchaseCents < 0 || product.saleCents < 0 ||
                    !seen.add(product.barcode)) {
                throw new IllegalArgumentException("备份数据无效或包含重复条码");
            }
        }
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("products", null, null);
            for (Product product : products) {
                long id = db.insertOrThrow("products", null, values(product));
                if (id == -1) throw new SQLiteConstraintException("商品恢复失败");
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    static final class Product {
        final String barcode;
        final String name;
        final long purchaseCents;
        final long saleCents;

        Product(String barcode, String name, long purchaseCents, long saleCents) {
            this.barcode = barcode;
            this.name = name;
            this.purchaseCents = purchaseCents;
            this.saleCents = saleCents;
        }
    }
}
