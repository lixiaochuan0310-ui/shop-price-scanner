package com.localpricescan.app;

import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.text.TextUtils;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;


/** 手动扫码：已有商品直接显示价格；新条码录入三项并本地保存。 */
public final class MainActivity extends Activity {
    private ProductDatabase database;
    private View initialCard, resultCard, addCard;
    private TextView resultBarcode, resultName, resultPurchase, resultSale, addBarcode;
    private EditText nameInput, purchaseInput, saleInput;
    private String lastBarcode;
    private boolean scannerLaunching;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(0xFFF6F9FF);
        getWindow().setNavigationBarColor(0xFFF6F9FF);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        setContentView(R.layout.activity_main);
        database = new ProductDatabase(this);

        initialCard = findViewById(R.id.initialCard);
        resultCard = findViewById(R.id.resultCard);
        addCard = findViewById(R.id.addCard);
        resultBarcode = findViewById(R.id.resultBarcode);
        resultName = findViewById(R.id.resultName);
        resultPurchase = findViewById(R.id.resultPurchase);
        resultSale = findViewById(R.id.resultSale);
        addBarcode = findViewById(R.id.addBarcode);
        nameInput = findViewById(R.id.nameInput);
        purchaseInput = findViewById(R.id.purchaseInput);
        saleInput = findViewById(R.id.saleInput);

        findViewById(R.id.scanButton).setOnClickListener(v -> launchScanner());
        findViewById(R.id.scanAgainButton).setOnClickListener(v -> launchScanner());
        findViewById(R.id.scanFromFormButton).setOnClickListener(v -> launchScanner());
        findViewById(R.id.saveButton).setOnClickListener(v -> saveProduct());
        findViewById(R.id.editProductButton).setOnClickListener(v -> editCurrentProduct());
        findViewById(R.id.productListButton).setOnClickListener(v ->
                startActivity(new Intent(this, ProductListActivity.class)));
        findViewById(R.id.backupButton).setOnClickListener(v ->
                startActivity(new Intent(this, BackupActivity.class)));
        showOnly(initialCard);

        if (state != null) {
            // 屏幕重建时不自动再次弹出扫描器。
            lastBarcode = state.getString("barcode");
            String mode = state.getString("mode", "initial");
            if ("result".equals(mode) && lastBarcode != null) {
                ProductDatabase.Product product = database.get(lastBarcode);
                if (product != null) showProduct(product);
            } else if ("add".equals(mode) && lastBarcode != null) {
                showAddForm(lastBarcode);
                nameInput.setText(state.getString("name", ""));
                purchaseInput.setText(state.getString("purchase", ""));
                saleInput.setText(state.getString("sale", ""));
            }
        }
    }

    private void launchScanner() {
        if (scannerLaunching || isFinishing() || isDestroyed()) return;
        scannerLaunching = true;
        hideKeyboard();
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setCaptureActivity(PortraitCaptureActivity.class);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES);
        integrator.setPrompt("将商品条形码放入扫描框");
        integrator.setBeepEnabled(false);
        integrator.setBarcodeImageEnabled(false);
        integrator.setOrientationLocked(true);
        try {
            integrator.initiateScan();
        } catch (RuntimeException error) {
            scannerLaunching = false;
            Toast.makeText(this, "无法打开摄像头，请检查相机权限", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (scanResult == null) {
            super.onActivityResult(requestCode, resultCode, data);
            return;
        }
        scannerLaunching = false;
        String barcode = scanResult.getContents();
        if (TextUtils.isEmpty(barcode)) return; // 按返回取消扫描，不清除原有结果。
        lastBarcode = barcode;
        try {
            ProductDatabase.Product existing = database.get(barcode);
            if (existing != null) showProduct(existing);
            else showAddForm(barcode);
        } catch (SQLiteException error) {
            Toast.makeText(this, "商品数据读取失败，请检查手机存储空间", Toast.LENGTH_LONG).show();
        }
    }

    private void editCurrentProduct() {
        if (lastBarcode == null) return;
        ProductDatabase.Product product = database.get(lastBarcode);
        if (product == null) {
            Toast.makeText(this, "商品未找到", Toast.LENGTH_SHORT).show();
            return;
        }
        EditProductDialog.open(this, database, product, () -> {
            ProductDatabase.Product latest = database.get(lastBarcode);
            if (latest != null) showProduct(latest);
        });
    }

    private void showProduct(ProductDatabase.Product product) {
        lastBarcode = product.barcode;
        resultBarcode.setText("条形码  " + product.barcode);
        resultName.setText(product.name);
        resultPurchase.setText(Money.show(product.purchaseCents));
        resultSale.setText(Money.show(product.saleCents));
        showOnly(resultCard);
    }

    private void showAddForm(String barcode) {
        lastBarcode = barcode;
        addBarcode.setText("条形码  " + barcode);
        nameInput.setText("");
        purchaseInput.setText("");
        saleInput.setText("");
        showOnly(addCard);
    }

    private void saveProduct() {
        if (lastBarcode == null) return;
        String name = nameInput.getText().toString().trim();
        Long purchase = Money.parseCents(purchaseInput.getText().toString());
        Long sale = Money.parseCents(saleInput.getText().toString());
        if (name.isEmpty()) {
            nameInput.setError("请输入商品名称");
            nameInput.requestFocus();
            return;
        }
        if (purchase == null) {
            purchaseInput.setError("请输入有效进价，最多两位小数");
            purchaseInput.requestFocus();
            return;
        }
        if (sale == null) {
            saleInput.setError("请输入有效售价，最多两位小数");
            saleInput.requestFocus();
            return;
        }
        try {
            ProductDatabase.Product product = new ProductDatabase.Product(lastBarcode, name, purchase, sale);
            database.insert(product);
            hideKeyboard();
            showProduct(product);
            Toast.makeText(this, "商品已保存到本机", Toast.LENGTH_SHORT).show();
        } catch (SQLiteConstraintException duplicate) {
            ProductDatabase.Product existing = database.get(lastBarcode);
            if (existing != null) showProduct(existing);
            Toast.makeText(this, "此条码已录入", Toast.LENGTH_SHORT).show();
        } catch (SQLiteException error) {
            Toast.makeText(this, "保存失败，请检查手机存储空间", Toast.LENGTH_LONG).show();
        }
    }

    private void showOnly(View view) {
        initialCard.setVisibility(view == initialCard ? View.VISIBLE : View.GONE);
        resultCard.setVisibility(view == resultCard ? View.VISIBLE : View.GONE);
        addCard.setVisibility(view == addCard ? View.VISIBLE : View.GONE);
    }

    private void hideKeyboard() {
        View focused = getCurrentFocus();
        if (focused == null) return;
        InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (keyboard != null) keyboard.hideSoftInputFromWindow(focused.getWindowToken(), 0);
        focused.clearFocus();
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putString("barcode", lastBarcode);
        out.putString("mode", resultCard.getVisibility() == View.VISIBLE ? "result" :
                addCard.getVisibility() == View.VISIBLE ? "add" : "initial");
        out.putString("name", nameInput.getText().toString());
        out.putString("purchase", purchaseInput.getText().toString());
        out.putString("sale", saleInput.getText().toString());
    }

    @Override protected void onDestroy() {
        if (database != null) database.close();
        super.onDestroy();
    }
}
