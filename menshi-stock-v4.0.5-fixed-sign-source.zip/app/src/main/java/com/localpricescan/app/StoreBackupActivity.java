package com.localpricescan.app;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.widget.LinearLayout;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** 数据备份包括商品/照片/单位/所有单据/明细/盘点，整库事务恢复。 */
public final class StoreBackupActivity extends SwipeBackActivity {
    private static final int WRITE=621,READ=622;
    private static final int LIMIT=120*1024*1024;
    private static final String FORMAT="menshi_store_complete_backup";
    private static final String[] TABLES={"product_categories","products","product_images","stock_settings","stock_documents","stock_lines","stock_counts","stock_cancelled_inbound","stock_doc_revisions","operation_logs"};
    private ProductDatabase helper;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);helper=new ProductDatabase(this);
        LinearLayout root=StoreUi.content(this,"数据备份与恢复");setContentView(root);
        LinearLayout body=StoreUi.padded(this,StoreUi.scroll(this,root));
        LinearLayout card=StoreUi.card(this);StoreUi.addCard(body,card);
        card.addView(StoreUi.text(this,"完整数据备份",19,true));StoreUi.gap(card,9);
        TextView note=StoreUi.text(this,"备份包含商品、照片、分类、库存、全部业务单据、盘点、删除前记录和操作日志。",15,false);
        note.setTextColor(StoreUi.MUTED);card.addView(note);StoreUi.gap(card,12);
        TextView backup=StoreUi.button(this,"导出完整备份文件",StoreUi.GREEN,0xffffffff);card.addView(backup);
        backup.setOnClickListener(v->pickerWrite());
        LinearLayout restoreCard=StoreUi.card(this);StoreUi.addCard(body,restoreCard);
        restoreCard.addView(StoreUi.text(this,"从备份文件恢复",19,true));StoreUi.gap(restoreCard,9);
        TextView warning=StoreUi.text(this,"换手机时把备份 JSON 文件传到新手机即可恢复。恢复会替换本机目前的全部门市数据，请先备份现有数据。",15,false);
        warning.setTextColor(StoreUi.MUTED);restoreCard.addView(warning);StoreUi.gap(restoreCard,12);
        TextView restore=StoreUi.button(this,"选择备份文件并恢复",0xffdfebf9,StoreUi.INK);
        restoreCard.addView(restore);restore.setOnClickListener(v->pickerRead());
    }
    private void pickerWrite(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"门市进销存完整备份_"+
                new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.CHINA).format(new Date())+".json");
        startActivityForResult(i,WRITE);
    }
    private void pickerRead(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");startActivityForResult(i,READ);
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        if(req==WRITE)write(data.getData());else if(req==READ)read(data.getData());
    }
    private JSONArray extract(SQLiteDatabase db,String name)throws Exception{
        JSONArray out=new JSONArray();
        try(Cursor c=db.rawQuery("SELECT * FROM "+name,null)){
            String[] cols=c.getColumnNames();
            while(c.moveToNext()){
                JSONObject row=new JSONObject();
                for(int j=0;j<cols.length;j++) {
                    switch(c.getType(j)) {
                        case Cursor.FIELD_TYPE_NULL:row.put(cols[j],JSONObject.NULL);break;
                        case Cursor.FIELD_TYPE_INTEGER:row.put(cols[j],c.getLong(j));break;
                        case Cursor.FIELD_TYPE_FLOAT:row.put(cols[j],c.getDouble(j));break;
                        case Cursor.FIELD_TYPE_BLOB:row.put(cols[j],"base64:"+
                                Base64.encodeToString(c.getBlob(j),Base64.NO_WRAP));break;
                        default:row.put(cols[j],c.getString(j));break;
                    }
                }
                out.put(row);
            }
        }
        return out;
    }
    private void write(Uri uri){
        try{
            AuditTrail.record(this,"备份数据","完整门市备份","开始生成完整备份，包括操作日志");
            SQLiteDatabase db=helper.getReadableDatabase();
            JSONObject backup=new JSONObject();backup.put("format",FORMAT);backup.put("version",1);
            backup.put("created",InventoryStore.dateToday());
            JSONObject content=new JSONObject();
            for(String name:TABLES)content.put(name,extract(db,name));
            backup.put("tables",content);
            byte[] bytes=backup.toString().getBytes(StandardCharsets.UTF_8);
            if(bytes.length>LIMIT)throw new IllegalArgumentException("备份超过120MB，请减少照片数量后重试");
            try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
                if(out==null)throw new IllegalArgumentException("无法写入备份文件");
                out.write(bytes);out.flush();
            }
            AuditTrail.record(this,"备份成功","完整门市备份","备份文件已写入所选位置");
            new AlertDialog.Builder(this).setTitle("备份完成")
                    .setMessage("已保存商品、分类、照片和全部进销存流水。请妥善保管备份文件。")
                    .setPositiveButton("确定",null).show();
        }catch(Exception e){AuditTrail.failure(this,"备份失败","完整门市备份",
                e.getMessage());new AlertDialog.Builder(this).setTitle("备份失败")
                .setMessage(e.getMessage()==null?"无法完成备份":e.getMessage())
                .setPositiveButton("确定",null).show();}
    }
    private static final class Column {
        final String name,type;
        Column(String name,String type){this.name=name;this.type=type;}
    }
    private List<Column> columns(SQLiteDatabase db,String table){
        List<Column> cols=new ArrayList<>();
        try(Cursor c=db.rawQuery("PRAGMA table_info("+table+")",null)){
            while(c.moveToNext())cols.add(new Column(c.getString(1),c.getString(2)));
        }
        return cols;
    }
    private void validate(JSONObject backup)throws Exception{
        if(!FORMAT.equals(backup.optString("format"))||backup.optInt("version")!=1)
            throw new IllegalArgumentException("不是《门市进销存》的完整备份文件");
        JSONObject tables=backup.getJSONObject("tables");
        SQLiteDatabase db=helper.getReadableDatabase();
        for(String table:TABLES){
            JSONArray rows=(table.equals("stock_cancelled_inbound") || table.equals("stock_doc_revisions")
                    || table.equals("operation_logs") || table.equals("product_categories")) && !tables.has(table)
                    ? new JSONArray() : tables.getJSONArray(table);
            if(rows.length()>150_000)throw new IllegalArgumentException("备份记录数量异常");
            List<Column> cols=columns(db,table);Set<String> expected=new HashSet<>();
            for(Column col:cols)expected.add(col.name);
            for(int i=0;i<rows.length();i++){
                JSONObject item=rows.getJSONObject(i);
                java.util.Iterator<String> keys=item.keys();
                while(keys.hasNext())if(!expected.contains(keys.next()))
                    throw new IllegalArgumentException("备份字段错误："+table);
                for(Column col:cols)if(!item.has(col.name) &&
                        !(table.equals("stock_documents") && (col.name.equals("voided") || col.name.equals("source_document_id"))) &&
                        !(table.equals("products") && col.name.equals("category")))
                    throw new IllegalArgumentException("备份字段缺失："+col.name);
                if(table.equals("product_images")){
                    String photo=item.getString("jpeg");
                    if(!photo.startsWith("base64:")||photo.length()>1_700_000)
                        throw new IllegalArgumentException("商品照片数据有误");
                    ProductDatabase.requirePhoto(Base64.decode(photo.substring(7),Base64.DEFAULT));
                }
            }
        }
    }
    private void read(Uri uri){
        try{
            ByteArrayOutputStream buffer=new ByteArrayOutputStream();
            try(InputStream input=getContentResolver().openInputStream(uri)){
                if(input==null)throw new IllegalArgumentException("文件无法读取");
                byte[] block=new byte[16384];int n;
                while((n=input.read(block))!=-1){if(buffer.size()+n>LIMIT)
                        throw new IllegalArgumentException("备份文件超过120MB");buffer.write(block,0,n);}
            }
            JSONObject data=new JSONObject(new String(buffer.toByteArray(),StandardCharsets.UTF_8));
            validate(data);
            new AlertDialog.Builder(this).setTitle("确认恢复全部门市数据？")
                    .setMessage("该操作会替换当前手机上的商品、分类、照片、库存、销售、内部领用、入库和盘点记录。\n\n请确认已保留当前数据备份。")
                    .setNegativeButton("取消",null)
                    .setPositiveButton("确认恢复",(d,w)->restore(data)).show();
        }catch(Exception e){new AlertDialog.Builder(this).setTitle("备份文件无效")
                .setMessage(e.getMessage()==null?"文件读取或校验失败，本机数据未修改":e.getMessage())
                .setPositiveButton("确定",null).show();}
    }
    private void restore(JSONObject backup){
        SQLiteDatabase db=helper.getWritableDatabase();
        try{
            JSONObject content=backup.getJSONObject("tables");
            db.beginTransaction();
            try{
                // 子表先清空，父表后清空；恢复顺序相反，事务失败会完整回滚。
                for(int i=TABLES.length-1;i>=0;i--)
                    if(!"operation_logs".equals(TABLES[i]))db.delete(TABLES[i],null,null);
                for(String table:TABLES){
                    List<Column> cols=columns(db,table);
                    JSONArray rows=(table.equals("stock_cancelled_inbound") || table.equals("stock_doc_revisions")
                            || table.equals("operation_logs") || table.equals("product_categories")) && !content.has(table)
                            ? new JSONArray() : content.getJSONArray(table);
                    for(int i=0;i<rows.length();i++){
                        JSONObject obj=rows.getJSONObject(i);ContentValues values=new ContentValues();
                        for(Column col:cols){
                            Object raw=obj.has(col.name)?obj.get(col.name):
                                    ("category".equals(col.name)?"":0);
                            if(raw==JSONObject.NULL){values.putNull(col.name);continue;}
                            if(raw instanceof Number){
                                if(col.type.toUpperCase(Locale.ROOT).contains("REAL"))values.put(col.name,((Number)raw).doubleValue());
                                else values.put(col.name,((Number)raw).longValue());
                            }else if("jpeg".equals(col.name)&&"product_images".equals(table)){
                                values.put(col.name,Base64.decode(raw.toString().substring(7),Base64.DEFAULT));
                            }else values.put(col.name,raw.toString());
                        }
                        if("operation_logs".equals(table)){
                            // Retain local logs; restored records get local IDs, UUID removes duplicates.
                            values.remove("id");
                            db.insertWithOnConflict(table,null,values,SQLiteDatabase.CONFLICT_IGNORE);
                        }else db.insertOrThrow(table,null,values);
                    }
                }
                ProductCategories.reconcile(db);
                // 校验引用关系和库存不为负数，错误时回滚全部恢复操作。
                try(Cursor c=db.rawQuery("PRAGMA foreign_key_check",null)){
                    if(c.moveToFirst())throw new IllegalArgumentException("备份中的单据关系不完整");
                }
                InventoryStore fresh=new InventoryStore(helper);
                for(InventoryStore.StockRow row:fresh.stocks())if(row.current<0)
                    throw new IllegalArgumentException("备份出现负库存，恢复已取消");
                AuditTrail.write(db,"恢复数据","完整门市备份",
                        "已恢复商品、照片、库存、业务单据，旧日志与备份日志合并保留");
                db.setTransactionSuccessful();
            }finally{db.endTransaction();}
            new AlertDialog.Builder(this).setTitle("恢复成功")
                    .setMessage("商品、分类、照片、库存和全部业务流水均已恢复。")
                    .setPositiveButton("确定",(d,w)->finish()).show();
        }catch(Exception e){AuditTrail.failure(this,"恢复失败","完整门市备份",e.getMessage());
            new AlertDialog.Builder(this).setTitle("恢复失败")
                .setMessage("本机原有数据已保留。"+(e.getMessage()==null?"":"\n原因："+e.getMessage()))
                .setPositiveButton("确定",null).show();}
    }
    @Override protected void onDestroy(){if(helper!=null)helper.close();super.onDestroy();}
}
