package com.localpricescan.app;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

/** User-managed product categories, with legacy product names preserved. */
final class ProductCategories {
    private ProductCategories() {}
    static void createSchema(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS product_categories (name TEXT PRIMARY KEY NOT NULL, position INTEGER NOT NULL)");
    }
    static String requireName(String input) {
        String name=input==null?"":input.trim();
        if(name.isEmpty())throw new IllegalArgumentException("请输入分类名称");
        if("全部".equals(name)||"未分类".equals(name)||"不分类".equals(name))throw new IllegalArgumentException("该名称为系统显示用语，请换一个名称");
        return name;
    }
    static List<String> list(SQLiteDatabase db) {
        List<String> names=new ArrayList<>();
        try(Cursor c=db.rawQuery("SELECT name FROM product_categories ORDER BY position ASC,name ASC",null)){
            while(c.moveToNext())names.add(c.getString(0));
        }
        return names;
    }
    static boolean exists(SQLiteDatabase db,String name) {
        try(Cursor c=db.rawQuery("SELECT 1 FROM product_categories WHERE name=?",new String[]{name})){return c.moveToFirst();}
    }
    static int count(SQLiteDatabase db,String name) {
        try(Cursor c=db.rawQuery("SELECT count(*) FROM products WHERE category=?",new String[]{name})){return c.moveToFirst()?c.getInt(0):0;}
    }
    private static void insert(SQLiteDatabase db,String name) {
        db.execSQL("INSERT INTO product_categories(name,position) SELECT ?,coalesce(max(position),-1)+1 FROM product_categories",new Object[]{name});
    }
    // Called inside the product transaction; a typed new category is committed only with the product.
    static void ensure(SQLiteDatabase db,String name) {
        if(name==null||name.isEmpty()||exists(db,name))return;
        insert(db,requireName(name));
        AuditTrail.write(db,"新增商品分类",name,"录入商品时创建分类","",name,"成功");
    }
    // Upgrade and legacy backup: only seed categories actually attached to products.
    static void reconcile(SQLiteDatabase db) {
        List<String> names=new ArrayList<>();
        try(Cursor c=db.rawQuery("SELECT DISTINCT category FROM products WHERE trim(category)<>'' ORDER BY category",null)){
            while(c.moveToNext())names.add(c.getString(0));
        }
        for(String name:names){
            if(!name.equals(requireName(name)))throw new IllegalArgumentException("商品分类名称格式不正确");
            if(!exists(db,name))insert(db,name);
        }
        for(String name:list(db))if(!name.equals(requireName(name)))throw new IllegalArgumentException("分类名称格式不正确");
    }
    static void add(SQLiteDatabase db,String input) {
        String name=requireName(input);
        db.beginTransaction();try{
            if(exists(db,name))throw new IllegalArgumentException("分类已存在");
            insert(db,name);
            AuditTrail.write(db,"新增商品分类",name,"创建分类","",name,"成功");
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    static void rename(SQLiteDatabase db,String old,String input) {
        String name=requireName(input);if(old.equals(name))return;
        db.beginTransaction();try{
            if(!exists(db,old))throw new IllegalArgumentException("原分类不存在");
            if(exists(db,name))throw new IllegalArgumentException("分类已存在");
            ContentValues v=new ContentValues();v.put("name",name);
            db.update("product_categories",v,"name=?",new String[]{old});
            v.clear();v.put("category",name);
            int n=db.update("products",v,"category=?",new String[]{old});
            AuditTrail.write(db,"修改商品分类",old,"同步更新 "+n+" 件商品分类",old,name,"成功");
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    static void delete(SQLiteDatabase db,String name) {
        db.beginTransaction();try{
            if(count(db,name)>0)throw new IllegalArgumentException("该分类下仍有商品，请先编辑商品并转移分类");
            if(db.delete("product_categories","name=?",new String[]{name})!=1)throw new IllegalArgumentException("分类不存在");
            AuditTrail.write(db,"删除商品分类",name,"仅删除空分类",name,"","成功");
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    static void move(SQLiteDatabase db,String name,int direction) {
        db.beginTransaction();try{
            List<String> names=list(db);int at=names.indexOf(name),to=at+direction;
            if(at<0||to<0||to>=names.size())return;
            String before=names.toString();java.util.Collections.swap(names,at,to);
            for(int i=0;i<names.size();i++){
                ContentValues v=new ContentValues();v.put("position",i);
                db.update("product_categories",v,"name=?",new String[]{names.get(i)});
            }
            AuditTrail.write(db,"调整商品分类顺序",name,"修改显示顺序",before,names.toString(),"成功");
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
}
