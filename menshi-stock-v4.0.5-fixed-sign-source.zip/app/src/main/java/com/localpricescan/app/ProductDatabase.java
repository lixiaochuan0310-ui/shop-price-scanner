package com.localpricescan.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/** 原商品及库存数据保留，数据库升级新增可自定义分类。 */
final class ProductDatabase extends SQLiteOpenHelper {
    static final String DATABASE = "offline_products.db";
    private static final int VERSION = 8;
    static final int MAX_PHOTO_BYTES = 1_200_000;

    ProductDatabase(Context context) { super(context, DATABASE, null, VERSION); }

    @Override public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE products (barcode TEXT PRIMARY KEY NOT NULL, " +
                "name TEXT NOT NULL, purchase_cents INTEGER NOT NULL CHECK(purchase_cents >= 0), " +
                "sale_cents INTEGER NOT NULL CHECK(sale_cents >= 0), "+
                "category TEXT NOT NULL DEFAULT '')");
        ProductCategories.createSchema(db);
        createImages(db);
        InventoryStore.createSchema(db);
        AuditTrail.createSchema(db);
    }

    private void createImages(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS product_images (barcode TEXT PRIMARY KEY NOT NULL, " +
                "jpeg BLOB NOT NULL, FOREIGN KEY(barcode) REFERENCES products(barcode) ON DELETE CASCADE)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) createImages(db);
        if (oldVersion < 3) InventoryStore.createSchema(db);
        if (oldVersion < 4) InventoryStore.createCancellationSchema(db);
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE stock_documents ADD COLUMN voided INTEGER NOT NULL DEFAULT 0");
            db.execSQL("ALTER TABLE stock_documents ADD COLUMN source_document_id INTEGER NOT NULL DEFAULT 0");
            InventoryStore.createRevisionSchema(db);
        }
        if (oldVersion < 6) AuditTrail.createSchema(db);
        if (oldVersion < 7) db.execSQL("ALTER TABLE products ADD COLUMN category TEXT NOT NULL DEFAULT ''");
        if (oldVersion < 8) {
            ProductCategories.createSchema(db);
            ProductCategories.reconcile(db);
        }
    }

    Product get(String barcode) {
        if (barcode == null || barcode.isEmpty()) return null;
        Product found = getExact(barcode);
        if (found != null) return found;
        String normalized = BarcodeKey.scanned(barcode);
        if (!normalized.equals(barcode)) {
            found = getExact(normalized);
            if (found != null) return found;
        }
        String alternative = BarcodeKey.equivalentUpcEan(normalized);
        return alternative == null ? null : getExact(alternative);
    }

    private Product getExact(String barcode) {
        try (Cursor cursor = getReadableDatabase().query("products",
                new String[]{"barcode", "name", "purchase_cents", "sale_cents", "category"},
                "barcode = ?", new String[]{barcode}, null, null, null)) {
            if (!cursor.moveToFirst()) return null;
            return new Product(cursor.getString(0), cursor.getString(1),
                    cursor.getLong(2), cursor.getLong(3), cursor.getString(4));
        }
    }

    List<Product> all() {
        List<Product> out = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query("products",
                new String[]{"barcode", "name", "purchase_cents", "sale_cents", "category"},
                null, null, null, null, "name COLLATE NOCASE ASC, barcode ASC")) {
            while (cursor.moveToNext()) {
                out.add(new Product(cursor.getString(0), cursor.getString(1),
                        cursor.getLong(2), cursor.getLong(3), cursor.getString(4)));
            }
        }
        return out;
    }

    int count() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT count(*) FROM products", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    byte[] photo(String barcode) {
        try (Cursor c = getReadableDatabase().query("product_images", new String[]{"jpeg"},
                "barcode = ?", new String[]{barcode}, null, null, null)) {
            return c.moveToFirst() ? c.getBlob(0) : null;
        }
    }

    private static ContentValues values(Product p) {
        ContentValues v = new ContentValues();
        v.put("barcode", p.barcode);
        v.put("name", p.name);
        v.put("purchase_cents", p.purchaseCents);
        v.put("sale_cents", p.saleCents);
        v.put("category", p.category);
        return v;
    }

    private static void photoInTransaction(SQLiteDatabase db, String barcode, byte[] photo) {
        db.delete("product_images", "barcode = ?", new String[]{barcode});
        if (photo != null) {
            requirePhoto(photo);
            ContentValues v = new ContentValues();
            v.put("barcode", barcode);
            v.put("jpeg", photo);
            db.insertOrThrow("product_images", null, v);
        }
    }

    static void requirePhoto(byte[] jpeg) {
        if (jpeg != null && (jpeg.length < 4 || jpeg.length > MAX_PHOTO_BYTES ||
                (jpeg[0] & 255) != 255 || (jpeg[1] & 255) != 216 ||
                (jpeg[jpeg.length - 2] & 255) != 255 || (jpeg[jpeg.length - 1] & 255) != 217)) {
            throw new IllegalArgumentException("商品照片无效或过大");
        }
    }

    private static String snapshot(Product p,boolean hasPhoto){
        org.json.JSONObject data=new org.json.JSONObject();
        try{
            data.put("barcode",p.barcode);data.put("name",p.name);data.put("category",p.category);
            data.put("purchase_cents",p.purchaseCents);data.put("sale_cents",p.saleCents);
            data.put("has_photo",hasPhoto);
        }catch(org.json.JSONException e){throw new IllegalStateException(e);}
        return data.toString();
    }

    void insert(Product product, byte[] photo) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ProductCategories.ensure(db,product.category);
            db.insertOrThrow("products", null, values(product));
            photoInTransaction(db, product.barcode, photo);
            AuditTrail.write(db,"新增商品",product.name+" / "+product.barcode,
                    "已录入商品及价格、分类、照片", "",snapshot(product,photo!=null),"成功");
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    boolean update(Product product, byte[] photo) {
        Product previous=getExact(product.barcode);
        String before=previous==null?"":snapshot(previous,photo(product.barcode)!=null);
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            ProductCategories.ensure(db,product.category);
            if (db.update("products", values(product), "barcode = ?",
                    new String[]{product.barcode}) != 1) return false;
            photoInTransaction(db, product.barcode, photo);
            AuditTrail.write(db,"编辑商品",product.name+" / "+product.barcode,
                    "已更新商品名称、价格、分类或照片",before,snapshot(product,photo!=null),"成功");
            db.setTransactionSuccessful();
            return true;
        } finally { db.endTransaction(); }
    }

    /** Delete product and its linked stock operations transactionally; log exact removed rows.
     * Other products in mixed documents are preserved, and paid amount is adjusted proportionally.
     */
    boolean delete(String barcode) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            Product p=get(barcode);
            if(p==null)return false;
            org.json.JSONObject history=new org.json.JSONObject();
            try{
                history.put("barcode",p.barcode);history.put("name",p.name);
                history.put("purchase_cents",p.purchaseCents);history.put("sale_cents",p.saleCents);
                history.put("photo_removed",photo(barcode)!=null);
            }catch(org.json.JSONException e){throw new IllegalStateException(e);}
            org.json.JSONArray removedLines=new org.json.JSONArray();
            java.util.Set<Long> docs=new java.util.HashSet<>();
            try(Cursor c=db.rawQuery("SELECT document_id,id,product_name,base_qty_milli,amount_cents " +
                    "FROM stock_lines WHERE barcode=?",new String[]{barcode})){
                while(c.moveToNext()){
                    docs.add(c.getLong(0));
                    org.json.JSONObject row=new org.json.JSONObject();
                    try{row.put("document_id",c.getLong(0));row.put("line_id",c.getLong(1));
                        row.put("name",c.getString(2));row.put("qty_milli",c.getLong(3));
                        row.put("amount_cents",c.getLong(4));}catch(org.json.JSONException e){throw new IllegalStateException(e);}
                    removedLines.put(row);
                }
            }
            org.json.JSONArray removedCounts=new org.json.JSONArray();
            try(Cursor c=db.rawQuery("SELECT id,business_date,before_milli,actual_milli,delta_milli,note " +
                    "FROM stock_counts WHERE barcode=?",new String[]{barcode})){
                while(c.moveToNext()){
                    org.json.JSONObject row=new org.json.JSONObject();
                    try{row.put("id",c.getLong(0));row.put("date",c.getString(1));
                        row.put("before_milli",c.getLong(2));row.put("actual_milli",c.getLong(3));
                        row.put("delta_milli",c.getLong(4));row.put("note",c.getString(5));}
                    catch(org.json.JSONException e){throw new IllegalStateException(e);}removedCounts.put(row);
                }
            }
            try {history.put("removed_lines",removedLines);history.put("removed_counts",removedCounts);}
            catch(org.json.JSONException e){throw new IllegalStateException(e);}
            // Remove only this product's lines; keep unrelated lines in the same document.
            db.delete("stock_lines","barcode=?",new String[]{barcode});
            db.delete("stock_counts","barcode=?",new String[]{barcode});
            for(Long docId:docs){
                String arg=Long.toString(docId);
                long remaining=0,total=0,oldTotal=0,oldPaid=0;
                try(Cursor c=db.rawQuery("SELECT COUNT(*),COALESCE(SUM(amount_cents),0) FROM stock_lines WHERE document_id=?",
                        new String[]{arg})){if(c.moveToFirst()){remaining=c.getLong(0);total=c.getLong(1);}}
                try(Cursor c=db.rawQuery("SELECT total_cents,paid_cents FROM stock_documents WHERE id=?",new String[]{arg})){
                    if(c.moveToFirst()){oldTotal=c.getLong(0);oldPaid=c.getLong(1);}
                }
                if(remaining==0){
                    // Returns for this product already had their line removed; no valid return is left.
                    db.delete("stock_documents","id=?",new String[]{arg});
                }else{
                    ContentValues update=new ContentValues();update.put("total_cents",total);
                    long newPaid=oldTotal<=0?0:java.math.BigDecimal.valueOf(oldPaid)
                            .multiply(java.math.BigDecimal.valueOf(total))
                            .divide(java.math.BigDecimal.valueOf(oldTotal),0,java.math.RoundingMode.HALF_UP).longValueExact();
                    update.put("paid_cents",newPaid);
                    db.update("stock_documents",update,"id=?",new String[]{arg});
                }
            }
            db.delete("product_images","barcode=?",new String[]{barcode});
            db.delete("stock_settings","barcode=?",new String[]{barcode});
            if(db.delete("products","barcode=?",new String[]{barcode})!=1)
                throw new IllegalStateException("删除商品失败，数据未修改");
            AuditTrail.write(db,"删除商品",p.name+" / "+barcode,
                    "同时删除该商品的库存、入库、销售、领用、盘点关联数据；其它商品保留",
                    history.toString(),"","成功");
            db.setTransactionSuccessful();return true;
        }finally {db.endTransaction();}
    }

    /** 全部校验后，以单个事务替换商品和照片，失败则原数据及照片全部回滚。 */
    void replaceAll(List<Record> records) {
        HashSet<String> keys = new HashSet<>();
        for (Record record : records) {
            Product p = record.product;
            if (p.barcode.isEmpty() || p.barcode.length() > 200 || p.name.trim().isEmpty() ||
                    p.name.length() > 500 || p.purchaseCents < 0 || p.saleCents < 0 ||
                    !keys.add(p.barcode)) throw new IllegalArgumentException("无效的商品备份数据");
            requirePhoto(record.photo);
        }
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("product_images", null, null);
            db.delete("products", null, null);
            for (Record r : records) {
                ProductCategories.ensure(db,r.product.category);
                db.insertOrThrow("products", null, values(r.product));
                if (r.photo != null) photoInTransaction(db, r.product.barcode, r.photo);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    static final class Product {
        final String barcode, name, category;
        final long purchaseCents, saleCents;
        Product(String barcode,String name,long purchaseCents,long saleCents){
            this(barcode,name,purchaseCents,saleCents,"");
        }
        Product(String barcode,String name,long purchaseCents,long saleCents,String category){
            this.barcode=barcode;this.name=name;this.purchaseCents=purchaseCents;this.saleCents=saleCents;
            this.category=category==null?"":category.trim();
        }
    }

    static final class Record {
        final Product product;
        final byte[] photo;
        Record(Product product, byte[] photo) { this.product=product; this.photo=photo; }
    }
}
