package com.localpricescan.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

/** 概念图首页：真实库存统计、固定比例立体八宫格、三个辅助入口。 */
public final class MainActivity extends Activity {
    private static final int NEW_ITEM=311;
    private ProductDatabase db;
    private TextView productCount,stockQuantity,stockValue;
    private String pendingBarcode;
    private boolean scanning;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);AppUi.apply(this);db=new ProductDatabase(this);
        getWindow().setBackgroundDrawableResource(R.drawable.bg_app_surface);
        float density=getResources().getDisplayMetrics().density;
        int widthDp=getResources().getConfiguration().screenWidthDp;
        int heightDp=getResources().getConfiguration().screenHeightDp;
        if(widthDp<=0)widthDp=(int)(getResources().getDisplayMetrics().widthPixels/density);
        if(heightDp<=0)heightDp=(int)(getResources().getDisplayMetrics().heightPixels/density);
        final HomeLayout layout=new HomeLayout(widthDp,heightDp);
        int margin=layout.margin, gap=layout.columnGap;
        int tileHeight=layout.tileHeight;
        LinearLayout root=StoreUi.column(this);root.setBackground(new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xffd7f5f1,0xffd2f3ee}));
        root.setClipChildren(false);root.setClipToPadding(false);setContentView(root);
        LinearLayout header=StoreUi.row(this);header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(widthDp*.048f),0,dp(widthDp*.036f),dp(layout.headerHeight*.10f));header.setBackgroundResource(R.drawable.home_header_art);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.home_brand_concept);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setContentDescription("门市进销存品牌标志");
        LinearLayout.LayoutParams logoLp=StoreUi.lp(dp(layout.logoSize),dp(layout.logoSize));logoLp.rightMargin=dp(widthDp*.034f);header.addView(logo,logoLp);
        LinearLayout nameGroup=StoreUi.column(this);
        LinearLayout titleRow=StoreUi.row(this);
        TextView brand=StoreUi.text(this,"门市进销存",widthDp<350?18:22,true);brand.setTextColor(0xffffffff);brand.setSingleLine(true);
        titleRow.addView(brand);TextView version=StoreUi.text(this,"",widthDp<350?9:11,true);version.setTextColor(0xfff0ffff);
        try{version.setText("V"+getPackageManager().getPackageInfo(getPackageName(),0).versionName);}catch(PackageManager.NameNotFoundException ignored){}
        LinearLayout.LayoutParams verLp=StoreUi.lp(-2,-2);verLp.leftMargin=dp(5);titleRow.addView(version,verLp);nameGroup.addView(titleRow);
        TextView sub=StoreUi.text(this,"商品 · 入库 · 销售 · 库存 · 报表",widthDp<350?9:11,false);sub.setTextColor(0xfff0fffa);sub.setSingleLine(true);nameGroup.addView(sub);
        header.addView(nameGroup,new LinearLayout.LayoutParams(0,-2,1));
        android.widget.ImageButton settings=new android.widget.ImageButton(this);settings.setImageResource(R.drawable.ic_home_gear);
        android.graphics.drawable.GradientDrawable gearMask=StoreUi.round(0xffffffff,18,this);
        settings.setBackground(new android.graphics.drawable.RippleDrawable(android.content.res.ColorStateList.valueOf(0x45ffffff),null,gearMask));settings.setScaleType(ImageView.ScaleType.CENTER_INSIDE);settings.setPadding(dp(5),dp(5),dp(5),dp(5));
        settings.setContentDescription("设置");header.addView(settings,StoreUi.lp(dp(36),dp(44)));settings.setOnClickListener(v->{
            android.widget.PopupMenu menu=new android.widget.PopupMenu(this,settings);
            menu.getMenu().add(0,1,0,"操作日志");menu.getMenu().add(0,2,1,"备份恢复");menu.getMenu().add(0,3,2,"商品分类管理");
            menu.setOnMenuItemClickListener(item->{if(item.getItemId()==1){AuditTrail.record(this,"功能入口","操作日志","首页设置");activity(StoreAuditActivity.class,null);return true;}if(item.getItemId()==2){AuditTrail.record(this,"功能入口","备份恢复","首页设置");activity(StoreBackupActivity.class,null);return true;}if(item.getItemId()==3){AuditTrail.record(this,"功能入口","商品分类管理","首页设置");activity(ProductCategoriesActivity.class,null);return true;}return false;});menu.show();
        });
        root.addView(header,StoreUi.lp(-1,dp(layout.headerHeight)));
        LinearLayout body=StoreUi.column(this);body.setPadding(dp(margin),dp(layout.topGap),dp(margin),0);body.setClipChildren(false);body.setClipToPadding(false);
        root.addView(body,StoreUi.lp(-1,-2));
        LinearLayout stats=StoreUi.row(this);stats.setClipChildren(false);stats.setClipToPadding(false);
        productCount=stat(stats,"商品总数",R.drawable.home_stat_products,layout,widthDp,false);
        stockQuantity=stat(stats,"库存总量",R.drawable.home_stat_quantity,layout,widthDp,false);
        stockValue=stat(stats,"库存金额",R.drawable.home_stat_value,layout,widthDp,true);
        body.addView(stats,StoreUi.lp(-1,dp(layout.statsHeight)));
        StoreUi.gap(body,layout.statsGap);

        LinearLayout gridCard=StoreUi.column(this);gridCard.setClipChildren(false);gridCard.setClipToPadding(false);
        gridCard.setPadding(dp(layout.gridPadding),dp(layout.gridPadding),dp(layout.gridPadding),dp(layout.gridPadding));gridCard.setBackground(StoreUi.round(0x60ffffff,22,this));
        body.addView(gridCard,StoreUi.lp(-1,-2));
        String[] names={"扫码查价","商品管理","商品入库","商品销售","内部领用","库存查询","统计报表","业务流水"};
        int[] icons={R.drawable.home_tile_scan,R.drawable.home_tile_layers,R.drawable.home_tile_in,R.drawable.home_tile_sale,
                R.drawable.home_tile_person,R.drawable.home_tile_stock,R.drawable.home_tile_reports,R.drawable.home_tile_records};
        for(int rowIndex=0;rowIndex<2;rowIndex++){
            LinearLayout tileRow=StoreUi.row(this);tileRow.setClipChildren(false);tileRow.setClipToPadding(false);
            if(rowIndex>0)StoreUi.gap(gridCard,layout.rowGap);
            gridCard.addView(tileRow,StoreUi.lp(-1,dp(tileHeight)));
            for(int col=0;col<4;col++){
                final int index=rowIndex*4+col;
                HomeArt.PressCard tile=new HomeArt.PressCard(this,0xfff0ffff,0xffcceee8,18);
                tile.setBackground(HomeArt.skin(this,icons[index],.68f,18));
                tile.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
                tile.setPadding(dp(3),0,dp(3),dp(tileHeight*.13f));
                TextView label=StoreUi.text(this,names[index],widthDp<350?13:15,true);label.setTextColor(0xff102f38);label.setGravity(Gravity.CENTER);
                label.setSingleLine(true);label.setHorizontallyScrolling(false);label.setIncludeFontPadding(false);
                androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(label,8,widthDp<350?13:15,1,android.util.TypedValue.COMPLEX_UNIT_SP);
                tile.addView(label,StoreUi.lp(-1,dp(layout.labelHeight)));
                LinearLayout.LayoutParams tileLp=new LinearLayout.LayoutParams(0,-1,1);
                if(col<3)tileLp.rightMargin=dp(gap);
                tileRow.addView(tile,tileLp);tile.setContentDescription(names[index]);tile.setOnClickListener(v->open(index));
            }
        }
        StoreUi.gap(body,layout.footerGap);
        LinearLayout foot=StoreUi.row(this);foot.setClipChildren(false);foot.setClipToPadding(false);
        footer(foot,"其他出库",R.drawable.home_foot_truck,layout,false,v->activity(StoreDocumentActivity.class,"OTHER"));
        footer(foot,"库存盘点",R.drawable.home_foot_count,layout,false,v->activity(StoreCountActivity.class,null));
        footer(foot,"备份恢复",R.drawable.home_foot_database,layout,true,v->activity(StoreBackupActivity.class,null));
        body.addView(foot,StoreUi.lp(-1,dp(layout.footerHeight)));
        // Only decorative waves fill the remaining window; no placeholder or demo content.
        ImageView waves=new ImageView(this);waves.setImageResource(R.drawable.home_wave_bottom);
        waves.setScaleType(ImageView.ScaleType.FIT_XY);waves.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        LinearLayout.LayoutParams waveLp=new LinearLayout.LayoutParams(-1,0,1);waveLp.topMargin=dp(5);
        root.addView(waves,waveLp);
        if(state!=null)pendingBarcode=state.getString("pendingBarcode");
    }
    private int dp(float n){return StoreUi.d(this,n);}
    private TextView stat(LinearLayout row,String caption,int res,HomeLayout layout,int widthDp,boolean last){
        LinearLayout card=StoreUi.column(this);
        card.setGravity(Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        card.setPadding(dp(4),0,dp(4),dp(layout.statsHeight*.092f));
        card.setBackground(HomeArt.skin(this,res,.55f,20));card.setElevation(dp(4));
        TextView title=StoreUi.text(this,caption,widthDp<350?12:13,true);title.setTextColor(0xffffffff);
        title.setGravity(Gravity.CENTER);title.setSingleLine(true);title.setHorizontallyScrolling(false);title.setIncludeFontPadding(false);
        title.setShadowLayer(dp(1.2f),0,dp(1),0x66305e50);
        androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(title,8,widthDp<350?12:13,1,android.util.TypedValue.COMPLEX_UNIT_SP);
        card.addView(title,StoreUi.lp(-1,dp(layout.statsHeight*.14f)));
        TextView value=StoreUi.text(this,"—",widthDp<350?22:26,true);value.setTextColor(0xffffffff);value.setGravity(Gravity.CENTER);value.setSingleLine(true);value.setHorizontallyScrolling(false);value.setIncludeFontPadding(false);
        value.setShadowLayer(dp(1.5f),0,dp(1),0x66305e50);
        androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(value,8,widthDp<350?22:26,1,android.util.TypedValue.COMPLEX_UNIT_SP);
        card.addView(value,StoreUi.lp(-1,dp(layout.statsHeight*.24f)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);if(!last)p.rightMargin=dp(layout.columnGap);row.addView(card,p);
        return value;
    }
    private void footer(LinearLayout row,String label,int res,HomeLayout layout,boolean last,View.OnClickListener listener){
        HomeArt.PressCard b=new HomeArt.PressCard(this,0xfffcffff,0xffe5f1ef,16);
        b.setBackground(HomeArt.skin(this,res,0f,16));b.setGravity(Gravity.CENTER);
        int widthDp=getResources().getConfiguration().screenWidthDp;
        int buttonWidth=(widthDp-2*layout.margin-2*layout.columnGap)/3;
        b.setPadding(dp(buttonWidth*.41f),0,dp(buttonWidth*.05f),dp(3));
        TextView text=StoreUi.text(this,label,widthDp<350?12:14,true);text.setTextColor(0xff102f38);text.setSingleLine(true);text.setHorizontallyScrolling(false);text.setGravity(Gravity.CENTER);text.setIncludeFontPadding(false);
        androidx.core.widget.TextViewCompat.setAutoSizeTextTypeUniformWithConfiguration(text,8,widthDp<350?12:14,1,android.util.TypedValue.COMPLEX_UNIT_SP);
        b.addView(text,StoreUi.lp(-1,-1));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);if(!last)p.rightMargin=dp(layout.columnGap);
        row.addView(b,p);b.setContentDescription(label);b.setOnClickListener(v->{AuditTrail.record(this,"功能入口",label,"首页底部");listener.onClick(v);});
    }
    private void activity(Class<?> screen,String kind){Intent i=new Intent(this,screen);if(kind!=null)i.putExtra("kind",kind);BackPreview.capture(this);startActivity(i);}
    private void open(int index){
        AuditTrail.record(this,"功能入口",new String[]{"扫码查价","商品管理","商品入库","商品销售",
                "内部领用","库存查询","统计报表","业务流水"}[index],"首页八宫格");
        switch(index){
            case 0:startScanner();break;
            case 1:activity(ProductListActivity.class,null);break;
            case 2:activity(StoreDocumentActivity.class,"IN");break;
            case 3:activity(StoreDocumentActivity.class,"SALE");break;
            case 4:activity(StoreDocumentActivity.class,"ISSUE");break;
            case 5:activity(StoreStockActivity.class,null);break;
            case 6:activity(StoreReportsActivity.class,null);break;
            case 7:activity(StoreRecordsActivity.class,null);break;
        }
    }
    @Override protected void onResume(){
        super.onResume();scanning=false;
        try{AuditTrail.record(this,"打开页面","首页","查看门市数据概览");}catch(Exception ignored){}
        if(db!=null && productCount!=null){
            try{
                int n=db.count();long totalQty=0;
                java.math.BigDecimal stockCents=java.math.BigDecimal.ZERO;
                for(InventoryStore.StockRow row:new InventoryStore(db).stocks()){
                    if(row.current<=0)continue;
                    totalQty=Math.addExact(totalQty,row.current);
                    ProductDatabase.Product p=db.get(row.barcode);
                    if(p!=null)stockCents=stockCents.add(java.math.BigDecimal.valueOf(p.purchaseCents)
                            .multiply(java.math.BigDecimal.valueOf(row.current))
                            .divide(java.math.BigDecimal.valueOf(1000),0,java.math.RoundingMode.HALF_UP));
                }
                productCount.setText(n+"种");stockQuantity.setText(InventoryStore.qty(totalQty));
                stockValue.setText(Money.show(stockCents.longValueExact()));
            }catch(Exception e){productCount.setText("—");stockQuantity.setText("—");stockValue.setText("—");}
        }
    }
    private void startScanner(){
        if(scanning)return;scanning=true;IntentIntegrator i=new IntentIntegrator(this);
        i.setCaptureActivity(PortraitCaptureActivity.class);i.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES);
        i.setPrompt("将商品条形码放入扫描框");i.setBeepEnabled(false);i.setOrientationLocked(true);
        try{i.initiateScan();}catch(RuntimeException e){scanning=false;Toast.makeText(this,"扫码无法启动，请检查相机权限",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        if(request==NEW_ITEM){super.onActivityResult(request,result,data);String code=pendingBarcode;pendingBarcode=null;
            if(result==RESULT_OK&&code!=null&&db.get(code)!=null)detail(code);return;}
        IntentResult scan=IntentIntegrator.parseActivityResult(request,result,data);
        if(scan==null){super.onActivityResult(request,result,data);return;}scanning=false;
        String code=BarcodeKey.scanned(scan.getContents());if(code.isEmpty())return;
        AuditTrail.record(this,"扫码查价",code,"已扫描条形码并查询本地商品库");
        try{ProductDatabase.Product p=db.get(code);
            if(p!=null){Toast.makeText(this,"该商品已登记，正在显示已有商品",Toast.LENGTH_SHORT).show();detail(p.barcode);}
            else{pendingBarcode=code;Intent i=new Intent(this,ProductEditorActivity.class);i.putExtra("barcode",code);startActivityForResult(i,NEW_ITEM);}
        }catch(SQLiteException e){Toast.makeText(this,"商品查询失败",Toast.LENGTH_LONG).show();}
    }
    private void detail(String code){Intent i=new Intent(this,ProductDetailActivity.class);i.putExtra("barcode",code);
        i.putExtra("scanResult",true);BackPreview.capture(this);startActivity(i);}
    @Override protected void onSaveInstanceState(Bundle state){super.onSaveInstanceState(state);state.putString("pendingBarcode",pendingBarcode);}
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
