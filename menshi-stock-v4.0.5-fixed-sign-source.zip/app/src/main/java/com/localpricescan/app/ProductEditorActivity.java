package com.localpricescan.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteConstraintException;
import android.database.sqlite.SQLiteException;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Arrays;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/** 首次新增和修改共用编辑页，商品照片可拍照、选相册、删除或留空。 */
public final class ProductEditorActivity extends SwipeBackActivity {
    private static final int CAPTURE = 410, CHOOSE = 411, CAMERA_PERMISSION = 412, ONLINE_PHOTO = 413;
    private ProductDatabase db;
    private String barcode;
    private boolean editing;
    private Uri captureUri;
    private byte[] imageBytes;
    private EditText nameInput, purchaseInput, saleInput;
    private EditText categoryInput;
    private ImageView imagePreview;
    private TextView noPhoto;
    private String initialName = "", initialPurchase = "", initialSale = "", initialCategory="";
    private byte[] initialPhoto;
    private boolean photoChanged;
    private boolean saving, saved;
    private String draftImageFile;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        AppUi.apply(this);
        setContentView(R.layout.activity_product_editor);
        db = new ProductDatabase(this);
        barcode = getIntent().getStringExtra("barcode");
        editing = getIntent().getBooleanExtra("edit",false);
        if (barcode == null || barcode.trim().isEmpty()) { finish(); return; }
        if (state != null) {
            String uri = state.getString("captureUri");
            if (uri != null) captureUri = Uri.parse(uri);
        }
        ((TextView) findViewById(R.id.editorTitle)).setText(editing ? "编辑商品" : "录入新商品");
        ((TextView) findViewById(R.id.editorBarcode)).setText("条形码  " + barcode);
        nameInput = findViewById(R.id.editorName);
        categoryInput=StoreUi.input(this,"输入分类名称（可留空）","",android.text.InputType.TYPE_CLASS_TEXT);
        android.view.ViewGroup group=(android.view.ViewGroup)nameInput.getParent();
        int insertAt=group.indexOfChild(nameInput)+1;
        TextView categoryTitle=StoreUi.text(this,"商品分类",14,true);
        categoryTitle.setPadding(0,StoreUi.d(this,10),0,StoreUi.d(this,4));
        group.addView(categoryTitle,insertAt++);
        android.widget.LinearLayout categoryRow=StoreUi.row(this);
        categoryRow.addView(categoryInput,new android.widget.LinearLayout.LayoutParams(0,-2,1));
        TextView chooseCategory=StoreUi.button(this,"选择",0xffe3f2e9,StoreUi.GREEN);
        categoryRow.addView(chooseCategory);
        chooseCategory.setOnClickListener(v->chooseCategory());
        group.addView(categoryRow,insertAt,new android.view.ViewGroup.LayoutParams(-1,-2));
        purchaseInput = findViewById(R.id.editorPurchase);
        saleInput = findViewById(R.id.editorSale);
        purchaseInput.setFilters(new android.text.InputFilter[]{new DecimalLimit(2)});
        saleInput.setFilters(new android.text.InputFilter[]{new DecimalLimit(2)});
        imagePreview = findViewById(R.id.editorPhoto);
        noPhoto = findViewById(R.id.editorNoPhoto);
        findViewById(R.id.editorBack).setOnClickListener(v -> onBackPressed());
        findViewById(R.id.editorCamera).setOnClickListener(v -> capture());
        findViewById(R.id.editorGallery).setOnClickListener(v -> choose());
        findViewById(R.id.editorOnlineGallery).setOnClickListener(v -> {
            Intent intent = new Intent(this, OnlinePhotoSearchActivity.class);
            intent.putExtra("barcode", barcode);
            intent.putExtra("name", nameInput.getText().toString().trim());
            startActivityForResult(intent, ONLINE_PHOTO);
        });
        findViewById(R.id.editorRemovePhoto).setOnClickListener(v ->
                DeleteConfirm.show(this,"移除商品照片",
                    "商品条码："+barcode+"\n仅移除当前编辑中的照片，保存商品后才会正式生效。",
                    "照片 / "+barcode,
                    ()->{imageBytes=null;photoChanged=true;updatePreview();
                        AuditTrail.record(this,"准备删除商品照片",barcode,"待保存商品资料时生效");},
                    null,"照片已从编辑页移除，保存商品后生效"));
        findViewById(R.id.editorSave).setOnClickListener(v -> save());
        if (editing) {
            ProductDatabase.Product p = db.get(barcode);
            if (p == null) { Toast.makeText(this,"商品不存在",Toast.LENGTH_LONG).show(); finish(); return; }
            barcode = p.barcode;
            categoryInput.setText(p.category);
            nameInput.setText(p.name);
            purchaseInput.setText(Money.input(p.purchaseCents));
            saleInput.setText(Money.input(p.saleCents));
            imageBytes = db.photo(barcode);
        }
        initialName = nameInput.getText().toString();
        initialPurchase = purchaseInput.getText().toString();
        initialSale = saleInput.getText().toString();
        initialPhoto = imageBytes == null ? null : imageBytes.clone();
        initialCategory=StoreUi.value(categoryInput);
        if (state != null) {
            categoryInput.setText(state.getString("draftCategoryText",StoreUi.value(categoryInput)));
            initialCategory=state.getString("initialCategory",initialCategory);
            initialName = state.getString("initialName",initialName);
            initialPurchase = state.getString("initialPurchase",initialPurchase);
            initialSale = state.getString("initialSale",initialSale);
            photoChanged = state.getBoolean("photoChanged",false);
            draftImageFile=state.getString("draftImageFile");
            if (photoChanged && state.getBoolean("photoCleared",false)) imageBytes=null;
            else if (photoChanged && draftImageFile != null) {
                byte[] recovered=readDraftImage(draftImageFile);
                if (recovered != null) imageBytes=recovered;
            }
            nameInput.setText(state.getString("name",nameInput.getText().toString()));
            purchaseInput.setText(state.getString("cost",purchaseInput.getText().toString()));
            saleInput.setText(state.getString("sale",saleInput.getText().toString()));
            // 更换图片的草稿保存在私有缓存；原商品照片仍由数据库读取。
        }
        updatePreview();
    }

    private void chooseCategory() {
        java.util.List<String> options=new java.util.ArrayList<>(ProductCategories.list(db.getReadableDatabase()));
        if(options.isEmpty()){Toast.makeText(this,"暂无分类，可直接输入新分类名称",Toast.LENGTH_SHORT).show();return;}
        options.add(0,"不分类");
        new AlertDialog.Builder(this).setTitle("选择商品分类").setItems(options.toArray(new String[0]),
                (d,w)->categoryInput.setText(w==0?"":options.get(w))).setNegativeButton("取消",null).show();
    }

    private void updatePreview() {
        PhotoUtils.show(imageBytes,imagePreview,noPhoto);
        findViewById(R.id.editorRemovePhoto).setVisibility(imageBytes == null ? View.GONE : View.VISIBLE);
    }

    private void capture() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA},CAMERA_PERMISSION);
            return;
        }
        try {
            captureUri = PhotoUtils.newCaptureUri(this);
            startActivityForResult(PhotoUtils.photoIntent(captureUri),CAPTURE);
        } catch (Exception e) { Toast.makeText(this,"无法启动拍照",Toast.LENGTH_LONG).show(); }
    }

    @Override public void onRequestPermissionsResult(int request, String[] perms, int[] grants) {
        super.onRequestPermissionsResult(request,perms,grants);
        if (request == CAMERA_PERMISSION && grants.length > 0 &&
                grants[0] == PackageManager.PERMISSION_GRANTED) capture();
        else if (request == CAMERA_PERMISSION) Toast.makeText(this,"需要相机权限才能拍照",Toast.LENGTH_SHORT).show();
    }

    private void choose() {
        try { startActivityForResult(PhotoUtils.galleryIntent(),CHOOSE); }
        catch (Exception e) { Toast.makeText(this,"无法打开相册",Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int request,int result,Intent data) {
        super.onActivityResult(request,result,data);
        if (result != RESULT_OK) return;
        Uri selected = request == CAPTURE ? captureUri :
                ((request == CHOOSE || request == ONLINE_PHOTO) && data != null ? data.getData() : null);
        if (selected == null) return;
        try {
            imageBytes = PhotoUtils.readJpeg(this,selected);
            photoChanged = true;
            updatePreview();
        } catch (Exception e) { Toast.makeText(this,"照片读取失败，请重试",Toast.LENGTH_LONG).show(); }
    }

    private void save() {
        if(saving||saved)return;
        String name = nameInput.getText().toString().trim();
        Long cost = Money.parseCents(purchaseInput.getText().toString());
        Long sale = Money.parseCents(saleInput.getText().toString());
        if (name.isEmpty()) { nameInput.setError("请输入名称"); nameInput.requestFocus(); return; }
        if (cost == null) { purchaseInput.setError("请输入有效进价，最多两位小数"); purchaseInput.requestFocus(); return; }
        if (sale == null) { saleInput.setError("请输入有效售价，最多两位小数"); saleInput.requestFocus(); return; }
        String category=StoreUi.value(categoryInput);
        try {if(!category.isEmpty())ProductCategories.requireName(category);}
        catch(IllegalArgumentException e){categoryInput.setError(e.getMessage());categoryInput.requestFocus();return;}
        saving=true;
        findViewById(R.id.editorSave).setEnabled(false);
        try {
            ProductDatabase.Product p = new ProductDatabase.Product(barcode,name,cost,sale,
                    StoreUi.value(categoryInput));
            if (editing) {
                if (!db.update(p,imageBytes)) {
                    saving=false;findViewById(R.id.editorSave).setEnabled(true);
                    Toast.makeText(this,"原商品不存在",Toast.LENGTH_LONG).show();return;
                }
            } else {
                if (db.get(barcode) != null) {
                    saving=false;findViewById(R.id.editorSave).setEnabled(true);
                    new AlertDialog.Builder(this).setTitle("该商品已存在")
                            .setMessage("此条形码已经有商品，请返回查看或编辑已有商品。")
                            .setPositiveButton("知道了",null).show();
                    return;
                }
                db.insert(p,imageBytes);
            }
            saved=true;
            discardDraftImage();
            setResult(RESULT_OK); finish();
        } catch (SQLiteConstraintException dup) {
            saving=false;findViewById(R.id.editorSave).setEnabled(true);
            Toast.makeText(this,"条码已存在",Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            saving=false;findViewById(R.id.editorSave).setEnabled(true);
            AuditTrail.failure(this,"商品保存失败",barcode,e.getMessage());
            Toast.makeText(this,"保存失败，原商品数据未修改",Toast.LENGTH_LONG).show();
        }
    }

    private boolean hasUnsavedChanges() {
        if (nameInput == null) return false;
        return !initialCategory.equals(StoreUi.value(categoryInput)) ||
                !initialName.equals(nameInput.getText().toString()) ||
                !initialPurchase.equals(purchaseInput.getText().toString()) ||
                !initialSale.equals(saleInput.getText().toString()) ||
                photoChanged || !Arrays.equals(initialPhoto,imageBytes);
    }

    @Override protected boolean blockSwipeExitForUnsavedChanges() {
        return hasUnsavedChanges();
    }

    @Override public void onBackPressed() {
        if (!hasUnsavedChanges()) { super.onBackPressed(); return; }
        new AlertDialog.Builder(this)
                .setTitle("放弃未保存的修改？")
                .setMessage("当前商品信息尚未保存，返回将丢失这些修改。")
                .setNegativeButton("继续编辑",null)
                .setPositiveButton("放弃修改",(dialog,which) -> closeWithoutSaving())
                .show();
    }

    private void closeWithoutSaving() { super.onBackPressed(); }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if(categoryInput!=null){out.putString("draftCategoryText",categoryInput.getText().toString());
            out.putString("initialCategory",initialCategory);}
        out.putString("captureUri",captureUri == null ? null : captureUri.toString());
        out.putString("initialName",initialName);
        out.putString("initialPurchase",initialPurchase);
        out.putString("initialSale",initialSale);
        out.putBoolean("photoChanged",photoChanged);
        out.putBoolean("photoCleared",photoChanged && imageBytes==null);
        if(photoChanged && imageBytes!=null) {
            try {
                File temp=File.createTempFile("menshi-editor-photo-",".jpg",getCacheDir());
                try(FileOutputStream fos=new FileOutputStream(temp)){fos.write(imageBytes);}
                discardDraftImage();
                draftImageFile=temp.getAbsolutePath();
            }catch(Exception ignored) { /* keep current photo in memory */ }
        }
        out.putString("draftImageFile",draftImageFile);
        if (nameInput != null) {
            out.putString("name",nameInput.getText().toString());
            out.putString("cost",purchaseInput.getText().toString());
            out.putString("sale",saleInput.getText().toString());
        }
    }

    private byte[] readDraftImage(String filename) {
        try(FileInputStream stream=new FileInputStream(filename)){
            File file=new File(filename);
            if(!file.getCanonicalPath().startsWith(getCacheDir().getCanonicalPath()+File.separator) ||
                    file.length()<1 || file.length()>5_000_000)return null;
            byte[] result=new byte[(int)file.length()];int offset=0;
            while(offset<result.length){int n=stream.read(result,offset,result.length-offset);
                if(n<0)return null;offset+=n;}
            return result;
        }catch(Exception e){return null;}
    }
    private void discardDraftImage(){
        if(draftImageFile==null)return;
        try{
            File file=new File(draftImageFile);
            if(file.getCanonicalPath().startsWith(getCacheDir().getCanonicalPath()+File.separator))file.delete();
        }catch(Exception ignored){}
        draftImageFile=null;
    }
    @Override protected void onDestroy() {
        if (isFinishing())discardDraftImage();
        if (db != null) db.close();super.onDestroy();
    }
}
