package com.localpricescan.app;

import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.List;

public final class ProductCategoriesActivity extends SwipeBackActivity {
    private ProductDatabase helper;
    private LinearLayout items;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);helper=new ProductDatabase(this);
        LinearLayout root=StoreUi.content(this,"商品分类管理");setContentView(root);
        LinearLayout body=StoreUi.padded(this,StoreUi.scroll(this,root));
        TextView note=StoreUi.text(this,"按经营需要自行添加分类，商品列表将按此顺序显示。",14,false);
        note.setTextColor(StoreUi.MUTED);body.addView(note);StoreUi.gap(body,12);
        TextView add=StoreUi.button(this,"＋ 新增分类",StoreUi.GREEN,0xffffffff);
        body.addView(add);add.setOnClickListener(v->edit(null));StoreUi.gap(body,12);
        items=StoreUi.column(this);body.addView(items);refresh();
    }
    private void refresh(){
        items.removeAllViews();List<String> names=ProductCategories.list(helper.getReadableDatabase());
        if(names.isEmpty()){
            LinearLayout card=StoreUi.card(this);card.addView(StoreUi.text(this,"暂无分类，请新增所需分类。",15,false));StoreUi.addCard(items,card);return;
        }
        for(int i=0;i<names.size();i++){
            String name=names.get(i);int n=ProductCategories.count(helper.getReadableDatabase(),name);
            LinearLayout card=StoreUi.card(this);card.addView(StoreUi.text(this,name,18,true));
            TextView quantity=StoreUi.text(this,"共 "+n+" 件商品",13,false);quantity.setTextColor(StoreUi.MUTED);card.addView(quantity);StoreUi.gap(card,10);
            LinearLayout row=StoreUi.row(this);card.addView(row);
            action(row,"修改",true,()->edit(name));
            action(row,"上移",i>0,()->move(name,-1));
            action(row,"下移",i<names.size()-1,()->move(name,1));
            action(row,"删除",true,()->remove(name));
            StoreUi.addCard(items,card);
        }
    }
    private void action(LinearLayout row,String label,boolean enabled,Runnable run){
        TextView b=StoreUi.button(this,label,0xffe3f2e9,"删除".equals(label)?0xffaa4545:StoreUi.GREEN);
        b.setTextSize(13);b.setEnabled(enabled);b.setAlpha(enabled?1f:0.4f);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.rightMargin=StoreUi.d(this,4);row.addView(b,p);b.setOnClickListener(v->run.run());
    }
    private void edit(String old){
        LinearLayout box=StoreUi.column(this);int pad=StoreUi.d(this,18);box.setPadding(pad,pad,pad,0);
        EditText input=StoreUi.input(this,"分类名称",old==null?"":old,android.text.InputType.TYPE_CLASS_TEXT);box.addView(input);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(old==null?"新增分类":"修改分类").setView(box)
                .setNegativeButton("取消",null).setPositiveButton("保存",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            try{
                if(old==null)ProductCategories.add(helper.getWritableDatabase(),StoreUi.value(input));
                else ProductCategories.rename(helper.getWritableDatabase(),old,StoreUi.value(input));
                dialog.dismiss();refresh();
            }catch(Exception e){input.setError(e.getMessage()==null?"保存失败":e.getMessage());}
        }));dialog.show();KeyboardGuard.forDialog(dialog);
    }
    private void move(String name,int dir){
        try{ProductCategories.move(helper.getWritableDatabase(),name,dir);refresh();}
        catch(Exception e){new AlertDialog.Builder(this).setTitle("排序失败").setMessage(e.getMessage()).setPositiveButton("确定",null).show();}
    }
    private void remove(String name){
        if(ProductCategories.count(helper.getReadableDatabase(),name)>0){
            new AlertDialog.Builder(this).setTitle("无法删除分类").setMessage("该分类下仍有商品，请先编辑商品并转移分类。")
                    .setPositiveButton("确定",null).show();return;
        }
        DeleteConfirm.show(this,"删除商品分类","分类："+name+"\n仅删除空分类，不影响商品和库存。",name,
                ()->ProductCategories.delete(helper.getWritableDatabase(),name),this::refresh,"分类已删除");
    }
    @Override protected void onDestroy(){if(helper!=null)helper.close();super.onDestroy();}
}
