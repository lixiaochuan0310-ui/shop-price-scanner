package com.localpricescan.app;

import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** 每日/月销售统计与全部库存、进出库、盘点和销售 Excel 导出。 */
public final class StoreReportsActivity extends SwipeBackActivity {
    private static final int XLSX=940;
    private ProductDatabase db;private InventoryStore store;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);db=new ProductDatabase(this);store=new InventoryStore(db);
        LinearLayout root=StoreUi.content(this,"统计报表");setContentView(root);
        LinearLayout body=StoreUi.padded(this,StoreUi.scroll(this,root));
        String today=InventoryStore.dateToday(),month=today.substring(0,7);
        salesCard(body,"今日销售  ·  "+today,store.salesSummary(today));
        salesCard(body,"本月销售  ·  "+month,store.salesSummary(month));
        LinearLayout help=StoreUi.card(this);StoreUi.addCard(body,help);
        help.addView(StoreUi.text(this,"Excel 表格导出",18,true));StoreUi.gap(help,9);
        TextView desc=StoreUi.text(this,
                "导出内容：库存汇总、商品资料、出入库明细、单据总览、每日销售、每月销售、库存盘点。\n"+
                "包含领用日期、领用人、所属工程、用途、售出金额、实收金额等信息。",14,false);
        desc.setTextColor(StoreUi.MUTED);help.addView(desc);StoreUi.gap(help,12);
        TextView export=StoreUi.button(this,"导出完整 Excel（.xlsx）",StoreUi.GREEN,0xffffffff);
        help.addView(export);export.setOnClickListener(v->picker());
        TextView records=StoreUi.button(this,"查看全部业务流水",0xffe2f0e8,StoreUi.GREEN);
        StoreUi.gap(help,10);help.addView(records);
        records.setOnClickListener(v->startActivity(new Intent(this,StoreRecordsActivity.class)));
    }
    private void salesCard(LinearLayout body,String heading,long[] totals) {
        LinearLayout card=StoreUi.card(this);StoreUi.addCard(body,card);
        card.addView(StoreUi.text(this,heading,17,true));StoreUi.gap(card,10);
        TextView text=StoreUi.text(this,"销售单数："+totals[0]+" 单\n销售总额："+Money.show(totals[1])+
                "\n实收金额："+Money.show(totals[2]),17,false);
        text.setLineSpacing(StoreUi.d(this,3),1f);card.addView(text);
    }
    private void picker(){
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        i.putExtra(Intent.EXTRA_TITLE,"门市进销存报表_"+
                new SimpleDateFormat("yyyyMMdd_HHmm",Locale.CHINA).format(new Date())+".xlsx");
        startActivityForResult(i,XLSX);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request!=XLSX||result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){
            if(out==null)throw new IllegalArgumentException("文件不可写入");
            StoreExcel.write(out,buildSheets());
            new AlertDialog.Builder(this).setTitle("导出完成")
                    .setMessage("已生成 Excel 工作簿，包含库存、销售、领用及盘点记录。")
                    .setPositiveButton("确定",null).show();
        }catch(Exception e){
            new AlertDialog.Builder(this).setTitle("导出失败")
                    .setMessage(e.getMessage()==null?"请选择其他文件保存位置":e.getMessage())
                    .setPositiveButton("确定",null).show();
        }
    }
    private static BigDecimal qtyNumber(long milli){return BigDecimal.valueOf(milli,3);}
    private static BigDecimal moneyNumber(long cents){return BigDecimal.valueOf(cents,2);}
    private List<StoreExcel.Sheet> buildSheets(){
        List<StoreExcel.Sheet> sheets=new ArrayList<>();
        StoreExcel.Sheet stock=new StoreExcel.Sheet("库存汇总");
        stock.add("商品名称","商品条码","基础单位","期初数量","累计入库","累计售出","内部领用","其他出库","盘点差额","当前库存");
        for(InventoryStore.StockRow s:store.stocks())stock.add(s.name,s.barcode,s.unit,
                qtyNumber(s.opening),qtyNumber(s.incoming),qtyNumber(s.sale),qtyNumber(s.issue),
                qtyNumber(s.other),qtyNumber(s.adjustment),qtyNumber(s.current));
        sheets.add(stock);
        StoreExcel.Sheet product=new StoreExcel.Sheet("商品资料");
        product.add("商品名称","条码","基础单位","包装单位","每包装基础数量","预设进价(元)","预设售价(元)");
        for(ProductDatabase.Product p:db.all()){
            InventoryStore.Settings s=store.settings(p.barcode);
            product.add(p.name,p.barcode,s.base,s.pack,s.factor,moneyNumber(p.purchaseCents),moneyNumber(p.saleCents));
        }sheets.add(product);
        StoreExcel.Sheet details=new StoreExcel.Sheet("出入库明细");
        details.add("业务日期","业务类型","单号","商品名称","商品条码","数量","单位","折合基础数量","单价(元)","小计(元)","供货商/客户/领用人","部门或工程","用途或原因");
        StoreExcel.Sheet docs=new StoreExcel.Sheet("单据总览");
        docs.add("业务日期","业务类型","单号","供货商/客户/领用人","部门/工程","用途/原因","商品种数","单据金额(元)","实收金额(元)");
        Map<String,long[]> daily=new LinkedHashMap<>(),monthly=new LinkedHashMap<>();
        for(InventoryStore.Document d:store.documents()){
            List<InventoryStore.Line> lines=store.lines(d.id);
            docs.add(d.date,InventoryStore.kindName(d.kind),d.id,d.party,d.department,d.purpose,
                    lines.size(),moneyNumber(d.total),InventoryStore.SALE.equals(d.kind)?moneyNumber(d.paid):"");
            for(InventoryStore.Line line:lines)details.add(d.date,InventoryStore.kindName(d.kind),d.id,
                    line.name,line.barcode,qtyNumber(line.inputMilli),line.unit,qtyNumber(line.baseMilli),
                    moneyNumber(line.unitPrice),moneyNumber(line.amount),d.party,d.department,d.purpose);
            if(InventoryStore.SALE.equals(d.kind)){
                long[] day=daily.computeIfAbsent(d.date,k->new long[3]);
                day[0]++;day[1]=Math.addExact(day[1],d.total);day[2]=Math.addExact(day[2],d.paid);
                long[] month=monthly.computeIfAbsent(d.date.substring(0,7),k->new long[3]);
                month[0]++;month[1]=Math.addExact(month[1],d.total);month[2]=Math.addExact(month[2],d.paid);
            }
        }
        sheets.add(details);sheets.add(docs);
        StoreExcel.Sheet days=new StoreExcel.Sheet("每日销售");days.add("销售日期","销售单数","销售总额(元)","实收金额(元)");
        for(Map.Entry<String,long[]> a:daily.entrySet())days.add(a.getKey(),a.getValue()[0],
                moneyNumber(a.getValue()[1]),moneyNumber(a.getValue()[2]));sheets.add(days);
        StoreExcel.Sheet months=new StoreExcel.Sheet("每月销售");months.add("销售月份","销售单数","销售总额(元)","实收金额(元)");
        for(Map.Entry<String,long[]> a:monthly.entrySet())months.add(a.getKey(),a.getValue()[0],
                moneyNumber(a.getValue()[1]),moneyNumber(a.getValue()[2]));sheets.add(months);
        StoreExcel.Sheet counted=new StoreExcel.Sheet("库存盘点");
        counted.add("盘点日期","商品名称","条码","基础单位","盘点前库存","实盘数量","盘盈盘亏差额","备注");
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT business_date,product_name,barcode,before_milli,"+
                "actual_milli,delta_milli,note FROM stock_counts ORDER BY business_date DESC,id DESC",null)){
            while(c.moveToNext())counted.add(c.getString(0),c.getString(1),c.getString(2),
                    store.settings(c.getString(2)).base,
                    qtyNumber(c.getLong(3)),qtyNumber(c.getLong(4)),qtyNumber(c.getLong(5)),c.getString(6));
        }
        sheets.add(counted);return sheets;
    }
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
