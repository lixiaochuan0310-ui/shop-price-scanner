package com.localpricescan.app;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** 进销存业务账本。所有数量以基础单位的千分之一存储，价格以分存储。 */
final class InventoryStore {
    static final String IN="IN", SALE="SALE", ISSUE="ISSUE", OTHER="OTHER";
    private final ProductDatabase helper;
    InventoryStore(ProductDatabase helper) { this.helper=helper; }

    static void createSchema(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS stock_settings ("+
                "barcode TEXT PRIMARY KEY NOT NULL, base_unit TEXT NOT NULL DEFAULT '件', "+
                "pack_unit TEXT NOT NULL DEFAULT '', pack_factor INTEGER NOT NULL DEFAULT 1 "+
                "CHECK(pack_factor >= 1), opening_milli INTEGER NOT NULL DEFAULT 0 "+
                "CHECK(opening_milli >= 0))");
        db.execSQL("CREATE TABLE IF NOT EXISTS stock_documents ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, business_date TEXT NOT NULL, "+
                "party TEXT NOT NULL DEFAULT '', department TEXT NOT NULL DEFAULT '', "+
                "purpose TEXT NOT NULL DEFAULT '', total_cents INTEGER NOT NULL DEFAULT 0, "+
                "paid_cents INTEGER NOT NULL DEFAULT 0, created_ms INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS stock_lines ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, document_id INTEGER NOT NULL, "+
                "barcode TEXT NOT NULL, product_name TEXT NOT NULL, "+
                "input_qty_milli INTEGER NOT NULL CHECK(input_qty_milli > 0), "+
                "unit_name TEXT NOT NULL, base_qty_milli INTEGER NOT NULL CHECK(base_qty_milli > 0), "+
                "unit_price_cents INTEGER NOT NULL CHECK(unit_price_cents >= 0), "+
                "amount_cents INTEGER NOT NULL CHECK(amount_cents >= 0), "+
                "FOREIGN KEY(document_id) REFERENCES stock_documents(id) ON DELETE CASCADE)");
        db.execSQL("CREATE INDEX IF NOT EXISTS stock_line_barcode_idx ON stock_lines(barcode)");
        db.execSQL("CREATE INDEX IF NOT EXISTS stock_doc_date_idx ON stock_documents(business_date)");
        db.execSQL("CREATE TABLE IF NOT EXISTS stock_counts ("+
                "id INTEGER PRIMARY KEY AUTOINCREMENT, business_date TEXT NOT NULL, "+
                "barcode TEXT NOT NULL, product_name TEXT NOT NULL, before_milli INTEGER NOT NULL, "+
                "actual_milli INTEGER NOT NULL CHECK(actual_milli >= 0), "+
                "delta_milli INTEGER NOT NULL, note TEXT NOT NULL DEFAULT '', created_ms INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX IF NOT EXISTS stock_count_barcode_idx ON stock_counts(barcode)");
    }

    static final class Settings {
        final String base, pack;
        final long factor, opening;
        Settings(String base,String pack,long factor,long opening) {
            this.base=base;this.pack=pack;this.factor=factor;this.opening=opening;
        }
    }
    static final class Line {
        final String barcode, name, unit;
        final long inputMilli, baseMilli, unitPrice, amount;
        Line(String barcode,String name,String unit,long inputMilli,long baseMilli,long unitPrice,long amount) {
            this.barcode=barcode;this.name=name;this.unit=unit;this.inputMilli=inputMilli;
            this.baseMilli=baseMilli;this.unitPrice=unitPrice;this.amount=amount;
        }
    }
    static final class Document {
        final long id, total, paid;
        final String kind, date, party, department, purpose;
        Document(long id,String kind,String date,String party,String department,String purpose,long total,long paid) {
            this.id=id;this.kind=kind;this.date=date;this.party=party;
            this.department=department;this.purpose=purpose;this.total=total;this.paid=paid;
        }
    }
    static final class StockRow {
        final String barcode, name, unit;
        final long opening, incoming, sale, issue, other, adjustment, current;
        StockRow(String barcode,String name,String unit,long opening,long incoming,long sale,long issue,
                 long other,long adjustment) {
            this.barcode=barcode;this.name=name;this.unit=unit;this.opening=opening;this.incoming=incoming;
            this.sale=sale;this.issue=issue;this.other=other;this.adjustment=adjustment;
            this.current=opening+incoming-sale-issue-other+adjustment;
        }
    }

    static Long parseQty(String text) {
        if (text == null || !text.trim().matches("(?:0|[1-9][0-9]{0,8})(?:\\.[0-9]{1,3})?")) return null;
        try { return new BigDecimal(text.trim()).movePointRight(3).longValueExact(); }
        catch (ArithmeticException e) { return null; }
    }
    static String qty(long milli) { return BigDecimal.valueOf(milli,3).stripTrailingZeros().toPlainString(); }
    static String dateToday() { return new SimpleDateFormat("yyyy-MM-dd",Locale.CHINA).format(new Date()); }
    static boolean validDate(String date) {
        if (date==null || !date.matches("\\d{4}-\\d{2}-\\d{2}")) return false;
        try { SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd",Locale.CHINA);
            format.setLenient(false); return format.parse(date)!=null;
        } catch (Exception e) { return false; }
    }
    static long amount(long unitPriceCents,long inputQtyMilli) {
        if (unitPriceCents<0 || inputQtyMilli<=0) throw new IllegalArgumentException("数量或单价无效");
        return BigDecimal.valueOf(unitPriceCents).multiply(BigDecimal.valueOf(inputQtyMilli))
                .divide(BigDecimal.valueOf(1000),0,RoundingMode.HALF_UP).longValueExact();
    }

    Settings settings(String barcode) {
        try (Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT base_unit, pack_unit, pack_factor, opening_milli FROM stock_settings WHERE barcode=?",
                new String[]{barcode})) {
            if (c.moveToFirst()) return new Settings(c.getString(0),c.getString(1),c.getLong(2),c.getLong(3));
        }
        return new Settings("件","",1,0);
    }
    void saveSettings(String barcode,String base,String pack,long factor,long opening) {
        if (helper.get(barcode)==null) throw new IllegalArgumentException("商品不存在");
        if (base==null || base.trim().isEmpty() || base.length()>16 || pack==null || pack.length()>16 ||
                factor<1 || factor>1_000_000 || opening<0) throw new IllegalArgumentException("单位或库存数量无效");
        if (base.trim().equals(pack.trim()) && !pack.trim().isEmpty()) throw new IllegalArgumentException("包装单位不能与基础单位相同");
        ContentValues v=new ContentValues();
        v.put("barcode",barcode);v.put("base_unit",base.trim());v.put("pack_unit",pack.trim());
        v.put("pack_factor",pack.trim().isEmpty()?1:factor);v.put("opening_milli",opening);
        helper.getWritableDatabase().insertWithOnConflict("stock_settings",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    boolean hasLedger(String barcode) {
        try (Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT (SELECT count(*) FROM stock_lines WHERE barcode=?) + "+
                "(SELECT count(*) FROM stock_counts WHERE barcode=?)",
                new String[]{barcode,barcode})) {return c.moveToFirst() && c.getLong(0)>0;}
    }
    private static long sum(SQLiteDatabase db,String sql,String barcode) {
        try (Cursor c=db.rawQuery(sql,new String[]{barcode})) {return c.moveToFirst() ? c.getLong(0):0;}
    }
    private static long qtyOn(SQLiteDatabase db,String barcode) {
        long opening=sum(db,"SELECT COALESCE(opening_milli,0) FROM stock_settings WHERE barcode=?",barcode);
        long ledger=sum(db,"SELECT COALESCE(SUM(CASE WHEN d.kind='IN' THEN l.base_qty_milli "+
                "ELSE -l.base_qty_milli END),0) FROM stock_lines l "+
                "JOIN stock_documents d ON d.id=l.document_id WHERE l.barcode=?",barcode);
        long adjust=sum(db,"SELECT COALESCE(SUM(delta_milli),0) FROM stock_counts WHERE barcode=?",barcode);
        return Math.addExact(Math.addExact(opening,ledger),adjust);
    }
    long current(String barcode) { return qtyOn(helper.getReadableDatabase(),barcode); }

    /** 一次 SQL 汇总库存，避免商品较多时逐件查询导致页面卡顿。 */
    List<StockRow> stocks() {
        List<StockRow> rows=new ArrayList<>();
        String sql="SELECT p.barcode,p.name,COALESCE(s.base_unit,'件'),"+
                "COALESCE(s.opening_milli,0),COALESCE(m.incoming,0),COALESCE(m.sold,0),"+
                "COALESCE(m.issued,0),COALESCE(m.other_out,0),COALESCE(a.adjusted,0) " +
                "FROM products p LEFT JOIN stock_settings s ON s.barcode=p.barcode " +
                "LEFT JOIN (SELECT l.barcode,"+
                "SUM(CASE WHEN d.kind='IN' THEN l.base_qty_milli ELSE 0 END) incoming,"+
                "SUM(CASE WHEN d.kind='SALE' THEN l.base_qty_milli ELSE 0 END) sold,"+
                "SUM(CASE WHEN d.kind='ISSUE' THEN l.base_qty_milli ELSE 0 END) issued,"+
                "SUM(CASE WHEN d.kind='OTHER' THEN l.base_qty_milli ELSE 0 END) other_out " +
                "FROM stock_lines l JOIN stock_documents d ON d.id=l.document_id " +
                "GROUP BY l.barcode) m ON m.barcode=p.barcode " +
                "LEFT JOIN (SELECT barcode,SUM(delta_milli) adjusted FROM stock_counts GROUP BY barcode) a " +
                "ON a.barcode=p.barcode ORDER BY p.name COLLATE NOCASE,p.barcode";
        try(Cursor c=helper.getReadableDatabase().rawQuery(sql,null)) {
            while(c.moveToNext()) rows.add(new StockRow(c.getString(0),c.getString(1),c.getString(2),
                    c.getLong(3),c.getLong(4),c.getLong(5),c.getLong(6),c.getLong(7),c.getLong(8)));
        }
        return rows;
    }

    static String kindName(String kind) {
        switch(kind) {case IN:return "商品入库";case SALE:return "商品销售";
            case ISSUE:return "内部领用";case OTHER:return "其他出库";default:return kind;}
    }
    /** 将一整张多商品单据原子提交；出库库存不足则全部回滚。 */
    long saveDocument(String kind,String date,String party,String department,String purpose,
                      List<Line> lines,long actualPaid) {
        if (!IN.equals(kind) && !SALE.equals(kind) && !ISSUE.equals(kind) && !OTHER.equals(kind))
            throw new IllegalArgumentException("未知单据类型");
        if (!validDate(date) || lines==null || lines.isEmpty()) throw new IllegalArgumentException("日期或商品明细无效");
        if (ISSUE.equals(kind) && (party.trim().isEmpty() || department.trim().isEmpty() || purpose.trim().isEmpty()))
            throw new IllegalArgumentException("请填写领用人、部门/工程和领用用途");
        if (actualPaid<0) throw new IllegalArgumentException("实收金额无效");
        long total=0;
        for(Line line:lines) {
            if (line.baseMilli<=0 || line.inputMilli<=0 || line.unitPrice<0 || line.amount<0 ||
                    helper.get(line.barcode)==null) throw new IllegalArgumentException("商品明细无效");
            total=Math.addExact(total,line.amount);
        }
        SQLiteDatabase db=helper.getWritableDatabase();
        db.beginTransaction();
        try {
            ContentValues doc=new ContentValues();
            doc.put("kind",kind);doc.put("business_date",date);doc.put("party",party.trim());
            doc.put("department",department.trim());doc.put("purpose",purpose.trim());
            doc.put("total_cents",total);doc.put("paid_cents",SALE.equals(kind)?actualPaid:0);
            doc.put("created_ms",System.currentTimeMillis());
            long docId=db.insertOrThrow("stock_documents",null,doc);
            for(Line l:lines) {
                ContentValues row=new ContentValues();
                row.put("document_id",docId);row.put("barcode",l.barcode);
                row.put("product_name",l.name);row.put("input_qty_milli",l.inputMilli);
                row.put("unit_name",l.unit);row.put("base_qty_milli",l.baseMilli);
                row.put("unit_price_cents",l.unitPrice);row.put("amount_cents",l.amount);
                db.insertOrThrow("stock_lines",null,row);
                if (!IN.equals(kind) && qtyOn(db,l.barcode)<0)
                    throw new IllegalArgumentException("库存不足："+l.name+"，本单未保存");
            }
            db.setTransactionSuccessful();
            return docId;
        } finally {db.endTransaction();}
    }
    /** 盘点按保存瞬间库存计算差额，原子记录，不覆写历史流水。 */
    void count(String barcode,String date,long actualMilli,String note) {
        if (!validDate(date) || actualMilli<0) throw new IllegalArgumentException("日期或实盘数量无效");
        ProductDatabase.Product p=helper.get(barcode);
        if (p==null) throw new IllegalArgumentException("商品不存在");
        SQLiteDatabase db=helper.getWritableDatabase();
        db.beginTransaction();
        try {
            long before=qtyOn(db,barcode);
            long difference=Math.subtractExact(actualMilli,before);
            ContentValues v=new ContentValues();v.put("business_date",date);v.put("barcode",barcode);
            v.put("product_name",p.name);v.put("before_milli",before);v.put("actual_milli",actualMilli);
            v.put("delta_milli",difference);v.put("note",note.trim());v.put("created_ms",System.currentTimeMillis());
            db.insertOrThrow("stock_counts",null,v);
            db.setTransactionSuccessful();
        } finally {db.endTransaction();}
    }
    List<Document> documents() {
        List<Document> docs=new ArrayList<>();
        try(Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT id,kind,business_date,party,department,purpose,total_cents,paid_cents " +
                        "FROM stock_documents ORDER BY business_date DESC,id DESC",null)) {
            while(c.moveToNext()) docs.add(new Document(c.getLong(0),c.getString(1),c.getString(2),
                    c.getString(3),c.getString(4),c.getString(5),c.getLong(6),c.getLong(7)));
        }
        return docs;
    }
    List<Line> lines(long documentId) {
        List<Line> rows=new ArrayList<>();
        try(Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT barcode,product_name,unit_name,input_qty_milli,base_qty_milli,unit_price_cents,amount_cents " +
                        "FROM stock_lines WHERE document_id=? ORDER BY id",new String[]{Long.toString(documentId)})) {
            while(c.moveToNext()) rows.add(new Line(c.getString(0),c.getString(1),c.getString(2),
                    c.getLong(3),c.getLong(4),c.getLong(5),c.getLong(6)));
        }
        return rows;
    }
    long[] salesSummary(String prefix) {
        long[] out={0,0,0};
        try(Cursor c=helper.getReadableDatabase().rawQuery(
                "SELECT count(*),COALESCE(SUM(total_cents),0),COALESCE(SUM(paid_cents),0) "+
                "FROM stock_documents WHERE kind='SALE' AND business_date LIKE ?",new String[]{prefix+"%"})) {
            if(c.moveToFirst()) {out[0]=c.getLong(0);out[1]=c.getLong(1);out[2]=c.getLong(2);}
        }
        return out;
    }
}
