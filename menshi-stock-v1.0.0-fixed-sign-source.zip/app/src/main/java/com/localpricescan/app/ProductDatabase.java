package com.localpricescan.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/** 原商品数据库不变；升级仅增加图片表，已有商品和价格原样保留。 */
final class ProductDatabase extends SQLiteOpenHelper {
    static final String DATABASE = "offline_products.db";
    private static final int VERSION = 3;
    static final int MAX_PHOTO_BYTES = 1_200_000;

    ProductDatabase(Context context) { super(context, DATABASE, null, VERSION); }

    @Override public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE products (barcode TEXT PRIMARY KEY NOT NULL, " +
                "name TEXT NOT NULL, purchase_cents INTEGER NOT NULL CHECK(purchase_cents >= 0), " +
                "sale_cents INTEGER NOT NULL CHECK(sale_cents >= 0))");
        createImages(db);
        InventoryStore.createSchema(db);
    }

    private void createImages(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS product_images (barcode TEXT PRIMARY KEY NOT NULL, " +
                "jpeg BLOB NOT NULL, FOREIGN KEY(barcode) REFERENCES products(barcode) ON DELETE CASCADE)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) createImages(db);
        if (oldVersion < 3) InventoryStore.createSchema(db);
    }

    Product get(String barcode) {
        if (barcode == null || barcode.isEmpty()) return null;
        Product found = getExact(barcode);
        if (found != null) return found;
        String normalized = BarcodeKey.scanned(barcode);
        if (!normalized.equals(barcode)) {
            found = getExact(normalized);
            if (found != null) return found;
        }
        String alternative = BarcodeKey.equivalentUpcEan(normalized);
        return alternative == null ? null : getExact(alternative);
    }

    private Product getExact(String barcode) {
        try (Cursor cursor = getReadableDatabase().query("products",
                new String[]{"barcode", "name", "purchase_cents", "sale_cents"},
                "barcode = ?", new String[]{barcode}, null, null, null)) {
            if (!cursor.moveToFirst()) return null;
            return new Product(cursor.getString(0), cursor.getString(1),
                    cursor.getLong(2), cursor.getLong(3));
        }
    }

    List<Product> all() {
        List<Product> out = new ArrayList<>();
        try (Cursor cursor = getReadableDatabase().query("products",
                new String[]{"barcode", "name", "purchase_cents", "sale_cents"},
                null, null, null, null, "name COLLATE NOCASE ASC, barcode ASC")) {
            while (cursor.moveToNext()) {
                out.add(new Product(cursor.getString(0), cursor.getString(1),
                        cursor.getLong(2), cursor.getLong(3)));
            }
        }
        return out;
    }

    int count() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT count(*) FROM products", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    byte[] photo(String barcode) {
        try (Cursor c = getReadableDatabase().query("product_images", new String[]{"jpeg"},
                "barcode = ?", new String[]{barcode}, null, null, null)) {
            return c.moveToFirst() ? c.getBlob(0) : null;
        }
    }

    private static ContentValues values(Product p) {
        ContentValues v = new ContentValues();
        v.put("barcode", p.barcode);
        v.put("name", p.name);
        v.put("purchase_cents", p.purchaseCents);
        v.put("sale_cents", p.saleCents);
        return v;
    }

    private static void photoInTransaction(SQLiteDatabase db, String barcode, byte[] photo) {
        db.delete("product_images", "barcode = ?", new String[]{barcode});
        if (photo != null) {
            requirePhoto(photo);
            ContentValues v = new ContentValues();
            v.put("barcode", barcode);
            v.put("jpeg", photo);
            db.insertOrThrow("product_images", null, v);
        }
    }

    static void requirePhoto(byte[] jpeg) {
        if (jpeg != null && (jpeg.length < 4 || jpeg.length > MAX_PHOTO_BYTES ||
                (jpeg[0] & 255) != 255 || (jpeg[1] & 255) != 216 ||
                (jpeg[jpeg.length - 2] & 255) != 255 || (jpeg[jpeg.length - 1] & 255) != 217)) {
            throw new IllegalArgumentException("商品照片无效或过大");
        }
    }

    void insert(Product product, byte[] photo) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.insertOrThrow("products", null, values(product));
            photoInTransaction(db, product.barcode, photo);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    boolean update(Product product, byte[] photo) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            if (db.update("products", values(product), "barcode = ?",
                    new String[]{product.barcode}) != 1) return false;
            photoInTransaction(db, product.barcode, photo);
            db.setTransactionSuccessful();
            return true;
        } finally { db.endTransaction(); }
    }

    boolean delete(String barcode) {
        InventoryStore stock=new InventoryStore(this);
        if (stock.hasLedger(barcode) || stock.current(barcode)!=0)
            throw new IllegalStateException("该商品仍有库存或历史业务记录，不能删除");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            int result = db.delete("products", "barcode = ?", new String[]{barcode});
            if (result > 0) {
                db.delete("product_images", "barcode = ?", new String[]{barcode});
                db.delete("stock_settings", "barcode = ?", new String[]{barcode});
            }
            db.setTransactionSuccessful();
            return result == 1;
        } finally { db.endTransaction(); }
    }

    /** 全部校验后，以单个事务替换商品和照片，失败则原数据及照片全部回滚。 */
    void replaceAll(List<Record> records) {
        HashSet<String> keys = new HashSet<>();
        for (Record record : records) {
            Product p = record.product;
            if (p.barcode.isEmpty() || p.barcode.length() > 200 || p.name.trim().isEmpty() ||
                    p.name.length() > 500 || p.purchaseCents < 0 || p.saleCents < 0 ||
                    !keys.add(p.barcode)) throw new IllegalArgumentException("无效的商品备份数据");
            requirePhoto(record.photo);
        }
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("product_images", null, null);
            db.delete("products", null, null);
            for (Record r : records) {
                db.insertOrThrow("products", null, values(r.product));
                if (r.photo != null) photoInTransaction(db, r.product.barcode, r.photo);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    static final class Product {
        final String barcode, name;
        final long purchaseCents, saleCents;
        Product(String barcode, String name, long purchaseCents, long saleCents) {
            this.barcode=barcode; this.name=name;
            this.purchaseCents=purchaseCents; this.saleCents=saleCents;
        }
    }

    static final class Record {
        final Product product;
        final byte[] photo;
        Record(Product product, byte[] photo) { this.product=product; this.photo=photo; }
    }
}
