package com.localpricescan.app;

import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** 入库、销售、内部领用、其他出库及盘点全部保留可查的单据流水。 */
public final class StoreRecordsActivity extends SwipeBackActivity {
    private ProductDatabase db;private InventoryStore store;
    private LinearLayout list;private EditText search;
    private String barcodeOnly;
    private static final class CountRow {
        long id,before,actual,delta;String date,code,name,note;
    }
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);db=new ProductDatabase(this);store=new InventoryStore(db);
        barcodeOnly=getIntent().getStringExtra("barcode");
        LinearLayout root=StoreUi.content(this,barcodeOnly==null?"业务流水记录":"商品流水记录");setContentView(root);
        LinearLayout body=StoreUi.padded(this,StoreUi.scroll(this,root));
        LinearLayout filters=StoreUi.card(this);StoreUi.addCard(body,filters);
        StoreUi.label(filters,"按日期、商品、人员、客户或工程搜索");
        search=StoreUi.input(this,"例如：2026-11、张三、摄像头","",1);filters.addView(search);
        StoreUi.gap(body,4);list=StoreUi.column(this);body.addView(list);
        search.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after) {}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){reload();}
            @Override public void afterTextChanged(Editable e) {}
        });reload();
    }
    private List<CountRow> counts() {
        List<CountRow> out=new ArrayList<>();
        try(Cursor c=db.getReadableDatabase().rawQuery("SELECT id,business_date,barcode,product_name,"+
                "before_milli,actual_milli,delta_milli,note FROM stock_counts ORDER BY business_date DESC,id DESC",null)) {
            while(c.moveToNext()){CountRow r=new CountRow();r.id=c.getLong(0);r.date=c.getString(1);
                r.code=c.getString(2);r.name=c.getString(3);r.before=c.getLong(4);r.actual=c.getLong(5);
                r.delta=c.getLong(6);r.note=c.getString(7);out.add(r);}
        }return out;
    }
    private void reload() {
        if(list==null)return;
        list.removeAllViews();String q=StoreUi.value(search).toLowerCase(Locale.ROOT);
        int count=0;
        for(InventoryStore.Document doc:store.documents()) {
            List<InventoryStore.Line> lines=store.lines(doc.id);
            if(barcodeOnly!=null) {
                boolean related=false;for(InventoryStore.Line l:lines)if(barcodeOnly.equals(l.barcode))related=true;
                if(!related)continue;
            }
            StringBuilder names=new StringBuilder();for(InventoryStore.Line l:lines)names.append(l.name).append(' ');
            String target=(doc.date+doc.party+doc.department+doc.purpose+names+doc.id+
                    InventoryStore.kindName(doc.kind)).toLowerCase(Locale.ROOT);
            if(!q.isEmpty()&&!target.contains(q))continue;
            count++;
            LinearLayout card=StoreUi.card(this);
            TextView heading=StoreUi.text(this,InventoryStore.kindName(doc.kind)+"  ·  "+doc.date,17,true);
            card.addView(heading);StoreUi.gap(card,5);
            TextView info=StoreUi.text(this,"单号 #"+doc.id+"  ·  "+lines.size()+" 种商品\n"+
                    names.toString().trim(),13,false);info.setTextColor(StoreUi.MUTED);card.addView(info);
            if(InventoryStore.SALE.equals(doc.kind)||InventoryStore.IN.equals(doc.kind)) {
                StoreUi.gap(card,6);TextView price=StoreUi.text(this,
                        "单据金额 "+Money.show(doc.total)+(InventoryStore.SALE.equals(doc.kind)?
                                "  ·  实收 "+Money.show(doc.paid):""),14,true);
                price.setTextColor(StoreUi.GREEN);card.addView(price);
            }
            StoreUi.addCard(list,card);card.setOnClickListener(v->showDocument(doc,lines));
        }
        for(CountRow c:counts()) {
            if(barcodeOnly!=null&&!barcodeOnly.equals(c.code))continue;
            if(!q.isEmpty() && !(c.date+c.name+c.code+c.note).toLowerCase(Locale.ROOT).contains(q))continue;
            count++;LinearLayout card=StoreUi.card(this);
            card.addView(StoreUi.text(this,"库存盘点  ·  "+c.date,17,true));
            StoreUi.gap(card,5);
            TextView t=StoreUi.text(this,c.name+"\n系统 "+InventoryStore.qty(c.before)+
                    "  →  实盘 "+InventoryStore.qty(c.actual)+"  ·  差额 "+InventoryStore.qty(c.delta),13,false);
            t.setTextColor(StoreUi.MUTED);card.addView(t);
            StoreUi.addCard(list,card);card.setOnClickListener(v->showCount(c));
        }
        if(count==0)list.addView(StoreUi.text(this,"没有符合条件的业务记录。",15,false));
    }
    private void showDocument(InventoryStore.Document d,List<InventoryStore.Line> lines) {
        StringBuilder sb=new StringBuilder("日期：").append(d.date).append("\n单据：#").append(d.id);
        if(!d.party.isEmpty())sb.append("\n客户／供货商／领用人：").append(d.party);
        if(!d.department.isEmpty())sb.append("\n部门／工程：").append(d.department);
        if(!d.purpose.isEmpty())sb.append("\n用途／原因：").append(d.purpose);
        sb.append("\n\n商品明细：");
        for(InventoryStore.Line l:lines){
            if(barcodeOnly!=null&&!barcodeOnly.equals(l.barcode))continue;
            sb.append("\n").append(l.name).append("\n  ").append(InventoryStore.qty(l.inputMilli)).append(" ")
                    .append(l.unit).append(" × ").append(Money.show(l.unitPrice)).append(" = ").append(Money.show(l.amount));
        }
        sb.append("\n\n单据总额：").append(Money.show(d.total));
        if(InventoryStore.SALE.equals(d.kind))sb.append("\n实收金额：").append(Money.show(d.paid));
        new AlertDialog.Builder(this).setTitle(InventoryStore.kindName(d.kind)+"详情")
                .setMessage(sb.toString()).setPositiveButton("关闭",null).show();
    }
    private void showCount(CountRow c) {
        new AlertDialog.Builder(this).setTitle("库存盘点详情")
                .setMessage("日期："+c.date+"\n商品："+c.name+"\n条码："+c.code+
                        "\n原库存："+InventoryStore.qty(c.before)+
                        "\n实盘数量："+InventoryStore.qty(c.actual)+
                        "\n盘点差额："+InventoryStore.qty(c.delta)+"\n备注："+c.note)
                .setPositiveButton("关闭",null).show();
    }
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
