package com.localpricescan.app;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** 一张单据多种商品，扫码与商品库检索都能加入明细。 */
public final class StoreDocumentActivity extends SwipeBackActivity {
    private static final int NEW_PRODUCT=822;
    private ProductDatabase db;
    private InventoryStore store;
    private String kind,pending;
    private EditText date,party,department,purpose,paid;
    private TextView totalView,save;
    private LinearLayout linesContainer;
    private final List<LineEditor> items=new ArrayList<>();
    private long lastTotal=-1;

    private static final class LineEditor {
        ProductDatabase.Product product;
        InventoryStore.Settings setting;
        EditText quantity,price;
        Spinner unit;
        TextView subtotal;
        LinearLayout card;
        boolean firstUnitEvent=true;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);db=new ProductDatabase(this);store=new InventoryStore(db);
        kind=getIntent().getStringExtra("kind");
        if(!InventoryStore.IN.equals(kind) && !InventoryStore.SALE.equals(kind) &&
                !InventoryStore.ISSUE.equals(kind) && !InventoryStore.OTHER.equals(kind)) {finish();return;}
        LinearLayout root=StoreUi.content(this,"新建"+InventoryStore.kindName(kind));
        setContentView(root);
        LinearLayout body=StoreUi.padded(this,StoreUi.scroll(this,root));
        LinearLayout basics=StoreUi.card(this);StoreUi.addCard(body,basics);
        StoreUi.label(basics,"单据日期（点击可更改）");
        date=StoreUi.input(this,"日期",InventoryStore.dateToday(),1);
        date.setFocusable(false);date.setOnClickListener(v->pickDate(date));basics.addView(date);
        StoreUi.gap(basics,10);
        if(InventoryStore.IN.equals(kind)) {
            StoreUi.label(basics,"供货商名称（选填）");party=addInput(basics,"例如：某设备供应商");
        } else if(InventoryStore.SALE.equals(kind)) {
            StoreUi.label(basics,"购买人／客户单位（选填）");party=addInput(basics,"不填写也可以保存");
        } else if(InventoryStore.ISSUE.equals(kind)) {
            StoreUi.label(basics,"领用人（必填）");party=addInput(basics,"实际领取人员姓名");
            StoreUi.gap(basics,10);
            StoreUi.label(basics,"领用部门／工程（必填）");department=addInput(basics,"例如：XX小区监控工程");
            StoreUi.gap(basics,10);
            StoreUi.label(basics,"领用用途（必填）");purpose=addInput(basics,"例如：安装摄像头");
        } else {
            StoreUi.label(basics,"其他出库去向／接收人（选填）");party=addInput(basics,"例如：调拨到其他门市");
            StoreUi.gap(basics,10);
            StoreUi.label(basics,"出库原因（选填）");purpose=addInput(basics,"例如：内部调拨");
        }

        LinearLayout goods=StoreUi.card(this);StoreUi.addCard(body,goods);
        TextView prompt=StoreUi.text(this,"商品明细（可一次添加多种商品）",17,true);goods.addView(prompt);
        StoreUi.gap(goods,8);
        LinearLayout buttons=StoreUi.row(this);
        TextView scan=StoreUi.button(this,"扫码添加",0xffd5ecfd,StoreUi.INK);
        buttons.addView(scan,new LinearLayout.LayoutParams(0,-2,1));scan.setOnClickListener(v->startScanner());
        TextView choose=StoreUi.button(this,"商品库选择",0xffe0f3e3,StoreUi.GREEN);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1);cp.leftMargin=StoreUi.d(this,8);
        buttons.addView(choose,cp);choose.setOnClickListener(v->chooseProduct());
        goods.addView(buttons);
        StoreUi.gap(goods,9);
        linesContainer=StoreUi.column(this);goods.addView(linesContainer);
        TextView empty=StoreUi.text(this,"暂无商品，请扫码添加或从商品库选择。",13,false);
        empty.setTextColor(StoreUi.MUTED);empty.setTag("emptyLineHint");linesContainer.addView(empty);
        LinearLayout totals=StoreUi.card(this);StoreUi.addCard(body,totals);
        totalView=StoreUi.text(this,"单据金额  ¥0.00",20,true);totals.addView(totalView);
        if(InventoryStore.SALE.equals(kind)) {
            StoreUi.gap(totals,12);
            StoreUi.label(totals,"实收金额（默认等于销售总额，可修改）");
            paid=StoreUi.decimal(this,"实收金额","0.00");totals.addView(paid);
        }
        save=StoreUi.button(this,"保存整张"+InventoryStore.kindName(kind)+"单",StoreUi.GREEN,0xffffffff);
        LinearLayout.LayoutParams savep=StoreUi.lp(-1,-2);
        savep.leftMargin=savep.rightMargin=StoreUi.d(this,15);savep.bottomMargin=StoreUi.d(this,12);
        root.addView(save,savep);save.setOnClickListener(v->commit());
        String preset=getIntent().getStringExtra("barcode");if(preset!=null) addProduct(preset);
    }
    private EditText addInput(LinearLayout parent,String hint) {
        EditText e=StoreUi.input(this,hint,"",1);parent.addView(e);return e;
    }
    private void pickDate(EditText field) {
        Calendar c=Calendar.getInstance();String[] p=StoreUi.value(field).split("-");
        if(p.length==3) try {c.set(Integer.parseInt(p[0]),Integer.parseInt(p[1])-1,Integer.parseInt(p[2]));}
        catch(Exception ignored) {}
        new DatePickerDialog(this,(view,y,m,d)->field.setText(String.format(Locale.ROOT,"%04d-%02d-%02d",y,m+1,d)),
                c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();
    }
    private void startScanner() {
        IntentIntegrator i=new IntentIntegrator(this);i.setCaptureActivity(PortraitCaptureActivity.class);
        i.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES);i.setPrompt("扫描需要登记的商品条码");
        i.setBeepEnabled(false);i.setOrientationLocked(true);
        try{i.initiateScan();}catch(Exception e){Toast.makeText(this,"扫码启动失败",Toast.LENGTH_LONG).show();}
    }
    private void chooseProduct() {
        List<ProductDatabase.Product> all=db.all();
        if(all.isEmpty()){newProductPrompt();return;}
        LinearLayout area=StoreUi.column(this);area.setPadding(StoreUi.d(this,12),8,StoreUi.d(this,12),4);
        EditText query=StoreUi.input(this,"输入商品名称或条码搜索","",1);area.addView(query);
        ListView result=new ListView(this);area.addView(result,new LinearLayout.LayoutParams(-1,StoreUi.d(this,300)));
        List<ProductDatabase.Product> found=new ArrayList<>(all);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,new ArrayList<>());
        result.setAdapter(adapter);
        Runnable refresh=()->{
            found.clear();adapter.clear();String q=StoreUi.value(query).toLowerCase(Locale.ROOT);
            for(ProductDatabase.Product p:all) if(q.isEmpty()||p.name.toLowerCase(Locale.ROOT).contains(q)||p.barcode.contains(q)) {
                found.add(p);adapter.add(p.name+"\n"+p.barcode);
            }
            adapter.notifyDataSetChanged();
        };
        refresh.run();query.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int st,int count,int after) {}
            @Override public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();}
            @Override public void afterTextChanged(Editable e) {}
        });
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("选择商品").setView(area)
                .setNegativeButton("取消",null).setNeutralButton("录入新商品",(d,w)->newProductPrompt())
                .create();
        result.setOnItemClickListener((parent,v,pos,id)->{
            if(pos>=0&&pos<found.size()){addProduct(found.get(pos).barcode);dialog.dismiss();}
        });dialog.show();
    }
    private void newProductPrompt() {
        EditText barcode=StoreUi.input(this,"输入新商品条码","",1);
        new AlertDialog.Builder(this).setTitle("录入新商品条码")
                .setView(barcode).setNegativeButton("取消",null)
                .setPositiveButton("继续",(dialog,which)->{
                    String code=StoreUi.value(barcode);
                    if(code.isEmpty()){Toast.makeText(this,"条形码不能为空",Toast.LENGTH_LONG).show();return;}
                    ProductDatabase.Product exists=db.get(code);
                    if(exists!=null)addProduct(exists.barcode);
                    else openEditor(code);
                }).show();
    }
    private void openEditor(String code) {
        pending=code;
        Intent i=new Intent(this,ProductEditorActivity.class);i.putExtra("barcode",code);
        startActivityForResult(i,NEW_PRODUCT);
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        if(request==NEW_PRODUCT) {
            super.onActivityResult(request,result,data);
            String code=pending;pending=null;
            if(result==RESULT_OK&&code!=null)addProduct(code);
            return;
        }
        IntentResult scan=IntentIntegrator.parseActivityResult(request,result,data);
        if(scan==null){super.onActivityResult(request,result,data);return;}
        String code=BarcodeKey.scanned(scan.getContents());if(code.isEmpty())return;
        ProductDatabase.Product p=db.get(code);
        if(p!=null)addProduct(p.barcode);else openEditor(code);
    }
    private void addProduct(String barcode) {
        ProductDatabase.Product p=db.get(barcode);
        if(p==null){Toast.makeText(this,"未找到该商品",Toast.LENGTH_LONG).show();return;}
        for(LineEditor old:items) if(old.product.barcode.equals(p.barcode)) {
            Toast.makeText(this,"已在单据中，可直接修改数量",Toast.LENGTH_SHORT).show();old.quantity.requestFocus();return;
        }
        LineEditor line=new LineEditor();line.product=p;line.setting=store.settings(p.barcode);
        line.card=StoreUi.column(this);line.card.setPadding(StoreUi.d(this,10),StoreUi.d(this,9),
                StoreUi.d(this,10),StoreUi.d(this,10));line.card.setBackground(StoreUi.border(0xfff3f8f3,0xffdae8d9,this));
        LinearLayout head=StoreUi.row(this);TextView name=StoreUi.text(this,p.name,15,true);
        head.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView remove=StoreUi.text(this,"移除",13,true);remove.setTextColor(0xffbc5d56);
        head.addView(remove);remove.setOnClickListener(v->{items.remove(line);linesContainer.removeView(line.card);recompute();});
        line.card.addView(head);StoreUi.gap(line.card,6);
        LinearLayout edit=StoreUi.row(this);
        LinearLayout qtyCol=StoreUi.column(this);StoreUi.label(qtyCol,"数量");
        line.quantity=StoreUi.decimal(this,"数量","1");qtyCol.addView(line.quantity);
        edit.addView(qtyCol,new LinearLayout.LayoutParams(0,-2,1));
        LinearLayout unitCol=StoreUi.column(this);StoreUi.label(unitCol,"单位");
        line.unit=new Spinner(this);
        ArrayList<String> units=new ArrayList<>();units.add(line.setting.base);
        if(!line.setting.pack.isEmpty()&&line.setting.factor>1) units.add(line.setting.pack);
        ArrayAdapter<String> unitAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,units);
        line.unit.setAdapter(unitAdapter);unitCol.addView(line.unit);
        LinearLayout.LayoutParams up=new LinearLayout.LayoutParams(0,-2,1);up.leftMargin=StoreUi.d(this,7);
        edit.addView(unitCol,up);
        LinearLayout priceCol=StoreUi.column(this);StoreUi.label(priceCol,"单价(元)");
        line.price=StoreUi.decimal(this,"价格",Money.input(defaultPrice(p)));
        priceCol.addView(line.price);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(0,-2,1);pp.leftMargin=StoreUi.d(this,7);
        edit.addView(priceCol,pp);line.card.addView(edit);
        StoreUi.gap(line.card,5);
        line.subtotal=StoreUi.text(this,"小计 ¥0.00",13,false);line.subtotal.setTextColor(StoreUi.GREEN);
        line.card.addView(line.subtotal);
        LinearLayout.LayoutParams lp=StoreUi.lp(-1,-2);lp.bottomMargin=StoreUi.d(this,8);
        if(items.isEmpty())linesContainer.removeAllViews();
        linesContainer.addView(line.card,lp);items.add(line);
        TextWatcher change=new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){recompute();}
            @Override public void afterTextChanged(Editable e){}
        };
        line.quantity.addTextChangedListener(change);line.price.addTextChangedListener(change);
        line.unit.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> parent,View v,int position,long id){
                if(line.firstUnitEvent){line.firstUnitEvent=false;return;}
                long factor=position==0?1:line.setting.factor;
                try{line.price.setText(Money.input(Math.multiplyExact(defaultPrice(p),factor)));}
                catch(ArithmeticException e){line.price.setText("");}
                recompute();
            }
            @Override public void onNothingSelected(AdapterView<?> p){}
        });
        recompute();
    }
    private long defaultPrice(ProductDatabase.Product p) {
        return InventoryStore.SALE.equals(kind)?p.saleCents:p.purchaseCents;
    }
    private List<InventoryStore.Line> collect() {
        List<InventoryStore.Line> rows=new ArrayList<>();
        for(LineEditor e:items) {
            Long amountQty=InventoryStore.parseQty(StoreUi.value(e.quantity));
            if(amountQty==null || amountQty<=0)throw new IllegalArgumentException("请输入"+e.product.name+"的有效数量");
            long factor=e.unit.getSelectedItemPosition()==1?e.setting.factor:1;
            long baseMilli=Math.multiplyExact(amountQty,factor);
            Long cents=Money.parseCents(StoreUi.value(e.price));
            if(cents==null)throw new IllegalArgumentException("请输入"+e.product.name+"的正确单价");
            long subtotal=InventoryStore.amount(cents,amountQty);
            rows.add(new InventoryStore.Line(e.product.barcode,e.product.name,
                    e.unit.getSelectedItem().toString(),amountQty,baseMilli,cents,subtotal));
        }
        return rows;
    }
    private void recompute() {
        long total=0;boolean allValid=true;
        for(LineEditor e:items) {
            Long q=InventoryStore.parseQty(StoreUi.value(e.quantity));
            Long p=Money.parseCents(StoreUi.value(e.price));
            if(q==null||q<=0||p==null) {e.subtotal.setText("请输入有效数量和单价");allValid=false;continue;}
            try{long amount=InventoryStore.amount(p,q);total=Math.addExact(total,amount);
                e.subtotal.setText("小计 "+Money.show(amount));
            } catch(ArithmeticException ex){allValid=false;e.subtotal.setText("金额超出范围");}
        }
        totalView.setText(allValid?"单据金额  "+Money.show(total):"请检查商品明细");
        if(paid!=null && allValid) {
            String value=StoreUi.value(paid);
            if(value.isEmpty()||lastTotal<0||value.equals(Money.input(lastTotal)))paid.setText(Money.input(total));
        }
        lastTotal=total;
    }
    private void commit() {
        if(items.isEmpty()){Toast.makeText(this,"请先添加商品",Toast.LENGTH_LONG).show();return;}
        try {
            List<InventoryStore.Line> rows=collect();long total=0;
            for(InventoryStore.Line row:rows)total=Math.addExact(total,row.amount);
            Long actual=paid==null?0:Money.parseCents(StoreUi.value(paid));
            if(paid!=null && actual==null) throw new IllegalArgumentException("实收金额格式不正确");
            if(InventoryStore.ISSUE.equals(kind) && (StoreUi.value(party).isEmpty() ||
                    StoreUi.value(department).isEmpty()||StoreUi.value(purpose).isEmpty()))
                throw new IllegalArgumentException("领用人、部门/工程和用途必须填写");
            String message="确认保存 "+rows.size()+" 种商品？\n"+
                    "单据金额："+Money.show(total)+"\n"+
                    (InventoryStore.IN.equals(kind)?"保存后增加库存。":"保存后扣减对应商品库存。");
            long paidCents=actual==null?0:actual;
            new AlertDialog.Builder(this).setTitle("确认"+InventoryStore.kindName(kind))
                    .setMessage(message).setNegativeButton("返回修改",null)
                    .setPositiveButton("确认保存",(d,w)->{
                        save.setEnabled(false);
                        try{
                            store.saveDocument(kind,StoreUi.value(date),party==null?"":StoreUi.value(party),
                                    department==null?"":StoreUi.value(department),
                                    purpose==null?"":StoreUi.value(purpose),rows,paidCents);
                            new AlertDialog.Builder(this).setTitle("保存成功")
                                    .setMessage("整张"+InventoryStore.kindName(kind)+"单已保存，库存已更新。")
                                    .setPositiveButton("确定",(dia,wh)->finish()).setCancelable(false).show();
                        }catch(Exception error){save.setEnabled(true);
                            new AlertDialog.Builder(this).setTitle("保存失败")
                                    .setMessage(error.getMessage()==null?"原有数据未改变":error.getMessage())
                                    .setPositiveButton("确定",null).show();}
                    }).show();
        } catch(Exception error) {
            new AlertDialog.Builder(this).setTitle("信息填写不完整")
                    .setMessage(error.getMessage()==null?"请检查数量、单价和日期":error.getMessage())
                    .setPositiveButton("确定",null).show();
        }
    }
    @Override protected boolean blockSwipeExitForUnsavedChanges(){return !items.isEmpty();}
    @Override public void onBackPressed(){
        if(items.isEmpty()){super.onBackPressed();return;}
        new AlertDialog.Builder(this).setTitle("放弃当前单据？")
                .setMessage("未保存的商品明细将丢失。")
                .setNegativeButton("继续填写",null).setPositiveButton("放弃",(d,w)->super.onBackPressed()).show();
    }
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
