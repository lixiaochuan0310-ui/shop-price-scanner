package com.localpricescan.app;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

/** 门市进销存首页：八宫格，扫码只查价，不改变库存。 */
public final class MainActivity extends Activity {
    private static final int NEW_ITEM=311;
    private ProductDatabase db;
    private TextView summary;
    private String pendingBarcode;
    private boolean scanning;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);AppUi.apply(this);db=new ProductDatabase(this);
        getWindow().setBackgroundDrawableResource(R.drawable.bg_app_surface);
        LinearLayout root=StoreUi.column(this);root.setPadding(StoreUi.d(this,15),StoreUi.d(this,13),
                StoreUi.d(this,15),StoreUi.d(this,12));root.setBackgroundColor(StoreUi.PALE);
        setContentView(root);
        LinearLayout title=StoreUi.row(this);
        android.widget.ImageView brandIcon=new android.widget.ImageView(this);
        brandIcon.setImageResource(R.drawable.ic_store_foreground);
        LinearLayout.LayoutParams brandIconParams=new LinearLayout.LayoutParams(StoreUi.d(this,38),StoreUi.d(this,38));
        brandIconParams.rightMargin=StoreUi.d(this,8);
        title.addView(brandIcon,brandIconParams);
        TextView brand=StoreUi.text(this,"门市进销存",25,true);brand.setTextColor(StoreUi.GREEN);
        title.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        TextView version=StoreUi.text(this,"v2.0.0",12,false);
        try {version.setText("v"+getPackageManager().getPackageInfo(getPackageName(),0).versionName);}
        catch(PackageManager.NameNotFoundException ignored) {}
        version.setTextColor(StoreUi.MUTED);title.addView(version);root.addView(title);
        StoreUi.gap(root,5);
        TextView subtitle=StoreUi.text(this,"扫码查价 · 商品进销存 · 本地离线",13,false);
        subtitle.setTextColor(StoreUi.MUTED);root.addView(subtitle);
        StoreUi.gap(root,12);
        summary=StoreUi.text(this,"正在读取库存…",14,true);
        summary.setGravity(Gravity.CENTER);summary.setPadding(10,StoreUi.d(this,11),10,StoreUi.d(this,11));
        summary.setBackground(StoreUi.round(0xffffffff,18,this));root.addView(summary);
        StoreUi.gap(root,11);
        String[] names={"扫码查价","商品入库","商品销售","内部领用","库存查询","库存盘点","商品管理","统计报表"};
        int[] tileIcons={R.drawable.ic_home_scan,R.drawable.ic_home_in,R.drawable.ic_home_sale,R.drawable.ic_home_issue,
                R.drawable.ic_home_stock,R.drawable.ic_home_count,R.drawable.ic_home_items,R.drawable.ic_home_reports};
        int[][] tint={{0xffd9ecff,0xffb6ddf8},{0xffe2f5e5,0xffbbebce},
                {0xfffff4d8,0xfff8dfa4},{0xfff1e8ff,0xffd9c6ef},
                {0xffdff4f2,0xffbae5df},{0xffffece4,0xfff1d2c0},
                {0xffe7ecfc,0xffced7f2},{0xffedf6dc,0xffd8eab5}};
        for(int r=0;r<4;r++) {
            LinearLayout row=StoreUi.row(this);
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,0,1);
            rp.bottomMargin=StoreUi.d(this,9);root.addView(row,rp);
            for(int c=0;c<2;c++) {
                final int index=r*2+c;
                LinearLayout tile=StoreUi.column(this);tile.setGravity(Gravity.CENTER);
                GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                        new int[]{tint[index][0],tint[index][1]});bg.setCornerRadius(StoreUi.d(this,17));
                tile.setBackground(bg);tile.setElevation(StoreUi.d(this,1));
                android.widget.ImageView icon=new android.widget.ImageView(this);
                icon.setImageResource(tileIcons[index]);
                tile.addView(icon,new LinearLayout.LayoutParams(StoreUi.d(this,31),StoreUi.d(this,31)));
                StoreUi.gap(tile,7);
                TextView text=StoreUi.text(this,names[index],15,true);text.setGravity(Gravity.CENTER);
                tile.addView(text);
                LinearLayout.LayoutParams tilep=new LinearLayout.LayoutParams(0,-1,1);
                if(c==0) tilep.rightMargin=StoreUi.d(this,9);
                row.addView(tile,tilep);tile.setOnClickListener(v->open(index));
            }
        }
        LinearLayout foot=StoreUi.row(this);
        footer(foot,"其他出库",v->activity(StoreDocumentActivity.class,"OTHER"));
        footer(foot,"业务流水",v->activity(StoreRecordsActivity.class,null));
        footer(foot,"备份恢复",v->activity(StoreBackupActivity.class,null));
        root.addView(foot);
        if(state!=null) pendingBarcode=state.getString("pendingBarcode");
    }
    private void footer(LinearLayout row,String text,View.OnClickListener action) {
        TextView b=StoreUi.button(this,text,0xffe7efe5,StoreUi.GREEN);
        b.setTextSize(13);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.rightMargin=StoreUi.d(this,5);
        row.addView(b,p);b.setOnClickListener(action);
    }
    private void activity(Class<?> screen,String kind) {
        Intent intent=new Intent(this,screen);if(kind!=null)intent.putExtra("kind",kind);
        BackPreview.capture(this);startActivity(intent);
    }
    private void open(int index) {
        switch(index) {
            case 0: startScanner();break;
            case 1: activity(StoreDocumentActivity.class,"IN");break;
            case 2: activity(StoreDocumentActivity.class,"SALE");break;
            case 3: activity(StoreDocumentActivity.class,"ISSUE");break;
            case 4: activity(StoreStockActivity.class,null);break;
            case 5: activity(StoreCountActivity.class,null);break;
            case 6: activity(ProductListActivity.class,null);break;
            case 7: activity(StoreReportsActivity.class,null);break;
        }
    }
    @Override protected void onResume() {
        super.onResume();
        scanning=false;
        if(db!=null && summary!=null) {
            try {
                int n=db.count();int available=0;int empty=0;
                for(InventoryStore.StockRow r:new InventoryStore(db).stocks()) {if(r.current>0)available++;else empty++;}
                summary.setText("商品 "+n+" 种    ·    有库存 "+available+" 种    ·    零库存 "+empty+" 种");
            } catch (Exception e) {summary.setText("库存读取失败，请检查数据");}
        }
    }
    private void startScanner() {
        if(scanning) return;scanning=true;
        IntentIntegrator i=new IntentIntegrator(this);
        i.setCaptureActivity(PortraitCaptureActivity.class);i.setDesiredBarcodeFormats(IntentIntegrator.ONE_D_CODE_TYPES);
        i.setPrompt("将商品条形码放入扫描框");i.setBeepEnabled(false);i.setOrientationLocked(true);
        try{i.initiateScan();}catch(RuntimeException e){scanning=false;Toast.makeText(this,"扫码无法启动，请检查相机权限",Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int request,int result,Intent data) {
        if(request==NEW_ITEM) {
            super.onActivityResult(request,result,data);
            String code=pendingBarcode;pendingBarcode=null;
            if(result==RESULT_OK && code!=null && db.get(code)!=null) detail(code);
            return;
        }
        IntentResult scan=IntentIntegrator.parseActivityResult(request,result,data);
        if(scan==null){super.onActivityResult(request,result,data);return;}
        scanning=false;
        String code=BarcodeKey.scanned(scan.getContents());if(code.isEmpty())return;
        try {
            ProductDatabase.Product p=db.get(code);
            if(p!=null){
                Toast.makeText(this,"该商品已登记，正在显示已有商品",Toast.LENGTH_SHORT).show();
                detail(p.barcode);
            }
            else {pendingBarcode=code;Intent i=new Intent(this,ProductEditorActivity.class);
                i.putExtra("barcode",code);startActivityForResult(i,NEW_ITEM);}
        } catch(SQLiteException e){Toast.makeText(this,"商品查询失败",Toast.LENGTH_LONG).show();}
    }
    private void detail(String code) {
        Intent i=new Intent(this,ProductDetailActivity.class);
        i.putExtra("barcode",code);i.putExtra("scanResult",true);
        BackPreview.capture(this);startActivity(i);
    }
    @Override protected void onSaveInstanceState(Bundle state){super.onSaveInstanceState(state);state.putString("pendingBarcode",pendingBarcode);}
    @Override protected void onDestroy(){if(db!=null)db.close();super.onDestroy();}
}
