package com.localpricescan.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.RenderEffect;
import android.graphics.Shader;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;

/**
 * 交互式返回：当前页面随右滑逐渐模糊、淡出，上一页的真实预览由模糊变清晰。
 * 过渡只在内存中进行，不写入照片或商品资料；不创建白色中间页面。
 */
final class SwipeBackEffect {
    private final Activity activity;
    private final Bitmap previousScreen;
    private View foreground;
    private FrameLayout frame;
    private ImageView blurredPrevious;
    private boolean finishing;
    private boolean dragging;
    private float progress;
    private int lastBlurRadius = -1;
    private ValueAnimator settleAnimator;

    SwipeBackEffect(Activity activity, Bitmap previousScreen) {
        this.activity = activity;
        this.previousScreen = previousScreen;
    }

    /** 页面首次布局完成后即建立上一页预览，避免起滑时才插入视图。 */
    void install() {
        if (foreground != null) return;
        View content = activity.findViewById(android.R.id.content);
        if (!(content instanceof FrameLayout)) return;
        frame = (FrameLayout) content;
        if (frame.getChildCount() == 0) return;
        foreground = frame.getChildAt(frame.getChildCount() - 1);

        ImageView clearPrevious = previewView(previousScreen);
        frame.addView(clearPrevious, 0, fullScreenParams());

        blurredPrevious = previewView(previousScreen);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // 上一页只创建一次 GPU 模糊层，滑动时只改变其 alpha，避免每帧处理截图。
            blurredPrevious.setRenderEffect(RenderEffect.createBlurEffect(
                    dp(12), dp(12), Shader.TileMode.CLAMP));
        } else if (previousScreen != null) {
            // 旧系统用小尺寸柔化预览替代实时模糊，不在每次手指移动时计算图像。
            int w = Math.max(1, previousScreen.getWidth() / 12);
            int h = Math.max(1, previousScreen.getHeight() / 12);
            blurredPrevious.setImageBitmap(Bitmap.createScaledBitmap(previousScreen, w, h, true));
        }
        frame.addView(blurredPrevious, 1, fullScreenParams());
        blurredPrevious.setAlpha(1f);
    }

    private ImageView previewView(Bitmap picture) {
        ImageView image = new ImageView(activity);
        image.setBackgroundResource(R.drawable.bg_app_surface);
        image.setScaleType(ImageView.ScaleType.FIT_XY);
        if (picture != null) image.setImageBitmap(picture);
        image.setClickable(false);
        image.setFocusable(false);
        return image;
    }

    private FrameLayout.LayoutParams fullScreenParams() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    private float dp(float amount) {
        return amount * activity.getResources().getDisplayMetrics().density;
    }

    private void cancelSettle() {
        if (settleAnimator != null) {
            settleAnimator.cancel();
            settleAnimator = null;
        }
    }

    boolean begin() {
        if (finishing) return false;
        install();
        if (foreground == null || frame == null) return false;
        // 新手势可打断前一次未完成的回弹，避免两个动画同时修改页面造成卡顿。
        cancelSettle();
        if (dragging) return true;
        dragging = true;
        foreground.setPivotX(foreground.getWidth() / 2f);
        foreground.setPivotY(foreground.getHeight() / 2f);
        return true;
    }

    void drag(float dx) {
        if (!begin()) return;
        // 实际手势进度与画面过渡绑定，完成阈值仍由 Activity 统一判断。
        setProgress(Math.max(0f, dx) / Math.max(1f, frame.getWidth()));
    }

    private void setProgress(float value) {
        if (foreground == null || frame == null) return;
        progress = Math.max(0f, Math.min(1f, value));
        // 只轻微右移和缩放，主体由模糊、淡出取代原先的缩小飞走动画。
        foreground.setTranslationX(frame.getWidth() * .08f * progress);
        foreground.setTranslationY(0f);
        float scale = 1f - .035f * progress;
        foreground.setScaleX(scale);
        foreground.setScaleY(scale);
        foreground.setAlpha(1f - progress);
        if (blurredPrevious != null) {
            // 两张相同的上一页预览交叉淡化：模糊层逐渐退去，清晰层逐渐露出。
            blurredPrevious.setAlpha(1f - progress);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            int radius = Math.round(dp(10) * progress / 2f) * 2;
            if (radius != lastBlurRadius) {
                lastBlurRadius = radius;
                foreground.setRenderEffect(radius <= 0 ? null :
                        RenderEffect.createBlurEffect(radius, radius, Shader.TileMode.CLAMP));
            }
        }
    }

    /** 完成右滑后，在清晰的上一页预览上结束当前 Activity。 */
    void dismiss(Runnable navigateBack) {
        if (finishing) return;
        if (foreground == null || frame == null) {
            navigateBack.run();
            return;
        }
        finishing = true;
        animateTo(1f, 200L, () -> {
            setProgress(1f);
            navigateBack.run();
        });
    }

    void restore(boolean immediately) {
        if (foreground == null || finishing) return;
        cancelSettle();
        if (immediately) {
            setProgress(0f);
            dragging = false;
        } else {
            animateTo(0f, 140L, () -> dragging = false);
        }
    }

    private void animateTo(float target, long duration, Runnable endAction) {
        cancelSettle();
        final float start = progress;
        final ValueAnimator animation = ValueAnimator.ofFloat(start, target);
        settleAnimator = animation;
        animation.setDuration(duration);
        animation.setInterpolator(new DecelerateInterpolator(1.4f));
        animation.addUpdateListener(a -> setProgress((Float) a.getAnimatedValue()));
        animation.addListener(new AnimatorListenerAdapter() {
            private boolean canceled;
            @Override public void onAnimationCancel(Animator a) { canceled = true; }
            @Override public void onAnimationEnd(Animator a) {
                if (settleAnimator == animation) settleAnimator = null;
                if (!canceled) endAction.run();
            }
        });
        animation.start();
    }

    boolean isFinishing() { return finishing; }
}
