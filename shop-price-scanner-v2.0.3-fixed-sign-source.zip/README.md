# 商品查价 V2.0.3 — 国内免费图片搜索整改版（固定签名源码）

## 此次整改

- 将 V2.0.2 的 Open Food Facts / Open Products Facts 条码和名称查询替换为国内网页图片搜索，不再通过这两个图库接口查询。
- 在“录入新商品”或“编辑商品”中点击“免费搜索商品照片”，默认使用百度图片，另可切换搜狗图片。
- 自动带入已有商品名称或条码，也可以输入更精确的名称与规格（例如“百事可乐 500ml”）查找。
- 搜索结果以原搜索网站网页展示。长按可取得实际 HTTPS 图片地址的图片，核对包装后点“使用这张照片”，图片压缩后交回编辑页，保存商品时写入原有 SQLite 本地数据库。
- 搜索引擎可能禁止内嵌网页、以背景或动态画布呈现图片、限制防盗链、出现验证页或返回非 HTTPS 图片。此时点击“在浏览器打开”，用浏览器保存照片后返回“从相册选图”再导入，避免假装成功。
- 保留独立的手机相册选择功能、相机拍照功能，平时离线扫码仍不访问网络。
- 不接入任何付费接口，不需要账号或 API 密钥，不抓取搜索引擎内部私有接口，不保证能自动获取所有图片。

## 兼容性和签名

- 包名 `com.localpricescan.app`、SQLite 数据库与商品表结构不变；仅更改联网图片搜索 Activity / 页面布局、编辑按钮文案及应用版本号。
- 版本号 `2.0.3`、版本代码 `12`，可从之前较低版本号覆盖升级；不要卸载原应用。
- `.github/workflows/build-release.yml` 与 `signing/release-keystore.p12.enc` 均保持原样。
- GitHub Actions 仍通过仓库 Secret `SHOP_SIGNING_PASSWORD` 解密固定签名，执行 `assembleRelease`；签名 SHA-256 指纹校验为 `EC:12:10:E1:E8:7C:E2:06:3F:3C:AA:5E:B2:4D:BB:05:B1:41:C2:04:33:AE:8D:F8:21:F0:CE:FD:31:05:7F:3F`。

## GitHub 使用

1. 将 `shop-price-scanner-v2.0.3-fixed-sign-source.zip` 作为**文件**上传到 `lixiaochuan0310-ui/shop-price-scanner` 仓库根目录，不解压。
2. 现有 `build-release.yml` 会选择最新的 v2.0.3 源码编译（使用现有固定签名配置）。
3. 下载 Actions 的 `shop-price-scanner-signed-release` 产物，解压出 `app-release.apk` 覆盖安装，不要卸载旧版，保留原有商品数据和照片。

## 验证范围

已进行源码静态检查、全部 XML 解析、资源 ID 对应性、关键原始文件哈希对比和 ZIP 校验。本环境未具备 Android SDK，不能替代 GitHub 实际 APK 编译或手机运行测试；百度 / 搜狗的移动网页行为与具体图片下载权限必须以实机验证为准。
